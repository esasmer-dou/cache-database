package com.reactor.cachedb.mssql;

import com.reactor.cachedb.core.config.WriteBehindConfig;
import com.reactor.cachedb.core.model.OperationType;
import com.reactor.cachedb.core.queue.FailureClassifyingFlusher;
import com.reactor.cachedb.core.queue.QueuedWriteOperation;
import com.reactor.cachedb.core.queue.StoragePerformanceCollector;
import com.reactor.cachedb.core.queue.WriteBehindFlusherFactory;
import com.reactor.cachedb.core.queue.WriteFailureDetails;
import com.reactor.cachedb.core.registry.EntityRegistry;
import com.reactor.cachedb.jdbc.AbstractJdbcWriteBehindFlusher;
import com.reactor.cachedb.jdbc.JdbcWriteBehindSupport;
import com.reactor.cachedb.jdbc.JdbcWriteFence;
import com.reactor.cachedb.jdbc.VersionGuardedWriteSupport;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.sql.DataSource;

public final class MssqlWriteBehindFlusher extends AbstractJdbcWriteBehindFlusher implements FailureClassifyingFlusher {

    private final MssqlDatabaseDialect dialect;
    private final MssqlFailureClassifier failureClassifier;
    private final StoragePerformanceCollector performanceCollector;
    private final MssqlWriteBehindOptions options;
    private final int transactionBatchSize;

    public MssqlWriteBehindFlusher(DataSource dataSource, EntityRegistry entityRegistry) {
        this(
                dataSource,
                entityRegistry,
                WriteBehindConfig.defaults(),
                (StoragePerformanceCollector) null);
    }

    public MssqlWriteBehindFlusher(
            DataSource dataSource, EntityRegistry entityRegistry, WriteBehindConfig config) {
        this(dataSource, entityRegistry, config, (StoragePerformanceCollector) null);
    }

    public MssqlWriteBehindFlusher(
            DataSource dataSource,
            EntityRegistry entityRegistry,
            WriteBehindConfig config,
            StoragePerformanceCollector performanceCollector) {
        this(
                dataSource,
                entityRegistry,
                config,
                performanceCollector,
                MssqlWriteBehindOptions.defaults());
    }

    public MssqlWriteBehindFlusher(
            DataSource dataSource,
            EntityRegistry entityRegistry,
            WriteBehindConfig config,
            MssqlWriteBehindOptions options) {
        this(dataSource, entityRegistry, config, null, options);
    }

    public MssqlWriteBehindFlusher(
            DataSource dataSource,
            EntityRegistry entityRegistry,
            WriteBehindConfig config,
            StoragePerformanceCollector performanceCollector,
            MssqlWriteBehindOptions options) {
        super(dataSource, entityRegistry, JdbcWriteFence.Provider.MSSQL,
                (options == null ? MssqlWriteBehindOptions.defaults() : options).queryTimeoutSeconds(), config);
        this.dialect = new MssqlDatabaseDialect();
        this.failureClassifier = new MssqlFailureClassifier();
        this.performanceCollector = performanceCollector;
        this.options = options == null ? MssqlWriteBehindOptions.defaults() : options;
        this.transactionBatchSize =
                Math.max(
                        1,
                        config == null
                                ? WriteBehindConfig.defaults().maxFlushBatchSize()
                                : config.maxFlushBatchSize());
    }

    public static WriteBehindFlusherFactory factory(MssqlWriteBehindOptions options) {
        MssqlWriteBehindOptions resolvedOptions =
                options == null ? MssqlWriteBehindOptions.defaults() : options;
        return (dataSource, entityRegistry, writeBehindConfig, performanceCollector) ->
                new MssqlWriteBehindFlusher(
                        dataSource,
                        entityRegistry,
                        writeBehindConfig,
                        performanceCollector,
                        resolvedOptions);
    }

    @Override
    public void flush(QueuedWriteOperation operation) throws SQLException {
        if (operation.atomicBatch()) {
            flushAtomicBatch(operation.batchOperations());
            return;
        }
        long startedAt = System.nanoTime();
        try {
            writeFence.initialize();
            try (Connection connection = dataSource.getConnection()) {
                executeInTransaction(connection, List.of(operation));
            }
        } finally {
            recordWrite(startedAt, operation.observationTag());
        }
    }

    @Override
    public void flushBatch(List<QueuedWriteOperation> operations) throws SQLException {
        long startedAt = System.nanoTime();
        try {
            if (operations.isEmpty()) {
                return;
            }
            writeFence.initialize();
            try (Connection connection = dataSource.getConnection()) {
                for (int start = 0; start < operations.size(); start += transactionBatchSize) {
                    int end = Math.min(operations.size(), start + transactionBatchSize);
                    executeInTransaction(connection, operations.subList(start, end));
                }
            }
        } finally {
            if (!operations.isEmpty()) {
                recordWrite(startedAt, dominantObservationTag(operations));
            }
        }
    }

    private void executeInTransaction(Connection connection, List<QueuedWriteOperation> operations)
            throws SQLException {
        SessionSettings settings = options.lockTimeoutEnabled() ? new SessionSettings() {
            private int previousTimeout;
            private boolean restore;
            @Override
            public void apply(Connection connection) throws SQLException {
                if (options.restoreLockTimeoutAfterTransaction()) {
                    previousTimeout = currentLockTimeout(connection);
                    restore = true;
                }
                setLockTimeout(connection, options.lockTimeoutMillis());
            }
            @Override
            public void restore(Connection connection) throws SQLException {
                if (restore) setLockTimeout(connection, previousTimeout);
            }
        } : null;
        inTransaction(connection, operations, options.transactionIsolation(), settings, accepted -> {
            try (StatementCache statements = new StatementCache(connection)) {
                int index = 0;
                while (index < accepted.size()) {
                    QueuedWriteOperation operation = accepted.get(index);
                    index = operation.type() == OperationType.DELETE
                            ? deleteConsecutiveBatch(statements, accepted, index)
                            : upsertConsecutiveBatch(statements, accepted, index);
                }
            }
        });
    }

    @Override
    public void flushAtomicBatch(List<QueuedWriteOperation> operations) throws SQLException {
        if (operations.isEmpty()) return;
        writeFence.initialize();
        try (Connection connection = dataSource.getConnection()) {
            executeInTransaction(connection, operations);
        }
    }

    private int deleteConsecutiveBatch(
            StatementCache statements, List<QueuedWriteOperation> operations, int startIndex)
            throws SQLException {
        QueuedWriteOperation template = operations.get(startIndex);
        String sql = dialect.deleteSql(template);
        PreparedStatement statement = statements.get(sql);
        int index = startIndex;
        while (index < operations.size()) {
            QueuedWriteOperation operation = operations.get(index);
            if (operation.type() != OperationType.DELETE
                    || !dialect.deleteSql(operation).equals(sql)) {
                break;
            }
            statement.clearParameters();
            bindDelete(statement, operation);
            statement.addBatch();
            index++;
        }
        int[] affectedRows = statement.executeBatch();
        statement.clearBatch();
        VersionGuardedWriteSupport.verifyBatchOutcome(
                statements.connection(),
                entityRegistry,
                operations.subList(startIndex, index),
                affectedRows,
                options.queryTimeoutSeconds());
        return index;
    }

    private void bindDelete(PreparedStatement statement, QueuedWriteOperation operation)
            throws SQLException {
        statement.setObject(
                1,
                JdbcWriteBehindSupport.convertValue(
                        operation.id(),
                        JdbcWriteBehindSupport.columnType(
                                entityRegistry, operation, operation.idColumn())));
        statement.setLong(2, operation.version());
    }

    private int upsertConsecutiveBatch(
            StatementCache statements, List<QueuedWriteOperation> operations, int startIndex)
            throws SQLException {
        QueuedWriteOperation template = operations.get(startIndex);
        List<Map.Entry<String, String>> templateEntries = entries(template);
        String updateSql = dialect.updateSql(template, templateEntries);
        String insertSql = dialect.insertSql(template, templateEntries);
        int maxProbeRows = MssqlDatabaseDialect.MSSQL_PARAMETER_LIMIT / 2;
        ArrayList<QueuedWriteOperation> batch = new ArrayList<>();
        Set<String> identities = new HashSet<>();

        int index = startIndex;
        while (index < operations.size() && batch.size() < maxProbeRows) {
            QueuedWriteOperation candidate = operations.get(index);
            if (candidate.type() == OperationType.DELETE) {
                break;
            }
            List<Map.Entry<String, String>> candidateEntries = entries(candidate);
            if (!dialect.updateSql(candidate, candidateEntries).equals(updateSql)
                    || !dialect.insertSql(candidate, candidateEntries).equals(insertSql)) {
                break;
            }
            String identity = candidate.entityName() + '\u001F' + candidate.id();
            if (!identities.add(identity)) {
                break;
            }
            batch.add(candidate);
            index++;
        }

        PreparedStatement updateStatement = statements.get(updateSql);
        for (QueuedWriteOperation operation : batch) {
            updateStatement.clearParameters();
            bindUpdate(updateStatement, operation, entries(operation));
            updateStatement.addBatch();
        }
        int[] updateOutcomes = updateStatement.executeBatch();
        updateStatement.clearBatch();
        if (updateOutcomes == null || updateOutcomes.length != batch.size()) {
            throw new SQLException(
                    "MSSQL update batch returned an unexpected result count: expected="
                            + batch.size()
                            + ", actual="
                            + (updateOutcomes == null ? "null" : updateOutcomes.length));
        }

        ArrayList<QueuedWriteOperation> unresolved = new ArrayList<>();
        for (int operationIndex = 0; operationIndex < batch.size(); operationIndex++) {
            int outcome = updateOutcomes[operationIndex];
            if (outcome > 0 || outcome == Statement.SUCCESS_NO_INFO) {
                continue;
            }
            if (outcome == Statement.EXECUTE_FAILED) {
                throw new SQLException(
                        "MSSQL update batch failed for entity="
                                + batch.get(operationIndex).entityName()
                                + ", id="
                                + batch.get(operationIndex).id());
            }
            if (outcome != 0) {
                throw new SQLException(
                        "MSSQL update batch returned unsupported outcome=" + outcome);
            }
            unresolved.add(batch.get(operationIndex));
        }

        if (!unresolved.isEmpty()) {
            Map<Integer, Long> currentVersions = currentVersions(statements, unresolved);
            ArrayList<QueuedWriteOperation> missing = new ArrayList<>();
            for (int unresolvedIndex = 0; unresolvedIndex < unresolved.size(); unresolvedIndex++) {
                QueuedWriteOperation operation = unresolved.get(unresolvedIndex);
                Long currentVersion = currentVersions.get(unresolvedIndex);
                if (currentVersion == null) {
                    missing.add(operation);
                    continue;
                }
                if (currentVersion >= operation.version()) {
                    continue;
                }
                throw new SQLException(
                        "Version-guarded MSSQL upsert did not reach durable state for entity="
                                + operation.entityName()
                                + ", id="
                                + operation.id()
                                + ", incomingVersion="
                                + operation.version()
                                + ", currentVersion="
                                + currentVersion,
                        "CDB02");
            }
            insertBatch(statements, insertSql, missing);
        }
        return index;
    }

    private void bindUpdate(
            PreparedStatement statement,
            QueuedWriteOperation operation,
            List<Map.Entry<String, String>> entries)
            throws SQLException {
        int parameterIndex = 1;
        for (Map.Entry<String, String> entry : entries) {
            if (entry.getKey().equals(operation.idColumn())) {
                continue;
            }
            statement.setObject(
                    parameterIndex++,
                    JdbcWriteBehindSupport.convertValue(
                            entry.getValue(),
                            JdbcWriteBehindSupport.columnType(
                                    entityRegistry, operation, entry.getKey())));
        }
        statement.setObject(
                parameterIndex++,
                JdbcWriteBehindSupport.convertValue(
                        operation.id(),
                        JdbcWriteBehindSupport.columnType(
                                entityRegistry, operation, operation.idColumn())));
        statement.setLong(parameterIndex, operation.version());
    }

    private Map<Integer, Long> currentVersions(
            StatementCache statements, List<QueuedWriteOperation> operations) throws SQLException {
        QueuedWriteOperation template = operations.get(0);
        PreparedStatement statement =
                statements.get(dialect.currentVersionsSql(template, operations.size()));
        statement.clearParameters();
        int parameterIndex = 1;
        for (int index = 0; index < operations.size(); index++) {
            QueuedWriteOperation operation = operations.get(index);
            statement.setInt(parameterIndex++, index);
            statement.setObject(
                    parameterIndex++,
                    JdbcWriteBehindSupport.convertValue(
                            operation.id(),
                            JdbcWriteBehindSupport.columnType(
                                    entityRegistry, operation, operation.idColumn())));
        }
        LinkedHashMap<Integer, Long> versions = new LinkedHashMap<>();
        try (ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                int operationOrdinal = resultSet.getInt(1);
                long version = resultSet.getLong(2);
                versions.put(operationOrdinal, resultSet.wasNull() ? null : version);
            }
        }
        return versions;
    }

    private void insertBatch(
            StatementCache statements, String insertSql, List<QueuedWriteOperation> operations)
            throws SQLException {
        if (operations.isEmpty()) {
            return;
        }
        PreparedStatement statement = statements.get(insertSql);
        for (QueuedWriteOperation operation : operations) {
            statement.clearParameters();
            JdbcWriteBehindSupport.bindUpsert(
                    statement, operation, entityRegistry, entries(operation));
            statement.addBatch();
        }
        int[] outcomes = statement.executeBatch();
        statement.clearBatch();
        VersionGuardedWriteSupport.verifyBatchOutcome(
                statements.connection(),
                entityRegistry,
                operations,
                outcomes,
                options.queryTimeoutSeconds());
    }

    private List<Map.Entry<String, String>> entries(QueuedWriteOperation operation) {
        return new ArrayList<>(operation.columns().entrySet());
    }

    private PreparedStatement prepareStatement(Connection connection, String sql)
            throws SQLException {
        PreparedStatement statement = connection.prepareStatement(sql);
        applyQueryTimeout(statement);
        return statement;
    }

    private final class StatementCache implements AutoCloseable {
        private final Connection connection;
        private final LinkedHashMap<String, PreparedStatement> statements = new LinkedHashMap<>();

        private StatementCache(Connection connection) {
            this.connection = connection;
        }

        private PreparedStatement get(String sql) throws SQLException {
            PreparedStatement cached = statements.get(sql);
            if (cached != null) {
                return cached;
            }
            PreparedStatement prepared = prepareStatement(connection, sql);
            statements.put(sql, prepared);
            return prepared;
        }

        private Connection connection() {
            return connection;
        }

        @Override
        public void close() throws SQLException {
            SQLException closeFailure = null;
            for (PreparedStatement statement : statements.values()) {
                try {
                    statement.close();
                } catch (SQLException exception) {
                    if (closeFailure == null) {
                        closeFailure = exception;
                    } else {
                        closeFailure.addSuppressed(exception);
                    }
                }
            }
            if (closeFailure != null) {
                throw closeFailure;
            }
        }
    }

    private int currentLockTimeout(Connection connection) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            applyQueryTimeout(statement);
            try (ResultSet resultSet = statement.executeQuery("SELECT @@LOCK_TIMEOUT")) {
                if (resultSet.next()) {
                    return resultSet.getInt(1);
                }
            }
        }
        return MssqlWriteBehindOptions.LOCK_TIMEOUT_WAIT_FOREVER;
    }

    private void setLockTimeout(Connection connection, int lockTimeoutMillis) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            applyQueryTimeout(statement);
            statement.execute("SET LOCK_TIMEOUT " + lockTimeoutMillis);
        }
    }

    private void applyQueryTimeout(Statement statement) throws SQLException {
        if (options.queryTimeoutSeconds() > 0) {
            statement.setQueryTimeout(options.queryTimeoutSeconds());
        }
    }

    private void recordWrite(long startedAtNanos, String observationTag) {
        if (performanceCollector == null) {
            return;
        }
        long elapsedMicros = (System.nanoTime() - startedAtNanos) / 1_000L;
        String normalizedTag = observationTag == null ? "" : observationTag.trim();
        if (normalizedTag.isBlank()) {
            performanceCollector.recordPostgresWrite("mssql:write-behind", elapsedMicros);
            return;
        }
        performanceCollector.recordPostgresWrite(providerTag(normalizedTag), elapsedMicros);
    }

    private String providerTag(String normalizedTag) {
        if (normalizedTag.regionMatches(true, 0, "mssql:", 0, "mssql:".length())) {
            return normalizedTag;
        }
        return "mssql:" + normalizedTag;
    }

    private String dominantObservationTag(List<QueuedWriteOperation> operations) {
        java.util.LinkedHashMap<String, Integer> counts = new java.util.LinkedHashMap<>();
        for (QueuedWriteOperation operation : operations) {
            String tag = operation.observationTag();
            if (tag == null || tag.isBlank()) {
                continue;
            }
            counts.merge(tag.trim(), 1, Integer::sum);
        }
        String bestTag = "";
        int bestCount = 0;
        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            if (entry.getValue() > bestCount) {
                bestTag = entry.getKey();
                bestCount = entry.getValue();
            }
        }
        return bestTag;
    }

    @Override
    public WriteFailureDetails classify(Exception exception) {
        return failureClassifier.classify(exception);
    }
}
