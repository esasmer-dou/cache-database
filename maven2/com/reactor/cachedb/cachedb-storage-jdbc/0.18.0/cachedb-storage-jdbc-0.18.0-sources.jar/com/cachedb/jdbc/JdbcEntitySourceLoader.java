package com.reactor.cachedb.jdbc;

import com.reactor.cachedb.core.cache.PageWindow;
import com.reactor.cachedb.core.model.EntityCodec;
import com.reactor.cachedb.core.model.EntityMetadata;
import com.reactor.cachedb.core.page.EntityByIdLoader;
import com.reactor.cachedb.core.page.EntityPageLoader;
import com.reactor.cachedb.core.page.EntityQueryLoader;
import com.reactor.cachedb.core.page.VersionedEntity;
import com.reactor.cachedb.core.page.VersionedEntitySourceLoader;
import com.reactor.cachedb.core.query.QueryFilter;
import com.reactor.cachedb.core.query.QueryGroup;
import com.reactor.cachedb.core.query.QueryNode;
import com.reactor.cachedb.core.query.QuerySort;
import com.reactor.cachedb.core.query.QuerySortDirection;
import com.reactor.cachedb.core.query.QuerySpec;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.StringJoiner;

public final class JdbcEntitySourceLoader<T, ID>
        implements VersionedEntitySourceLoader<T, ID>, com.reactor.cachedb.core.page.EntityOwnershipLoader<ID> {

    private static final String IDENTIFIER_SEGMENT = "[A-Za-z_][A-Za-z0-9_]*";
    private static final String IDENTIFIER = IDENTIFIER_SEGMENT;
    private static final String QUALIFIED_IDENTIFIER = IDENTIFIER_SEGMENT + "(\\." + IDENTIFIER_SEGMENT + ")*";

    private final DataSource dataSource;
    private final EntityMetadata<T, ID> metadata;
    private final EntityCodec<T> codec;
    private final int maxRows;
    private final int queryTimeoutSeconds;
    private final String tableName;
    private final List<String> selectColumns;
    private final Set<String> allowedColumns;
    private final JdbcQueryDialect dialect;

    public JdbcEntitySourceLoader(
            DataSource dataSource,
            EntityMetadata<T, ID> metadata,
            EntityCodec<T> codec,
            int maxRows
    ) {
        this(dataSource, metadata, codec, maxRows, 30);
    }

    public JdbcEntitySourceLoader(
            DataSource dataSource,
            EntityMetadata<T, ID> metadata,
            EntityCodec<T> codec,
            int maxRows,
            int queryTimeoutSeconds
    ) {
        this(dataSource, metadata, codec, maxRows, queryTimeoutSeconds, JdbcQueryDialects.resolve(dataSource));
    }

    public JdbcEntitySourceLoader(
            DataSource dataSource,
            EntityMetadata<T, ID> metadata,
            EntityCodec<T> codec,
            int maxRows,
            int queryTimeoutSeconds,
            JdbcQueryDialect dialect
    ) {
        this.dataSource = Objects.requireNonNull(dataSource, "dataSource");
        this.metadata = Objects.requireNonNull(metadata, "metadata");
        this.codec = Objects.requireNonNull(codec, "codec");
        this.maxRows = Math.max(1, maxRows);
        if (queryTimeoutSeconds <= 0) {
            throw new IllegalArgumentException("queryTimeoutSeconds must be greater than zero");
        }
        this.queryTimeoutSeconds = queryTimeoutSeconds;
        this.dialect = Objects.requireNonNull(dialect, "dialect");
        this.tableName = requireQualifiedIdentifier(metadata.tableName(), "tableName");
        this.selectColumns = validateColumns(metadata.columns());
        this.allowedColumns = new HashSet<>(selectColumns);
        this.allowedColumns.add(requireIdentifier(metadata.idColumn(), "idColumn"));
        if (metadata.versionColumn() != null && !metadata.versionColumn().isBlank()) {
            this.allowedColumns.add(requireIdentifier(metadata.versionColumn(), "versionColumn"));
        }
        if (metadata.deletedColumn() != null && !metadata.deletedColumn().isBlank()) {
            this.allowedColumns.add(requireIdentifier(metadata.deletedColumn(), "deletedColumn"));
        }
    }

    @Override
    public Optional<VersionedEntity<T>> loadVersionedById(ID id) {
        Objects.requireNonNull(id, "id");
        ArrayList<Object> parameters = new ArrayList<>();
        parameters.add(id);
        String sql = "SELECT " + selectList()
                + " FROM " + tableName
                + " WHERE " + requireAllowedColumn(metadata.idColumn()) + " = ?"
                + activePredicate(parameters)
                + " ORDER BY " + requireAllowedColumn(metadata.idColumn()) + " ASC"
                + dialect.offsetFetchClause();
        parameters.add(0);
        parameters.add(1);
        List<VersionedEntity<T>> rows = executeVersioned(sql, parameters, 1);
        return rows.isEmpty() ? Optional.empty() : Optional.of(rows.get(0));
    }

    @Override public Map<ID, String> loadTenantOwners(java.util.Collection<ID> ids) {
        if (!com.reactor.cachedb.core.tenant.CacheTenantContext.isAdministrative())
            throw new com.reactor.cachedb.core.exception.CacheTenantAccessDeniedException(metadata.entityName());
        if (metadata.tenantFieldName() == null || ids == null || ids.isEmpty() || ids.size() > 500)
            throw new IllegalArgumentException("Ownership lookup needs 1..500 identities and a tenant column");
        var requested = new LinkedHashMap<String, ID>();
        for (ID id : ids) if (requested.put(Objects.requireNonNull(id).toString(), id) != null)
            throw new IllegalArgumentException("Ownership identities must be unique");
        String sql = "SELECT " + requireAllowedColumn(metadata.idColumn()) + ", "
                + requireAllowedColumn(metadata.tenantFieldName()) + " FROM " + tableName + " WHERE "
                + requireAllowedColumn(metadata.idColumn()) + " IN (" + String.join(",", java.util.Collections.nCopies(ids.size(), "?")) + ")";
        try (var connection = dataSource.getConnection(); var statement = connection.prepareStatement(sql)) {
            statement.setQueryTimeout(queryTimeoutSeconds); statement.setMaxRows(ids.size() + 1);
            statement.setFetchSize(Math.min(128, ids.size()));
            int index = 1; for (ID id : ids) dialect.bindParameter(statement, index++, id);
            var result = new LinkedHashMap<ID, String>();
            try (var rows = statement.executeQuery()) {
                while (rows.next()) {
                    ID id = requested.get(rows.getString(1));
                    String tenant = rows.getString(2);
                    if (id == null || result.containsKey(id) || tenant == null || tenant.isBlank() || tenant.length() > 256)
                        throw new IllegalStateException("Invalid or duplicate source ownership row");
                    result.put(id, tenant);
                }
            }
            return java.util.Collections.unmodifiableMap(result);
        } catch (SQLException failure) { throw new IllegalStateException("Tenant ownership source lookup failed", failure); }
    }

    @Override
    public java.util.OptionalLong loadVersionById(ID id) {
        Objects.requireNonNull(id, "id");
        var parameters = new ArrayList<Object>();
        parameters.add(id);
        String sql = "SELECT " + requireAllowedColumn(metadata.versionColumn()) + " FROM " + tableName
                + " WHERE " + requireAllowedColumn(metadata.idColumn()) + "=?" + activePredicate(parameters);
        try (var connection = dataSource.getConnection(); var statement = connection.prepareStatement(sql)) {
            statement.setQueryTimeout(queryTimeoutSeconds);
            statement.setMaxRows(1);
            for (int i = 0; i < parameters.size(); i++) dialect.bindParameter(statement, i + 1, parameters.get(i));
            try (var rows = statement.executeQuery()) {
                if (!rows.next()) return java.util.OptionalLong.empty();
                long version = rows.getLong(1);
                if (version < 0) throw new IllegalStateException("Negative source entity version");
                return java.util.OptionalLong.of(Math.max(1, version));
            }
        } catch (SQLException failure) { throw new IllegalStateException("Source version probe failed for " + metadata.entityName(), failure); }
    }

    @Override
    public List<VersionedEntity<T>> loadVersionedPage(PageWindow pageWindow) {
        PageWindow normalized = pageWindow == null ? new PageWindow(0, Math.min(maxRows, 100)) : pageWindow;
        if (com.reactor.cachedb.core.tenant.TenantAccess.active(metadata) != null)
            return loadVersionedQuery(QuerySpec.allOf().offsetBy(normalized.offset()).limitTo(boundedLimit(normalized.pageSize()))
                    .orderBy(QuerySort.asc(metadata.idColumn())));
        int pageSize = boundedLimit(normalized.pageSize());
        ArrayList<Object> parameters = new ArrayList<>();
        String sql = "SELECT " + selectList()
                + " FROM " + tableName
                + " WHERE 1 = 1"
                + activePredicate(parameters)
                + " ORDER BY " + requireAllowedColumn(metadata.idColumn()) + " ASC"
                + dialect.offsetFetchClause();
        parameters.add(Math.max(0, normalized.offset()));
        parameters.add(pageSize);
        return executeVersioned(sql, parameters, pageSize);
    }

    @Override
    public List<VersionedEntity<T>> loadVersionedQuery(QuerySpec querySpec) {
        QuerySpec normalized = querySpec == null ? QuerySpec.builder().limit(Math.min(maxRows, 100)).build() : querySpec;
        normalized = com.reactor.cachedb.core.tenant.TenantAccess.scoped(metadata, normalized);
        int limit = boundedLimit(normalized.limit());
        ArrayList<Object> parameters = new ArrayList<>();
        String sql = "SELECT " + selectList()
                + " FROM " + tableName
                + " WHERE " + renderNode(normalized.rootGroup(), parameters)
                + activePredicate(parameters)
                + renderOrderBy(normalized.sorts())
                + dialect.offsetFetchClause();
        parameters.add(Math.max(0, normalized.offset()));
        parameters.add(limit);
        return executeVersioned(sql, parameters, limit, normalized.queryTimeoutSeconds());
    }

    private List<VersionedEntity<T>> executeVersioned(String sql, List<Object> parameters, int expectedLimit) {
        return executeVersioned(sql, parameters, expectedLimit, 0);
    }

    private List<VersionedEntity<T>> executeVersioned(
            String sql,
            List<Object> parameters,
            int expectedLimit,
            int queryTimeoutOverrideSeconds
    ) {
        int boundedExpectedLimit = boundedLimit(expectedLimit);
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setQueryTimeout(queryTimeoutOverrideSeconds > 0
                    ? queryTimeoutOverrideSeconds
                    : queryTimeoutSeconds);
            statement.setFetchSize(Math.min(boundedExpectedLimit, maxRows));
            statement.setMaxRows(boundedExpectedLimit);
            for (int index = 0; index < parameters.size(); index++) {
                dialect.bindParameter(statement, index + 1, parameters.get(index));
            }
            try (ResultSet resultSet = statement.executeQuery()) {
                ArrayList<VersionedEntity<T>> rows = new ArrayList<>(Math.min(boundedExpectedLimit, 128));
                while (resultSet.next()) {
                    if (rows.size() >= boundedExpectedLimit) {
                        throw new IllegalStateException("JDBC source loader exceeded maxRows=" + boundedExpectedLimit
                                + " for " + metadata.entityName());
                    }
                    LinkedHashMap<String, Object> columns = rowColumns(resultSet);
                    T entity = codec.fromColumns(columns);
                    com.reactor.cachedb.core.tenant.TenantAccess.verify(metadata, entity);
                    rows.add(new VersionedEntity<>(entity, versionFrom(columns)));
                }
                return List.copyOf(rows);
            }
        } catch (SQLException exception) {
            throw new IllegalStateException("JDBC source load failed for " + metadata.entityName() + ": "
                    + exception.getMessage(), exception);
        }
    }

    private long versionFrom(Map<String, Object> columns) {
        String versionColumn = metadata.versionColumn();
        if (versionColumn == null || versionColumn.isBlank()) {
            throw new IllegalStateException("JDBC source loader requires a version column for " + metadata.entityName());
        }
        boolean columnPresent = false;
        Object value = null;
        for (Map.Entry<String, Object> entry : columns.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(versionColumn)) {
                columnPresent = true;
                value = entry.getValue();
                break;
            }
        }
        if (!columnPresent) {
            throw new IllegalStateException(
                    "JDBC source row does not contain version column " + versionColumn
                            + " for " + metadata.entityName()
            );
        }
        if (value == null) {
            return 1L;
        }
        long version;
        if (value instanceof Number number) {
            version = number.longValue();
        } else {
            try {
                version = Long.parseLong(String.valueOf(value));
            } catch (NumberFormatException ignored) {
                throw invalidVersion(versionColumn, value);
            }
        }
        if (version < 0L) {
            throw invalidVersion(versionColumn, value);
        }
        // Existing SQL rows commonly have NULL/0 before CacheDB owns versioning.
        return Math.max(1L, version);
    }

    private IllegalStateException invalidVersion(String versionColumn, Object value) {
        return new IllegalStateException(
                "JDBC source row has invalid version '" + value + "' in column " + versionColumn
                        + " for " + metadata.entityName()
                        + "; expected NULL, zero, or a positive integer"
        );
    }

    private LinkedHashMap<String, Object> rowColumns(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();
        LinkedHashMap<String, Object> row = new LinkedHashMap<>(selectColumns.size());
        for (int index = 1; index <= metaData.getColumnCount(); index++) {
            String label = metaData.getColumnLabel(index);
            if (label == null || label.isBlank()) {
                label = metaData.getColumnName(index);
            }
            row.put(label, resultSet.getObject(index));
        }
        return row;
    }

    private String renderNode(QueryNode node, List<Object> parameters) {
        if (node instanceof QueryFilter filter) {
            return renderFilter(filter, parameters);
        }
        QueryGroup group = (QueryGroup) node;
        if (group.nodes().isEmpty()) {
            return "1 = 1";
        }
        StringJoiner joiner = new StringJoiner(
                group.operator().name().equals("OR") ? " OR " : " AND ",
                "(",
                ")"
        );
        for (QueryNode child : group.nodes()) {
            joiner.add(renderNode(child, parameters));
        }
        return joiner.toString();
    }

    private String renderFilter(QueryFilter filter, List<Object> parameters) {
        String column = requireAllowedColumn(filter.column());
        return switch (filter.operator()) {
            case EQ -> bind(parameters, filter.value(), column + " = ?");
            case NE -> bind(parameters, filter.value(), column + " <> ?");
            case GT -> bind(parameters, filter.value(), column + " > ?");
            case GTE -> bind(parameters, filter.value(), column + " >= ?");
            case LT -> bind(parameters, filter.value(), column + " < ?");
            case LTE -> bind(parameters, filter.value(), column + " <= ?");
            case CONTAINS -> bind(parameters, "%" + String.valueOf(filter.value()) + "%", column + " LIKE ?");
            case STARTS_WITH -> bind(parameters, String.valueOf(filter.value()) + "%", column + " LIKE ?");
            case IN -> renderInFilter(column, filter.values(), parameters);
        };
    }

    private String renderInFilter(String column, List<Object> values, List<Object> parameters) {
        if (values == null || values.isEmpty()) {
            return "1 = 0";
        }
        if (values.size() > maxRows) {
            throw new IllegalArgumentException("IN filter for " + metadata.entityName()
                    + " has " + values.size() + " values but maxRows=" + maxRows);
        }
        int chunkSize = Math.max(1, dialect.maxInListExpressions());
        StringJoiner chunks = new StringJoiner(" OR ", "(", ")");
        for (int start = 0; start < values.size(); start += chunkSize) {
            int end = Math.min(values.size(), start + chunkSize);
            StringJoiner placeholders = new StringJoiner(", ", "(", ")");
            for (int index = start; index < end; index++) {
                parameters.add(values.get(index));
                placeholders.add("?");
            }
            chunks.add(column + " IN " + placeholders);
        }
        return chunks.toString();
    }

    private String bind(List<Object> parameters, Object value, String sql) {
        parameters.add(value);
        return sql;
    }

    String renderOrderBy(List<QuerySort> sorts) {
        String idColumn = requireAllowedColumn(metadata.idColumn());
        if (sorts == null || sorts.isEmpty()) {
            return " ORDER BY " + idColumn + " ASC";
        }
        StringJoiner joiner = new StringJoiner(", ", " ORDER BY ", "");
        HashSet<String> explicitSortColumns = new HashSet<>(sorts.size());
        for (QuerySort sort : sorts) {
            String column = requireAllowedColumn(sort.column());
            String direction = sort.direction() == QuerySortDirection.DESC ? "DESC" : "ASC";
            joiner.add(column + " " + direction);
            explicitSortColumns.add(column.toLowerCase(Locale.ROOT));
        }
        if (!explicitSortColumns.contains(idColumn.toLowerCase(Locale.ROOT))) {
            joiner.add(idColumn + " ASC");
        }
        return joiner.toString();
    }

    private String activePredicate(List<Object> parameters) {
        String tenant = com.reactor.cachedb.core.tenant.TenantAccess.active(metadata);
        String tenantPredicate = "";
        if (tenant != null) {
            parameters.add(tenant);
            tenantPredicate = " AND " + requireAllowedColumn(metadata.tenantFieldName()) + " = ?";
        }
        String deletedColumn = metadata.deletedColumn();
        if (deletedColumn == null || deletedColumn.isBlank()) {
            return tenantPredicate;
        }
        parameters.add(metadata.deletedMarkerValue());
        return tenantPredicate + " AND (" + requireAllowedColumn(deletedColumn) + " IS NULL OR "
                + requireAllowedColumn(deletedColumn) + " <> ?)";
    }

    private int boundedLimit(int requestedLimit) {
        int normalized = requestedLimit <= 0 ? maxRows : requestedLimit;
        if (normalized > maxRows) {
            throw new IllegalArgumentException("JDBC source load for " + metadata.entityName()
                    + " requested " + normalized + " rows but maxRows=" + maxRows);
        }
        return Math.max(1, normalized);
    }

    private String selectList() {
        return String.join(", ", selectColumns);
    }

    private List<String> validateColumns(List<String> columns) {
        if (columns == null || columns.isEmpty()) {
            throw new IllegalArgumentException("Entity " + metadata.entityName() + " must expose at least one JDBC source column");
        }
        ArrayList<String> validated = new ArrayList<>(columns.size() + 1);
        for (String column : columns) {
            validated.add(requireIdentifier(column, "column"));
        }
        String versionColumn = requireIdentifier(metadata.versionColumn(), "versionColumn");
        if (validated.stream().noneMatch(column -> column.equalsIgnoreCase(versionColumn))) {
            validated.add(versionColumn);
        }
        return List.copyOf(validated);
    }

    private String requireAllowedColumn(String column) {
        String normalized = requireIdentifier(column, "queryColumn");
        if (!allowedColumns.contains(normalized)) {
            throw new IllegalArgumentException("Column " + normalized + " is not part of "
                    + metadata.entityName() + " metadata");
        }
        return normalized;
    }

    private static String requireIdentifier(String value, String label) {
        String normalized = value == null ? "" : value.trim();
        if (normalized.matches(IDENTIFIER)) {
            return normalized;
        }
        throw new IllegalArgumentException(label + " must be a safe SQL identifier: " + value);
    }

    private static String requireQualifiedIdentifier(String value, String label) {
        String normalized = value == null ? "" : value.trim();
        if (normalized.matches(QUALIFIED_IDENTIFIER)) {
            return normalized;
        }
        throw new IllegalArgumentException(label + " must be a safe SQL identifier: " + value);
    }
}
