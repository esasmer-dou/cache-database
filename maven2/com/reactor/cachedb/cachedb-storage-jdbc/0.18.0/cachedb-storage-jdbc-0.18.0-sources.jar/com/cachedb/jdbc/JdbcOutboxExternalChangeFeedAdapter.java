package com.reactor.cachedb.jdbc;

import com.reactor.cachedb.core.change.ExternalChangeEvent;
import com.reactor.cachedb.core.change.ExternalChangeFeedAdapter;
import com.reactor.cachedb.core.change.ExternalChangeSink;
import com.reactor.cachedb.core.change.ExternalChangeType;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import javax.sql.DataSource;

public final class JdbcOutboxExternalChangeFeedAdapter implements ExternalChangeFeedAdapter {

    private final DataSource dataSource;
    private final JdbcOutboxDialect dialect;
    private final String adapterName;
    private final JdbcOutboxPartition partition;
    private final JdbcOutboxMapping mapping;
    private final int batchSize;
    private final long pollIntervalMillis;
    private final boolean createCheckpointTable;
    private final int transactionIsolation;
    private final java.util.concurrent.locks.ReentrantLock initializationLock = new java.util.concurrent.locks.ReentrantLock();
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicBoolean checkpointTableInitialized = new AtomicBoolean(false);
    private final AtomicBoolean checkpointRowEnsured = new AtomicBoolean(false);
    private final AtomicReference<RuntimeException> lastFailure = new AtomicReference<>();
    private volatile Thread worker;

    private JdbcOutboxExternalChangeFeedAdapter(Builder builder) {
        this.dataSource = Objects.requireNonNull(builder.dataSource, "dataSource");
        this.dialect = Objects.requireNonNull(builder.dialect, "dialect");
        this.partition = builder.partition;
        String baseName = requireText(builder.adapterName, "adapterName");
        this.adapterName = partition == null ? baseName : partition.checkpointName(baseName);
        this.mapping =
                new JdbcOutboxMapping(
                        builder.outboxTable,
                        builder.checkpointTable,
                        builder.idColumn,
                        builder.entityColumn,
                        builder.entityIdColumn,
                        builder.typeColumn,
                        builder.payloadColumn,
                        builder.versionColumn,
                        builder.occurredAtColumn,
                        builder.sourceColumn);
        this.batchSize = Math.max(1, builder.batchSize);
        this.pollIntervalMillis = Math.max(50L, builder.pollIntervalMillis);
        this.createCheckpointTable = builder.createCheckpointTable;
        this.transactionIsolation =
                partition != null && !builder.transactionIsolationExplicit
                        ? Connection.TRANSACTION_READ_COMMITTED
                        : builder.transactionIsolation;
    }

    public static Builder builder(DataSource dataSource, JdbcOutboxDialect dialect) {
        return new Builder(dataSource, dialect);
    }

    @Override
    public void start(ExternalChangeSink sink) {
        Objects.requireNonNull(sink, "sink");
        if (!running.compareAndSet(false, true)) {
            return;
        }
        worker =
                new Thread(
                        () -> runLoop(sink),
                        "cachedb-" + dialect.name() + "-outbox-" + adapterName);
        worker.setDaemon(true);
        worker.start();
    }

    public int pollOnce(ExternalChangeSink sink) {
        Objects.requireNonNull(sink, "sink");
        return pollOnce(sink, 0);
    }

    private int pollOnce(ExternalChangeSink sink, int attempt) {
        boolean deliveryStarted = false;
        try {
            initialize();
            try (Connection connection = dataSource.getConnection()) {
                boolean previousAutoCommit = connection.getAutoCommit();
                int previousIsolation = connection.getTransactionIsolation();
                Exception primaryFailure = null;
                long checkpoint = 0L;
                long lastAcceptedId = 0L;
                int accepted = 0;
                boolean ensuredCheckpoint = false;
                try {
                    connection.setAutoCommit(false);
                    connection.setTransactionIsolation(transactionIsolation);
                    ensuredCheckpoint = ensureCheckpoint(connection);
                    checkpoint = readCheckpointForUpdate(connection);
                    List<OutboxRow> rows = readBatch(connection, checkpoint);
                    lastAcceptedId = checkpoint;
                    for (OutboxRow row : rows) {
                        deliveryStarted = true;
                        sink.accept(row.event());
                        lastAcceptedId = row.id();
                        accepted++;
                    }
                    if (lastAcceptedId > checkpoint) {
                        writeCheckpoint(connection, lastAcceptedId);
                    }
                    connection.commit();
                    if (ensuredCheckpoint) {
                        checkpointRowEnsured.set(true);
                    }
                } catch (SQLException | RuntimeException exception) {
                    primaryFailure = exception;
                    rollbackQuietly(connection, exception);
                    throw exception;
                } finally {
                    try {
                        restoreConnection(connection, previousIsolation, previousAutoCommit);
                    } catch (SQLException restoreFailure) {
                        if (primaryFailure == null) {
                            throw restoreFailure;
                        }
                        primaryFailure.addSuppressed(restoreFailure);
                    }
                }
                lastFailure.set(null);
                return accepted;
            }
        } catch (SQLException exception) {
            if (partition != null
                    && !deliveryStarted
                    && attempt < 3
                    && transientTransactionConflict(exception)) {
                // The failed transaction is closed and no externally visible callback ran.
                try {
                    Thread.sleep(Math.min(50L, pollIntervalMillis) * (attempt + 1));
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    throw new IllegalStateException(
                            "Interrupted during outbox checkpoint retry", interrupted);
                }
                return pollOnce(sink, attempt + 1);
            }
            RuntimeException failure =
                    new IllegalStateException(
                            dialect.name() + " outbox polling failed for adapter " + adapterName,
                            exception);
            lastFailure.set(failure);
            throw failure;
        } catch (RuntimeException exception) {
            lastFailure.set(exception);
            throw exception;
        }
    }

    private boolean transientTransactionConflict(SQLException failure) {
        return failure instanceof java.sql.SQLTransientConnectionException
                || "40001".equals(failure.getSQLState())
                || "40P01".equals(failure.getSQLState())
                || failure.getErrorCode() == 1205
                || failure.getErrorCode() == 8177
                || failure.getErrorCode() == 60;
    }

    private void rollbackQuietly(Connection connection, Exception original) {
        try {
            connection.rollback();
        } catch (SQLException rollbackFailure) {
            original.addSuppressed(rollbackFailure);
        }
    }

    private void restoreConnection(
            Connection connection, int previousIsolation, boolean previousAutoCommit)
            throws SQLException {
        SQLException failure = null;
        try {
            connection.setTransactionIsolation(previousIsolation);
        } catch (SQLException exception) {
            failure = exception;
        }
        try {
            connection.setAutoCommit(previousAutoCommit);
        } catch (SQLException exception) {
            if (failure == null) {
                failure = exception;
            } else {
                failure.addSuppressed(exception);
            }
        }
        if (failure != null) {
            throw failure;
        }
    }

    public void initialize() throws SQLException {
        if (!createCheckpointTable || checkpointTableInitialized.get()) {
            return;
        }
        initializationLock.lock();
        try {
            if (checkpointTableInitialized.get()) {
                return;
            }
            try (Connection connection = dataSource.getConnection();
                    Statement statement = connection.createStatement()) {
                statement.executeUpdate(
                        dialect.createCheckpointTableSql(mapping.checkpointTable()));
            }
            checkpointTableInitialized.set(true);
        } finally { initializationLock.unlock(); }
    }

    public RuntimeException lastFailure() {
        return lastFailure.get();
    }

    @Override
    public void close() {
        running.set(false);
        Thread currentWorker = worker;
        if (currentWorker != null) {
            currentWorker.interrupt();
            try {
                currentWorker.join(5_000L);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void runLoop(ExternalChangeSink sink) {
        while (running.get()) {
            try {
                int accepted = pollOnce(sink);
                if (accepted == 0) {
                    Thread.sleep(pollIntervalMillis);
                }
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                running.set(false);
            } catch (RuntimeException exception) {
                lastFailure.set(exception);
                sleepAfterFailure();
            }
        }
    }

    private void sleepAfterFailure() {
        try {
            Thread.sleep(pollIntervalMillis);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            running.set(false);
        }
    }

    private boolean ensureCheckpoint(Connection connection) throws SQLException {
        if (checkpointRowEnsured.get()) {
            return false;
        }
        try (PreparedStatement statement =
                connection.prepareStatement(
                        dialect.ensureCheckpointSql(mapping.checkpointTable()))) {
            statement.setQueryTimeout(30);
            dialect.bindEnsureCheckpoint(statement, adapterName);
            statement.executeUpdate();
        }
        return true;
    }

    private long readCheckpointForUpdate(Connection connection) throws SQLException {
        try (PreparedStatement statement =
                connection.prepareStatement(
                        dialect.readCheckpointForUpdateSql(mapping.checkpointTable()))) {
            statement.setQueryTimeout(30);
            statement.setString(1, adapterName);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    return 0L;
                }
                return resultSet.getLong(1);
            }
        }
    }

    private List<OutboxRow> readBatch(Connection connection, long checkpoint) throws SQLException {
        try (PreparedStatement statement =
                connection.prepareStatement(dialect.readBatchSql(mapping, batchSize, partition))) {
            statement.setQueryTimeout(30);
            dialect.bindReadBatch(statement, checkpoint, batchSize);
            try (ResultSet resultSet = statement.executeQuery()) {
                ArrayList<OutboxRow> rows = new ArrayList<>();
                while (resultSet.next()) {
                    long id = resultSet.getLong(1);
                    rows.add(
                            new OutboxRow(
                                    id,
                                    new ExternalChangeEvent(
                                            resultSet.getString(2),
                                            resultSet.getObject(3),
                                            parseType(resultSet.getString(4)),
                                            parseFlatJsonObject(resultSet.getString(5)),
                                            resultSet.getLong(6),
                                            toInstant(resultSet.getTimestamp(7)),
                                            resultSet.getString(8))));
                }
                return List.copyOf(rows);
            }
        }
    }

    private void writeCheckpoint(Connection connection, long lastEventId) throws SQLException {
        try (PreparedStatement statement =
                connection.prepareStatement(
                        dialect.writeCheckpointSql(mapping.checkpointTable()))) {
            statement.setQueryTimeout(30);
            dialect.bindWriteCheckpoint(statement, adapterName, lastEventId);
            statement.executeUpdate();
        }
    }

    private ExternalChangeType parseType(String value) {
        if (value == null || value.isBlank()) {
            return ExternalChangeType.UPSERT;
        }
        return ExternalChangeType.valueOf(value.trim().toUpperCase(java.util.Locale.ROOT));
    }

    private Instant toInstant(Timestamp timestamp) {
        return timestamp == null ? Instant.now() : timestamp.toInstant();
    }

    private static Map<String, Object> parseFlatJsonObject(String json) {
        if (json == null || json.isBlank()) {
            return Map.of();
        }
        FlatJsonParser parser = new FlatJsonParser(json);
        return parser.parseObject();
    }

    private static String requireText(String value, String name) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(name + " must not be blank");
        }
        return value.trim();
    }

    public static final class Builder {
        private final DataSource dataSource;
        private final JdbcOutboxDialect dialect;
        private String adapterName = "cachedb-outbox";
        private String outboxTable = "cachedb_outbox";
        private String checkpointTable = "cachedb_outbox_adapter_checkpoint";
        private String idColumn = "id";
        private String entityColumn = "entity_name";
        private String entityIdColumn = "entity_id";
        private String typeColumn = "event_type";
        private String payloadColumn = "payload_json";
        private String versionColumn = "entity_version";
        private String occurredAtColumn = "occurred_at";
        private String sourceColumn = "event_source";
        private int batchSize = 100;
        private long pollIntervalMillis = 1_000L;
        private boolean createCheckpointTable = true;
        private int transactionIsolation = Connection.TRANSACTION_SERIALIZABLE;
        private boolean transactionIsolationExplicit;
        private JdbcOutboxPartition partition;

        private Builder(DataSource dataSource, JdbcOutboxDialect dialect) {
            this.dataSource = dataSource;
            this.dialect = dialect;
        }

        public Builder adapterName(String adapterName) {
            this.adapterName = adapterName;
            return this;
        }

        public Builder partition(JdbcOutboxPartition partition) {
            this.partition = Objects.requireNonNull(partition, "partition");
            return this;
        }

        public Builder partition(int count, int index, String column) {
            return partition(new JdbcOutboxPartition(count, index, column));
        }

        public Builder outboxTable(String outboxTable) {
            this.outboxTable = outboxTable;
            return this;
        }

        public Builder checkpointTable(String checkpointTable) {
            this.checkpointTable = checkpointTable;
            return this;
        }

        public Builder idColumn(String idColumn) {
            this.idColumn = idColumn;
            return this;
        }

        public Builder entityColumn(String entityColumn) {
            this.entityColumn = entityColumn;
            return this;
        }

        public Builder entityIdColumn(String entityIdColumn) {
            this.entityIdColumn = entityIdColumn;
            return this;
        }

        public Builder typeColumn(String typeColumn) {
            this.typeColumn = typeColumn;
            return this;
        }

        public Builder payloadColumn(String payloadColumn) {
            this.payloadColumn = payloadColumn;
            return this;
        }

        public Builder versionColumn(String versionColumn) {
            this.versionColumn = versionColumn;
            return this;
        }

        public Builder occurredAtColumn(String occurredAtColumn) {
            this.occurredAtColumn = occurredAtColumn;
            return this;
        }

        public Builder sourceColumn(String sourceColumn) {
            this.sourceColumn = sourceColumn;
            return this;
        }

        public Builder batchSize(int batchSize) {
            this.batchSize = batchSize;
            return this;
        }

        public Builder pollIntervalMillis(long pollIntervalMillis) {
            this.pollIntervalMillis = pollIntervalMillis;
            return this;
        }

        public Builder createCheckpointTable(boolean createCheckpointTable) {
            this.createCheckpointTable = createCheckpointTable;
            return this;
        }

        public Builder transactionIsolation(int transactionIsolation) {
            if (transactionIsolation != Connection.TRANSACTION_READ_COMMITTED
                    && transactionIsolation != Connection.TRANSACTION_REPEATABLE_READ
                    && transactionIsolation != Connection.TRANSACTION_SERIALIZABLE) {
                throw new IllegalArgumentException(
                        "Unsupported JDBC outbox transaction isolation: " + transactionIsolation);
            }
            this.transactionIsolation = transactionIsolation;
            this.transactionIsolationExplicit = true;
            return this;
        }

        public JdbcOutboxExternalChangeFeedAdapter build() {
            return new JdbcOutboxExternalChangeFeedAdapter(this);
        }
    }

    private record OutboxRow(long id, ExternalChangeEvent event) {}

    private static final class FlatJsonParser {
        private final String value;
        private int index;

        private FlatJsonParser(String value) {
            this.value = value.trim();
        }

        private Map<String, Object> parseObject() {
            skipWhitespace();
            if (!consume('{')) {
                return Map.of("_payload", value);
            }
            LinkedHashMap<String, Object> values = new LinkedHashMap<>();
            skipWhitespace();
            if (consume('}')) {
                return values;
            }
            while (index < value.length()) {
                String key = parseString();
                skipWhitespace();
                if (!consume(':')) {
                    return Map.of("_payload", value);
                }
                Object parsedValue = parseValue();
                values.put(key, parsedValue);
                skipWhitespace();
                if (consume('}')) {
                    return values;
                }
                if (!consume(',')) {
                    return Map.of("_payload", value);
                }
            }
            return Map.of("_payload", value);
        }

        private Object parseValue() {
            skipWhitespace();
            if (index >= value.length()) {
                return null;
            }
            char current = value.charAt(index);
            if (current == '"') {
                return parseString();
            }
            if (startsWith("true")) {
                index += 4;
                return true;
            }
            if (startsWith("false")) {
                index += 5;
                return false;
            }
            if (startsWith("null")) {
                index += 4;
                return null;
            }
            return parseNumberOrToken();
        }

        private Object parseNumberOrToken() {
            int start = index;
            while (index < value.length()) {
                char current = value.charAt(index);
                if (current == ',' || current == '}' || Character.isWhitespace(current)) {
                    break;
                }
                index++;
            }
            String token = value.substring(start, index);
            try {
                if (token.contains(".") || token.contains("e") || token.contains("E")) {
                    return Double.parseDouble(token);
                }
                return Long.parseLong(token);
            } catch (NumberFormatException ignored) {
                return token;
            }
        }

        private String parseString() {
            if (!consume('"')) {
                return "";
            }
            StringBuilder builder = new StringBuilder();
            while (index < value.length()) {
                char current = value.charAt(index++);
                if (current == '"') {
                    return builder.toString();
                }
                if (current == '\\' && index < value.length()) {
                    char escaped = value.charAt(index++);
                    builder.append(
                            switch (escaped) {
                                case '"', '\\', '/' -> escaped;
                                case 'b' -> '\b';
                                case 'f' -> '\f';
                                case 'n' -> '\n';
                                case 'r' -> '\r';
                                case 't' -> '\t';
                                default -> escaped;
                            });
                } else {
                    builder.append(current);
                }
            }
            return builder.toString();
        }

        private boolean startsWith(String expected) {
            return value.regionMatches(index, expected, 0, expected.length());
        }

        private boolean consume(char expected) {
            skipWhitespace();
            if (index < value.length() && value.charAt(index) == expected) {
                index++;
                return true;
            }
            return false;
        }

        private void skipWhitespace() {
            while (index < value.length() && Character.isWhitespace(value.charAt(index))) {
                index++;
            }
        }
    }
}
