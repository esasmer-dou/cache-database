package com.reactor.cachedb.examples.demo.entity;

import com.reactor.cachedb.core.codec.LengthPrefixedPayloadCodec;
import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.api.EntityRepository;
import com.reactor.cachedb.core.api.ProjectionRepository;
import com.reactor.cachedb.core.api.SourceRepository;
import com.reactor.cachedb.core.active.ActiveRecordInstance;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.PageWindow;
import com.reactor.cachedb.core.plan.FetchPlan;
import com.reactor.cachedb.core.model.EntityCodec;
import com.reactor.cachedb.core.model.EntityMetadata;
import com.reactor.cachedb.core.model.WriteDependency;
import com.reactor.cachedb.core.model.WriteReceipt;
import com.reactor.cachedb.core.page.EntityPageLoader;
import com.reactor.cachedb.core.page.VersionedEntity;
import com.reactor.cachedb.core.model.RelationDefinition;
import com.reactor.cachedb.core.model.RelationKind;
import com.reactor.cachedb.core.projection.EntityProjection;
import com.reactor.cachedb.core.query.QuerySpec;
import com.reactor.cachedb.core.query.PartitionedQuerySpec;
import com.reactor.cachedb.core.query.QuerySort;
import com.reactor.cachedb.core.route.RouteCacheContract;
import com.reactor.cachedb.core.route.RouteCacheContext;
import com.reactor.cachedb.core.route.RouteCacheStrictMode;
import com.reactor.cachedb.core.relation.RelationBatchLoader;
import com.reactor.cachedb.core.relation.CompositeRelationBatchLoader;
import com.reactor.cachedb.core.relation.PartitionedRelationBatchLoader;
import com.reactor.cachedb.starter.CacheDatabase;
import com.reactor.cachedb.starter.CacheWarmPlan;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public final class DemoOrderLineEntityCacheBinding {
    public static final EntityMetadata<DemoOrderLineEntity, java.lang.Long> METADATA = new Metadata();
    public static final EntityCodec<DemoOrderLineEntity> CODEC = new Codec();
    public static final com.reactor.cachedb.core.model.SourceMapping<DemoOrderLineEntity> SOURCE = com.reactor.cachedb.core.model.SourceMapping.entity(METADATA, CODEC);

    private DemoOrderLineEntityCacheBinding() {
    }

    public static DemoOrderLineEntity withId(DemoOrderLineEntity entity, java.lang.Long id) {
        java.util.Objects.requireNonNull(entity, "entity");
        java.util.Objects.requireNonNull(id, "id");
        entity.id = id;
        return entity;
    }

    public static final class Columns {
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Long> ID = Chunk0.ID;
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Long> ORDER_ID = Chunk0.ORDER_ID;
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Long> PRODUCT_ID = Chunk0.PRODUCT_ID;
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Integer> LINE_NUMBER = Chunk0.LINE_NUMBER;
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.String> SKU = Chunk0.SKU;
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Integer> QUANTITY = Chunk0.QUANTITY;
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Double> UNIT_PRICE = Chunk0.UNIT_PRICE;
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Double> LINE_TOTAL = Chunk0.LINE_TOTAL;
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.String> STATUS = Chunk0.STATUS;
        private static final class Chunk0 {
            static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Long> ID = new com.reactor.cachedb.core.query.TypedColumn<>(DemoOrderLineEntity.class, "id", "id", java.lang.Long.class);
            static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Long> ORDER_ID = new com.reactor.cachedb.core.query.TypedColumn<>(DemoOrderLineEntity.class, "order_id", "orderId", java.lang.Long.class);
            static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Long> PRODUCT_ID = new com.reactor.cachedb.core.query.TypedColumn<>(DemoOrderLineEntity.class, "product_id", "productId", java.lang.Long.class);
            static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Integer> LINE_NUMBER = new com.reactor.cachedb.core.query.TypedColumn<>(DemoOrderLineEntity.class, "line_number", "lineNumber", java.lang.Integer.class);
            static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.String> SKU = new com.reactor.cachedb.core.query.TypedColumn<>(DemoOrderLineEntity.class, "sku", "sku", java.lang.String.class);
            static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Integer> QUANTITY = new com.reactor.cachedb.core.query.TypedColumn<>(DemoOrderLineEntity.class, "quantity", "quantity", java.lang.Integer.class);
            static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Double> UNIT_PRICE = new com.reactor.cachedb.core.query.TypedColumn<>(DemoOrderLineEntity.class, "unit_price", "unitPrice", java.lang.Double.class);
            static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.Double> LINE_TOTAL = new com.reactor.cachedb.core.query.TypedColumn<>(DemoOrderLineEntity.class, "line_total", "lineTotal", java.lang.Double.class);
            static final com.reactor.cachedb.core.query.TypedColumn<DemoOrderLineEntity, java.lang.String> STATUS = new com.reactor.cachedb.core.query.TypedColumn<>(DemoOrderLineEntity.class, "status", "status", java.lang.String.class);
        }
        private Columns() {}
    }
    private static final class Metadata implements EntityMetadata<DemoOrderLineEntity, java.lang.Long> {
        @Override
        public String entityName() {
            return "DemoOrderLineEntity";
        }

        @Override
        public String tableName() {
            return "cachedb_demo_order_lines";
        }

        @Override
        public String redisNamespace() {
            return "demo-order-lines";
        }

        @Override
        public String idColumn() {
            return "id";
        }

        @Override
        public String versionColumn() {
            return "entity_version";
        }

        @Override
        public String deletedColumn() {
            return null;
        }

        @Override
        public String activeMarkerValue() {
            return "false";
        }

        @Override
        public String deletedMarkerValue() {
            return "true";
        }

        @Override
        public Class<DemoOrderLineEntity> entityType() {
            return DemoOrderLineEntity.class;
        }

        @Override
        public Function<DemoOrderLineEntity, java.lang.Long> idAccessor() {
            return entity -> entity.id;
        }

        @Override
        public List<String> columns() {
            return List.of("id", "order_id", "product_id", "line_number", "sku", "quantity", "unit_price", "line_total", "status");
        }

        @Override
        public Map<String, String> columnTypes() {
            return COLUMN_TYPES;
        }

        public java.util.Set<String> indexedColumns() { return INDEXED_COLUMNS; }
        private static final java.util.Set<String> INDEXED_COLUMNS = java.util.Set.of("id", "line_number", "line_total", "order_id", "product_id", "quantity", "sku", "status", "unit_price");
        private static final Map<String, String> COLUMN_TYPES = createColumnTypes();
        private static Map<String, String> createColumnTypes() {
            LinkedHashMap<String, String> columnTypes = new LinkedHashMap<>();
            columnTypes.put("id", "java.lang.Long");
            columnTypes.put("order_id", "java.lang.Long");
            columnTypes.put("product_id", "java.lang.Long");
            columnTypes.put("line_number", "java.lang.Integer");
            columnTypes.put("sku", "java.lang.String");
            columnTypes.put("quantity", "java.lang.Integer");
            columnTypes.put("unit_price", "java.lang.Double");
            columnTypes.put("line_total", "java.lang.Double");
            columnTypes.put("status", "java.lang.String");
            return java.util.Collections.unmodifiableMap(columnTypes);
        }

        @Override
        public Map<String, List<String>> partitionedSortIndexes() {
            return PARTITIONED_SORT_INDEXES;
        }

        private static final Map<String, List<String>> PARTITIONED_SORT_INDEXES = createPartitionedSortIndexes();
        private static Map<String, List<String>> createPartitionedSortIndexes() {
            return Map.of();
        }

        @Override
        public List<RelationDefinition> relations() {
            return List.of();
        }
    }

    private static final class Codec implements EntityCodec<DemoOrderLineEntity> {
        public boolean directColumnAccess() { return true; }
        public Object entityColumnValue(DemoOrderLineEntity entity, String column) {
            if (column == null) return null;
            return switch (column) {
                case "id" -> entity.id;
                case "order_id" -> entity.orderId;
                case "product_id" -> entity.productId;
                case "line_number" -> entity.lineNumber;
                case "sku" -> entity.sku;
                case "quantity" -> entity.quantity;
                case "unit_price" -> entity.unitPrice;
                case "line_total" -> entity.lineTotal;
                case "status" -> entity.status;
                default -> null;
            };
        }
        public Map<String, Object> normalizePatchColumns(Map<String, Object> updates) {
            Map<String, Object> result = new LinkedHashMap<>();
            for (var entry : updates.entrySet()) {
                Object value = normalize0(entry.getKey(), entry.getValue());
                result.put(entry.getKey(), value);
            }
            return result;
        }
        private Object normalize0(String column, Object raw) {
            return switch (column) {
                case "id" -> {
                    java.lang.Long value = raw instanceof Number number ? Long.valueOf(number.longValue()) : (raw == null ? null : Long.valueOf(String.valueOf(raw)));
                    yield value;
                }
                case "order_id" -> {
                    java.lang.Long value = raw instanceof Number number ? Long.valueOf(number.longValue()) : (raw == null ? null : Long.valueOf(String.valueOf(raw)));
                    yield value;
                }
                case "product_id" -> {
                    java.lang.Long value = raw instanceof Number number ? Long.valueOf(number.longValue()) : (raw == null ? null : Long.valueOf(String.valueOf(raw)));
                    yield value;
                }
                case "line_number" -> {
                    java.lang.Integer value = raw instanceof Number number ? Integer.valueOf(number.intValue()) : (raw == null ? null : Integer.valueOf(String.valueOf(raw)));
                    yield value;
                }
                case "sku" -> {
                    java.lang.String value = raw == null ? null : String.valueOf(raw);
                    yield value;
                }
                case "quantity" -> {
                    java.lang.Integer value = raw instanceof Number number ? Integer.valueOf(number.intValue()) : (raw == null ? null : Integer.valueOf(String.valueOf(raw)));
                    yield value;
                }
                case "unit_price" -> {
                    java.lang.Double value = raw instanceof Number number ? Double.valueOf(number.doubleValue()) : (raw == null ? null : Double.valueOf(String.valueOf(raw)));
                    yield value;
                }
                case "line_total" -> {
                    java.lang.Double value = raw instanceof Number number ? Double.valueOf(number.doubleValue()) : (raw == null ? null : Double.valueOf(String.valueOf(raw)));
                    yield value;
                }
                case "status" -> {
                    java.lang.String value = raw == null ? null : String.valueOf(raw);
                    yield value;
                }
                default -> throw new IllegalArgumentException("Unknown patch column: " + column);
            };
        }
        @Override
        public String toRedisValue(DemoOrderLineEntity entity) {
            StringBuilder payload = new StringBuilder();
            LengthPrefixedPayloadCodec.appendField(payload, "2:id", entity.id == null ? null : String.valueOf(entity.id));
            LengthPrefixedPayloadCodec.appendField(payload, "8:order_id", entity.orderId == null ? null : String.valueOf(entity.orderId));
            LengthPrefixedPayloadCodec.appendField(payload, "10:product_id", entity.productId == null ? null : String.valueOf(entity.productId));
            LengthPrefixedPayloadCodec.appendField(payload, "11:line_number", entity.lineNumber == null ? null : String.valueOf(entity.lineNumber));
            LengthPrefixedPayloadCodec.appendField(payload, "3:sku", entity.sku);
            LengthPrefixedPayloadCodec.appendField(payload, "8:quantity", entity.quantity == null ? null : String.valueOf(entity.quantity));
            LengthPrefixedPayloadCodec.appendField(payload, "10:unit_price", entity.unitPrice == null ? null : String.valueOf(entity.unitPrice));
            LengthPrefixedPayloadCodec.appendField(payload, "10:line_total", entity.lineTotal == null ? null : String.valueOf(entity.lineTotal));
            LengthPrefixedPayloadCodec.appendField(payload, "6:status", entity.status);
            return payload.toString();
        }

        @Override
        public DemoOrderLineEntity fromRedisValue(String encoded) {
            String value0 = null;
            String value1 = null;
            String value2 = null;
            String value3 = null;
            String value4 = null;
            String value5 = null;
            String value6 = null;
            String value7 = null;
            String value8 = null;
            var cursor = LengthPrefixedPayloadCodec.cursor(encoded);
            while (cursor.next()) {
                String column = cursor.name();
                if (column == null) continue;
                switch (column) {
                    case "id" -> value0 = cursor.value();
                    case "order_id" -> value1 = cursor.value();
                    case "product_id" -> value2 = cursor.value();
                    case "line_number" -> value3 = cursor.value();
                    case "sku" -> value4 = cursor.value();
                    case "quantity" -> value5 = cursor.value();
                    case "unit_price" -> value6 = cursor.value();
                    case "line_total" -> value7 = cursor.value();
                    case "status" -> value8 = cursor.value();
                    default -> { }
                }
            }
            DemoOrderLineEntity entity = new DemoOrderLineEntity();
            entity.id = value0 == null ? null : Long.valueOf(value0);
            entity.orderId = value1 == null ? null : Long.valueOf(value1);
            entity.productId = value2 == null ? null : Long.valueOf(value2);
            entity.lineNumber = value3 == null ? null : Integer.valueOf(value3);
            entity.sku = value4;
            entity.quantity = value5 == null ? null : Integer.valueOf(value5);
            entity.unitPrice = value6 == null ? null : Double.valueOf(value6);
            entity.lineTotal = value7 == null ? null : Double.valueOf(value7);
            entity.status = value8;
            return entity;
        }

        @Override
        public DemoOrderLineEntity fromColumns(Map<String, Object> columns) {
            DemoOrderLineEntity entity = new DemoOrderLineEntity();
            entity.id = columnValue(columns, "id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "id"))));
            entity.orderId = columnValue(columns, "order_id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "order_id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "order_id"))));
            entity.productId = columnValue(columns, "product_id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "product_id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "product_id"))));
            entity.lineNumber = columnValue(columns, "line_number") instanceof Number number ? Integer.valueOf(number.intValue()) : (columnValue(columns, "line_number") == null ? null : Integer.valueOf(String.valueOf(columnValue(columns, "line_number"))));
            entity.sku = columnValue(columns, "sku") == null ? null : String.valueOf(columnValue(columns, "sku"));
            entity.quantity = columnValue(columns, "quantity") instanceof Number number ? Integer.valueOf(number.intValue()) : (columnValue(columns, "quantity") == null ? null : Integer.valueOf(String.valueOf(columnValue(columns, "quantity"))));
            entity.unitPrice = columnValue(columns, "unit_price") instanceof Number number ? Double.valueOf(number.doubleValue()) : (columnValue(columns, "unit_price") == null ? null : Double.valueOf(String.valueOf(columnValue(columns, "unit_price"))));
            entity.lineTotal = columnValue(columns, "line_total") instanceof Number number ? Double.valueOf(number.doubleValue()) : (columnValue(columns, "line_total") == null ? null : Double.valueOf(String.valueOf(columnValue(columns, "line_total"))));
            entity.status = columnValue(columns, "status") == null ? null : String.valueOf(columnValue(columns, "status"));
            return entity;
        }

        @Override
        public Map<String, Object> toColumns(DemoOrderLineEntity entity) {
            LinkedHashMap<String, Object> columns = new LinkedHashMap<>();
            columns.put("id", entity.id);
            columns.put("order_id", entity.orderId);
            columns.put("product_id", entity.productId);
            columns.put("line_number", entity.lineNumber);
            columns.put("sku", entity.sku);
            columns.put("quantity", entity.quantity);
            columns.put("unit_price", entity.unitPrice);
            columns.put("line_total", entity.lineTotal);
            columns.put("status", entity.status);
            return columns;
        }
    }

    public static com.reactor.cachedb.core.projection.EntityProjection<com.reactor.cachedb.examples.demo.entity.DemoOrderLineEntity,com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel,java.lang.Long> orderLinePreviewProjection() {
        return DemoOrderLineEntity.orderLinePreviewProjection();
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel, java.lang.Long> orderLinePreview(CacheSession session) {
        return repository(session).projected(orderLinePreviewProjection());
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel, java.lang.Long> orderLinePreview(CacheSession session, CachePolicy cachePolicy) {
        return repository(session, cachePolicy).projected(orderLinePreviewProjection());
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel, java.lang.Long> orderLinePreview(EntityRepository<DemoOrderLineEntity, java.lang.Long> repository) {
        return repository.projected(orderLinePreviewProjection());
    }

    public static QuerySpec previewLinesForOrdersQuery(java.util.List<java.lang.Long> orderIds, int totalLimit) {
        return DemoOrderLineEntity.previewLinesForOrdersQuery(orderIds, totalLimit);
    }

    public static List<DemoOrderLineEntity> previewLinesForOrders(CacheSession cacheSession, java.util.List<java.lang.Long> orderIds, int totalLimit) {
        return repository(cacheSession).query(previewLinesForOrdersQuery(orderIds, totalLimit));
    }

    public static List<DemoOrderLineEntity> previewLinesForOrders(CacheSession cacheSession, CachePolicy cachePolicy, java.util.List<java.lang.Long> orderIds, int totalLimit) {
        return repository(cacheSession, cachePolicy).query(previewLinesForOrdersQuery(orderIds, totalLimit));
    }

    public static List<DemoOrderLineEntity> previewLinesForOrders(EntityRepository<DemoOrderLineEntity, java.lang.Long> entityRepository, java.util.List<java.lang.Long> orderIds, int totalLimit) {
        return entityRepository.query(previewLinesForOrdersQuery(orderIds, totalLimit));
    }

    public static <P> List<P> previewLinesForOrders(ProjectionRepository<P, java.lang.Long> projectionRepository, java.util.List<java.lang.Long> orderIds, int totalLimit) {
        return projectionRepository.query(previewLinesForOrdersQuery(orderIds, totalLimit));
    }

    public static EntityRepository<DemoOrderLineEntity, java.lang.Long> repository(CacheSession session) {
        return session.repository(METADATA, CODEC);
    }

    public static EntityRepository<DemoOrderLineEntity, java.lang.Long> repository(CacheSession session, CachePolicy cachePolicy) {
        return session.repository(METADATA, CODEC, cachePolicy);
    }

    public static void register(CacheDatabase cacheDatabase) {
        cacheDatabase.register(METADATA, CODEC);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase) {
        registerJdbcBacked(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void registerJdbcSource(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void registerDeclaredLoaders(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader, EntityPageLoader<DemoOrderLineEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader, EntityPageLoader<DemoOrderLineEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader, EntityPageLoader<DemoOrderLineEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader, EntityPageLoader<DemoOrderLineEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
        return CacheWarmPlan.builder(METADATA.entityName())
                .name(name)
                .querySpec(querySpec)
                .maxRows(maxRows)
                .build();
    }

    public static ActiveRecordInstance<DemoOrderLineEntity, java.lang.Long> attach(CacheSession session, DemoOrderLineEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session));
    }

    public static ActiveRecordInstance<DemoOrderLineEntity, java.lang.Long> attach(CacheSession session, CachePolicy cachePolicy, DemoOrderLineEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session, cachePolicy));
    }

    public static DemoOrderLineEntity save(CacheSession session, DemoOrderLineEntity entity) {
        return repository(session).save(entity);
    }

    public static DemoOrderLineEntity save(CacheSession session, CachePolicy cachePolicy, DemoOrderLineEntity entity) {
        return repository(session, cachePolicy).save(entity);
    }

    public static Optional<DemoOrderLineEntity> findById(CacheSession session, java.lang.Long id) {
        return repository(session).findById(id);
    }

    public static Optional<DemoOrderLineEntity> findById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        return repository(session, cachePolicy).findById(id);
    }

    public static List<DemoOrderLineEntity> findPage(CacheSession session, PageWindow pageWindow) {
        return repository(session).findPage(pageWindow);
    }

    public static List<DemoOrderLineEntity> findPage(CacheSession session, CachePolicy cachePolicy, PageWindow pageWindow) {
        return repository(session, cachePolicy).findPage(pageWindow);
    }

    public static List<DemoOrderLineEntity> query(CacheSession session, QuerySpec querySpec) {
        return repository(session).query(querySpec);
    }

    public static List<DemoOrderLineEntity> query(CacheSession session, CachePolicy cachePolicy, QuerySpec querySpec) {
        return repository(session, cachePolicy).query(querySpec);
    }

    public static void deleteById(CacheSession session, java.lang.Long id) {
        repository(session).deleteById(id);
    }

    public static void deleteById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        repository(session, cachePolicy).deleteById(id);
    }

    public static Scope using(CacheSession session) {
        return new Scope(session, null);
    }

    public static Scope using(CacheSession session, CachePolicy cachePolicy) {
        return new Scope(session, cachePolicy);
    }

    public static final class Scope {
        private final CacheSession cacheSession;
        private final EntityRepository<DemoOrderLineEntity, java.lang.Long> repository;
        private volatile SourceRepository<DemoOrderLineEntity, java.lang.Long> sourceRepository;
        private final Queries queries;
        private final Projections projections;

        private Scope(CacheSession cacheSession, CachePolicy cachePolicy) {
            this.cacheSession = cacheSession;
            this.repository = cachePolicy == null ? DemoOrderLineEntityCacheBinding.repository(cacheSession) : DemoOrderLineEntityCacheBinding.repository(cacheSession, cachePolicy);
            this.queries = new Queries(this);
            this.projections = new Projections(this);
        }

        public EntityRepository<DemoOrderLineEntity, java.lang.Long> repository() {
            return repository;
        }

        public ActiveRecordInstance<DemoOrderLineEntity, java.lang.Long> attach(DemoOrderLineEntity entity) {
            return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository);
        }

        public DemoOrderLineEntity save(DemoOrderLineEntity entity) {
            return repository.save(entity);
        }

        public WriteReceipt<DemoOrderLineEntity, java.lang.Long> saveWithReceipt(DemoOrderLineEntity entity) {
            return repository.saveWithReceipt(entity);
        }

        public WriteReceipt<DemoOrderLineEntity, java.lang.Long> save(DemoOrderLineEntity entity, long expectedVersion) {
            return repository.save(entity, expectedVersion);
        }

        public WriteReceipt<DemoOrderLineEntity, java.lang.Long> saveAfter(DemoOrderLineEntity entity, WriteDependency dependency) {
            return repository.saveAfter(entity, dependency);
        }

        public List<WriteReceipt<DemoOrderLineEntity, java.lang.Long>> saveAll(java.util.Collection<DemoOrderLineEntity> entities) {
            return repository.saveAll(entities);
        }

        public Optional<DemoOrderLineEntity> findById(java.lang.Long id) {
            return repository.findById(id);
        }

        public Optional<VersionedEntity<DemoOrderLineEntity>> findVersionedById(java.lang.Long id) {
            return repository.findVersionedById(id);
        }

        public Optional<WriteDependency> dependency(java.lang.Long id) {
            return repository.findVersionedById(id).map(versioned -> new WriteDependency(METADATA.redisNamespace(), String.valueOf(id), versioned.version()));
        }

        public List<DemoOrderLineEntity> findPage(PageWindow pageWindow) {
            return repository.findPage(pageWindow);
        }

        public List<DemoOrderLineEntity> query(QuerySpec querySpec) {
            return repository.query(querySpec);
        }

        public <K> Map<K, List<DemoOrderLineEntity>> queryPartitions(PartitionedQuerySpec<K> querySpec) {
            return repository.queryPartitions(querySpec);
        }

        public SourceRepository<DemoOrderLineEntity, java.lang.Long> source() {
            SourceRepository<DemoOrderLineEntity, java.lang.Long> resolved = sourceRepository;
            if (resolved == null) {
                synchronized (this) {
                    resolved = sourceRepository;
                    if (resolved == null) {
                        resolved = cacheSession.sourceRepository(METADATA, CODEC);
                        sourceRepository = resolved;
                    }
                }
            }
            return resolved;
        }

        public void deleteById(java.lang.Long id) {
            repository.deleteById(id);
        }

        public CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
            return DemoOrderLineEntityCacheBinding.warmPlan(name, querySpec, maxRows);
        }

        public Queries queries() {
            return queries;
        }

        public Projections projections() {
            return projections;
        }
    }

    public static final class Queries {
        private final Scope scope;

        private Queries(Scope scope) {
            this.scope = scope;
        }

        public QuerySpec previewLinesForOrdersQuery(java.util.List<java.lang.Long> orderIds, int totalLimit) {
            return DemoOrderLineEntityCacheBinding.previewLinesForOrdersQuery(orderIds, totalLimit);
        }

        public List<DemoOrderLineEntity> previewLinesForOrders(java.util.List<java.lang.Long> orderIds, int totalLimit) {
            return scope.repository().query(previewLinesForOrdersQuery(orderIds, totalLimit));
        }
    }

    public static final class Projections {
        private final Scope scope;
        private volatile ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel, java.lang.Long> orderLinePreview;

        private Projections(Scope scope) {
            this.scope = scope;
        }

        public com.reactor.cachedb.core.projection.EntityProjection<com.reactor.cachedb.examples.demo.entity.DemoOrderLineEntity,com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel,java.lang.Long> orderLinePreviewProjection() {
            return DemoOrderLineEntityCacheBinding.orderLinePreviewProjection();
        }

        public ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel, java.lang.Long> orderLinePreview() {
            ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel, java.lang.Long> resolved = orderLinePreview;
            if (resolved == null) {
                synchronized (this) {
                    resolved = orderLinePreview;
                    if (resolved == null) {
                        resolved = scope.repository().projected(orderLinePreviewProjection());
                        orderLinePreview = resolved;
                    }
                }
            }
            return resolved;
        }
    }
}
