package com.reactor.cachedb.examples.demo.entity;

import com.reactor.cachedb.core.codec.LengthPrefixedPayloadCodec;
import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.api.EntityRepository;
import com.reactor.cachedb.core.api.ProjectionRepository;
import com.reactor.cachedb.core.api.SourceRepository;
import com.reactor.cachedb.core.active.ActiveRecordInstance;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.PageWindow;
import com.reactor.cachedb.core.plan.FetchPlan;
import com.reactor.cachedb.core.model.EntityCodec;
import com.reactor.cachedb.core.model.EntityMetadata;
import com.reactor.cachedb.core.model.WriteDependency;
import com.reactor.cachedb.core.model.WriteReceipt;
import com.reactor.cachedb.core.page.EntityPageLoader;
import com.reactor.cachedb.core.page.VersionedEntity;
import com.reactor.cachedb.core.model.RelationDefinition;
import com.reactor.cachedb.core.model.RelationKind;
import com.reactor.cachedb.core.projection.EntityProjection;
import com.reactor.cachedb.core.query.QuerySpec;
import com.reactor.cachedb.core.query.PartitionedQuerySpec;
import com.reactor.cachedb.core.query.QuerySort;
import com.reactor.cachedb.core.route.RouteCacheContract;
import com.reactor.cachedb.core.route.RouteCacheContext;
import com.reactor.cachedb.core.route.RouteCacheStrictMode;
import com.reactor.cachedb.core.relation.RelationBatchLoader;
import com.reactor.cachedb.core.relation.CompositeRelationBatchLoader;
import com.reactor.cachedb.core.relation.PartitionedRelationBatchLoader;
import com.reactor.cachedb.starter.CacheDatabase;
import com.reactor.cachedb.starter.CacheWarmPlan;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public final class DemoProductEntityCacheBinding {
    public static final EntityMetadata<DemoProductEntity, java.lang.Long> METADATA = new Metadata();
    public static final EntityCodec<DemoProductEntity> CODEC = new Codec();
    public static final com.reactor.cachedb.core.model.SourceMapping<DemoProductEntity> SOURCE = com.reactor.cachedb.core.model.SourceMapping.entity(METADATA, CODEC);

    private DemoProductEntityCacheBinding() {
    }

    public static DemoProductEntity withId(DemoProductEntity entity, java.lang.Long id) {
        java.util.Objects.requireNonNull(entity, "entity");
        java.util.Objects.requireNonNull(id, "id");
        entity.id = id;
        return entity;
    }

    public static final class Columns {
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoProductEntity, java.lang.Long> ID = Chunk0.ID;
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoProductEntity, java.lang.String> SKU = Chunk0.SKU;
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoProductEntity, java.lang.String> CATEGORY = Chunk0.CATEGORY;
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoProductEntity, java.lang.Double> PRICE = Chunk0.PRICE;
        public static final com.reactor.cachedb.core.query.TypedColumn<DemoProductEntity, java.lang.Integer> STOCK = Chunk0.STOCK;
        private static final class Chunk0 {
            static final com.reactor.cachedb.core.query.TypedColumn<DemoProductEntity, java.lang.Long> ID = new com.reactor.cachedb.core.query.TypedColumn<>(DemoProductEntity.class, "id", "id", java.lang.Long.class);
            static final com.reactor.cachedb.core.query.TypedColumn<DemoProductEntity, java.lang.String> SKU = new com.reactor.cachedb.core.query.TypedColumn<>(DemoProductEntity.class, "sku", "sku", java.lang.String.class);
            static final com.reactor.cachedb.core.query.TypedColumn<DemoProductEntity, java.lang.String> CATEGORY = new com.reactor.cachedb.core.query.TypedColumn<>(DemoProductEntity.class, "category", "category", java.lang.String.class);
            static final com.reactor.cachedb.core.query.TypedColumn<DemoProductEntity, java.lang.Double> PRICE = new com.reactor.cachedb.core.query.TypedColumn<>(DemoProductEntity.class, "price", "price", java.lang.Double.class);
            static final com.reactor.cachedb.core.query.TypedColumn<DemoProductEntity, java.lang.Integer> STOCK = new com.reactor.cachedb.core.query.TypedColumn<>(DemoProductEntity.class, "stock", "stock", java.lang.Integer.class);
        }
        private Columns() {}
    }
    private static final class Metadata implements EntityMetadata<DemoProductEntity, java.lang.Long> {
        public int compressionThresholdBytes() { return 0; }
        @Override
        public String entityName() {
            return "DemoProductEntity";
        }

        @Override
        public String tableName() {
            return "cachedb_demo_products";
        }

        @Override
        public String redisNamespace() {
            return "demo-products";
        }

        @Override
        public String idColumn() {
            return "id";
        }

        @Override
        public String versionColumn() {
            return "entity_version";
        }

        @Override
        public String deletedColumn() {
            return null;
        }

        @Override
        public String activeMarkerValue() {
            return "false";
        }

        @Override
        public String deletedMarkerValue() {
            return "true";
        }

        @Override
        public Class<DemoProductEntity> entityType() {
            return DemoProductEntity.class;
        }

        @Override
        public Function<DemoProductEntity, java.lang.Long> idAccessor() {
            return entity -> entity.id;
        }

        @Override
        public List<String> columns() {
            return List.of("id", "sku", "category", "price", "stock");
        }

        @Override
        public Map<String, String> columnTypes() {
            return COLUMN_TYPES;
        }

        public java.util.Set<String> indexedColumns() { return INDEXED_COLUMNS; }
        private static final java.util.Set<String> INDEXED_COLUMNS = java.util.Set.of("category", "id", "price", "sku", "stock");
        private static final Map<String, String> COLUMN_TYPES = createColumnTypes();
        private static Map<String, String> createColumnTypes() {
            LinkedHashMap<String, String> columnTypes = new LinkedHashMap<>();
            columnTypes.put("id", "java.lang.Long");
            columnTypes.put("sku", "java.lang.String");
            columnTypes.put("category", "java.lang.String");
            columnTypes.put("price", "java.lang.Double");
            columnTypes.put("stock", "java.lang.Integer");
            return java.util.Collections.unmodifiableMap(columnTypes);
        }

        @Override
        public Map<String, List<String>> partitionedSortIndexes() {
            return PARTITIONED_SORT_INDEXES;
        }

        private static final Map<String, List<String>> PARTITIONED_SORT_INDEXES = createPartitionedSortIndexes();
        private static Map<String, List<String>> createPartitionedSortIndexes() {
            return Map.of();
        }

        @Override
        public List<RelationDefinition> relations() {
            return List.of();
        }
    }

    private static final class Codec implements EntityCodec<DemoProductEntity> {
        public boolean directColumnAccess() { return true; }
        public Object entityColumnValue(DemoProductEntity entity, String column) {
            if (column == null) return null;
            return switch (column) {
                case "id" -> entity.id;
                case "sku" -> entity.sku;
                case "category" -> entity.category;
                case "price" -> entity.price;
                case "stock" -> entity.stock;
                default -> null;
            };
        }
        public Map<String, Object> normalizePatchColumns(Map<String, Object> updates) {
            Map<String, Object> result = new LinkedHashMap<>();
            for (var entry : updates.entrySet()) {
                Object value = normalize0(entry.getKey(), entry.getValue());
                result.put(entry.getKey(), value);
            }
            return result;
        }
        private Object normalize0(String column, Object raw) {
            return switch (column) {
                case "id" -> {
                    java.lang.Long value = raw instanceof Number number ? Long.valueOf(number.longValue()) : (raw == null ? null : Long.valueOf(String.valueOf(raw)));
                    yield value;
                }
                case "sku" -> {
                    java.lang.String value = raw == null ? null : String.valueOf(raw);
                    yield value;
                }
                case "category" -> {
                    java.lang.String value = raw == null ? null : String.valueOf(raw);
                    yield value;
                }
                case "price" -> {
                    java.lang.Double value = raw instanceof Number number ? Double.valueOf(number.doubleValue()) : (raw == null ? null : Double.valueOf(String.valueOf(raw)));
                    yield value;
                }
                case "stock" -> {
                    java.lang.Integer value = raw instanceof Number number ? Integer.valueOf(number.intValue()) : (raw == null ? null : Integer.valueOf(String.valueOf(raw)));
                    yield value;
                }
                default -> throw new IllegalArgumentException("Unknown patch column: " + column);
            };
        }
        @Override
        public String toRedisValue(DemoProductEntity entity) {
            StringBuilder payload = new StringBuilder();
            LengthPrefixedPayloadCodec.appendField(payload, "2:id", entity.id == null ? null : String.valueOf(entity.id));
            LengthPrefixedPayloadCodec.appendField(payload, "3:sku", entity.sku);
            LengthPrefixedPayloadCodec.appendField(payload, "8:category", entity.category);
            LengthPrefixedPayloadCodec.appendField(payload, "5:price", entity.price == null ? null : String.valueOf(entity.price));
            LengthPrefixedPayloadCodec.appendField(payload, "5:stock", entity.stock == null ? null : String.valueOf(entity.stock));
            return payload.toString();
        }

        @Override
        public DemoProductEntity fromRedisValue(String encoded) {
            String value0 = null;
            String value1 = null;
            String value2 = null;
            String value3 = null;
            String value4 = null;
            var cursor = LengthPrefixedPayloadCodec.cursor(encoded);
            while (cursor.next()) {
                String column = cursor.name();
                if (column == null) continue;
                switch (column) {
                    case "id" -> value0 = cursor.value();
                    case "sku" -> value1 = cursor.value();
                    case "category" -> value2 = cursor.value();
                    case "price" -> value3 = cursor.value();
                    case "stock" -> value4 = cursor.value();
                    default -> { }
                }
            }
            DemoProductEntity entity = new DemoProductEntity();
            entity.id = value0 == null ? null : Long.valueOf(value0);
            entity.sku = value1;
            entity.category = value2;
            entity.price = value3 == null ? null : Double.valueOf(value3);
            entity.stock = value4 == null ? null : Integer.valueOf(value4);
            return entity;
        }

        @Override
        public DemoProductEntity fromColumns(Map<String, Object> columns) {
            DemoProductEntity entity = new DemoProductEntity();
            entity.id = columnValue(columns, "id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "id"))));
            entity.sku = columnValue(columns, "sku") == null ? null : String.valueOf(columnValue(columns, "sku"));
            entity.category = columnValue(columns, "category") == null ? null : String.valueOf(columnValue(columns, "category"));
            entity.price = columnValue(columns, "price") instanceof Number number ? Double.valueOf(number.doubleValue()) : (columnValue(columns, "price") == null ? null : Double.valueOf(String.valueOf(columnValue(columns, "price"))));
            entity.stock = columnValue(columns, "stock") instanceof Number number ? Integer.valueOf(number.intValue()) : (columnValue(columns, "stock") == null ? null : Integer.valueOf(String.valueOf(columnValue(columns, "stock"))));
            return entity;
        }

        @Override
        public Map<String, Object> toColumns(DemoProductEntity entity) {
            LinkedHashMap<String, Object> columns = new LinkedHashMap<>();
            columns.put("id", entity.id);
            columns.put("sku", entity.sku);
            columns.put("category", entity.category);
            columns.put("price", entity.price);
            columns.put("stock", entity.stock);
            return columns;
        }
    }

    public static EntityRepository<DemoProductEntity, java.lang.Long> repository(CacheSession session) {
        return session.repository(METADATA, CODEC);
    }

    public static EntityRepository<DemoProductEntity, java.lang.Long> repository(CacheSession session, CachePolicy cachePolicy) {
        return session.repository(METADATA, CODEC, cachePolicy);
    }

    public static void register(CacheDatabase cacheDatabase) {
        cacheDatabase.register(METADATA, CODEC);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase) {
        registerJdbcBacked(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
    }

    public static void registerJdbcSource(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
    }

    public static void registerDeclaredLoaders(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<DemoProductEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoProductEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<DemoProductEntity> relationBatchLoader, EntityPageLoader<DemoProductEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoProductEntity> relationBatchLoader, EntityPageLoader<DemoProductEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<DemoProductEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoProductEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<DemoProductEntity> relationBatchLoader, EntityPageLoader<DemoProductEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoProductEntity> relationBatchLoader, EntityPageLoader<DemoProductEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
    }

    public static CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
        return CacheWarmPlan.builder(METADATA.entityName())
                .name(name)
                .querySpec(querySpec)
                .maxRows(maxRows)
                .build();
    }

    public static ActiveRecordInstance<DemoProductEntity, java.lang.Long> attach(CacheSession session, DemoProductEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session));
    }

    public static ActiveRecordInstance<DemoProductEntity, java.lang.Long> attach(CacheSession session, CachePolicy cachePolicy, DemoProductEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session, cachePolicy));
    }

    public static DemoProductEntity save(CacheSession session, DemoProductEntity entity) {
        return repository(session).save(entity);
    }

    public static DemoProductEntity save(CacheSession session, CachePolicy cachePolicy, DemoProductEntity entity) {
        return repository(session, cachePolicy).save(entity);
    }

    public static Optional<DemoProductEntity> findById(CacheSession session, java.lang.Long id) {
        return repository(session).findById(id);
    }

    public static Optional<DemoProductEntity> findById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        return repository(session, cachePolicy).findById(id);
    }

    public static List<DemoProductEntity> findPage(CacheSession session, PageWindow pageWindow) {
        return repository(session).findPage(pageWindow);
    }

    public static List<DemoProductEntity> findPage(CacheSession session, CachePolicy cachePolicy, PageWindow pageWindow) {
        return repository(session, cachePolicy).findPage(pageWindow);
    }

    public static List<DemoProductEntity> query(CacheSession session, QuerySpec querySpec) {
        return repository(session).query(querySpec);
    }

    public static List<DemoProductEntity> query(CacheSession session, CachePolicy cachePolicy, QuerySpec querySpec) {
        return repository(session, cachePolicy).query(querySpec);
    }

    public static void deleteById(CacheSession session, java.lang.Long id) {
        repository(session).deleteById(id);
    }

    public static void deleteById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        repository(session, cachePolicy).deleteById(id);
    }

    public static Scope using(CacheSession session) {
        return new Scope(session, null);
    }

    public static Scope using(CacheSession session, CachePolicy cachePolicy) {
        return new Scope(session, cachePolicy);
    }

    public static final class Scope {
        private final CacheSession cacheSession;
        private final EntityRepository<DemoProductEntity, java.lang.Long> repository;
        private volatile SourceRepository<DemoProductEntity, java.lang.Long> sourceRepository;

        private Scope(CacheSession cacheSession, CachePolicy cachePolicy) {
            this.cacheSession = cacheSession;
            this.repository = cachePolicy == null ? DemoProductEntityCacheBinding.repository(cacheSession) : DemoProductEntityCacheBinding.repository(cacheSession, cachePolicy);
        }

        public EntityRepository<DemoProductEntity, java.lang.Long> repository() {
            return repository;
        }

        public ActiveRecordInstance<DemoProductEntity, java.lang.Long> attach(DemoProductEntity entity) {
            return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository);
        }

        public DemoProductEntity save(DemoProductEntity entity) {
            return repository.save(entity);
        }

        public WriteReceipt<DemoProductEntity, java.lang.Long> saveWithReceipt(DemoProductEntity entity) {
            return repository.saveWithReceipt(entity);
        }

        public WriteReceipt<DemoProductEntity, java.lang.Long> save(DemoProductEntity entity, long expectedVersion) {
            return repository.save(entity, expectedVersion);
        }

        public WriteReceipt<DemoProductEntity, java.lang.Long> saveAfter(DemoProductEntity entity, WriteDependency dependency) {
            return repository.saveAfter(entity, dependency);
        }

        public List<WriteReceipt<DemoProductEntity, java.lang.Long>> saveAll(java.util.Collection<DemoProductEntity> entities) {
            return repository.saveAll(entities);
        }

        public Optional<DemoProductEntity> findById(java.lang.Long id) {
            return repository.findById(id);
        }

        public Optional<VersionedEntity<DemoProductEntity>> findVersionedById(java.lang.Long id) {
            return repository.findVersionedById(id);
        }

        public Optional<WriteDependency> dependency(java.lang.Long id) {
            return repository.findVersionedById(id).map(versioned -> new WriteDependency(METADATA.redisNamespace(), String.valueOf(id), versioned.version()));
        }

        public List<DemoProductEntity> findPage(PageWindow pageWindow) {
            return repository.findPage(pageWindow);
        }

        public List<DemoProductEntity> query(QuerySpec querySpec) {
            return repository.query(querySpec);
        }

        public <K> Map<K, List<DemoProductEntity>> queryPartitions(PartitionedQuerySpec<K> querySpec) {
            return repository.queryPartitions(querySpec);
        }

        public SourceRepository<DemoProductEntity, java.lang.Long> source() {
            SourceRepository<DemoProductEntity, java.lang.Long> resolved = sourceRepository;
            if (resolved == null) {
                synchronized (this) {
                    resolved = sourceRepository;
                    if (resolved == null) {
                        resolved = cacheSession.sourceRepository(METADATA, CODEC);
                        sourceRepository = resolved;
                    }
                }
            }
            return resolved;
        }

        public void deleteById(java.lang.Long id) {
            repository.deleteById(id);
        }

        public CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
            return DemoProductEntityCacheBinding.warmPlan(name, querySpec, maxRows);
        }
    }
}
