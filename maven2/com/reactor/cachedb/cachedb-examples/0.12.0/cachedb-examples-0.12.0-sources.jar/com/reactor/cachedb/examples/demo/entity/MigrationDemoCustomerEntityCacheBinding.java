package com.reactor.cachedb.examples.demo.entity;

import com.reactor.cachedb.core.codec.LengthPrefixedPayloadCodec;
import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.api.EntityRepository;
import com.reactor.cachedb.core.api.ProjectionRepository;
import com.reactor.cachedb.core.api.SourceRepository;
import com.reactor.cachedb.core.active.ActiveRecordInstance;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.PageWindow;
import com.reactor.cachedb.core.plan.FetchPlan;
import com.reactor.cachedb.core.model.EntityCodec;
import com.reactor.cachedb.core.model.EntityMetadata;
import com.reactor.cachedb.core.model.WriteDependency;
import com.reactor.cachedb.core.model.WriteReceipt;
import com.reactor.cachedb.core.page.EntityPageLoader;
import com.reactor.cachedb.core.page.VersionedEntity;
import com.reactor.cachedb.core.model.RelationDefinition;
import com.reactor.cachedb.core.model.RelationKind;
import com.reactor.cachedb.core.projection.EntityProjection;
import com.reactor.cachedb.core.query.QuerySpec;
import com.reactor.cachedb.core.query.PartitionedQuerySpec;
import com.reactor.cachedb.core.query.QuerySort;
import com.reactor.cachedb.core.route.RouteCacheContract;
import com.reactor.cachedb.core.route.RouteCacheContext;
import com.reactor.cachedb.core.route.RouteCacheStrictMode;
import com.reactor.cachedb.core.relation.RelationBatchLoader;
import com.reactor.cachedb.core.relation.CompositeRelationBatchLoader;
import com.reactor.cachedb.core.relation.PartitionedRelationBatchLoader;
import com.reactor.cachedb.starter.CacheDatabase;
import com.reactor.cachedb.starter.CacheWarmPlan;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public final class MigrationDemoCustomerEntityCacheBinding {
    public static final EntityMetadata<MigrationDemoCustomerEntity, java.lang.Long> METADATA = new Metadata();
    public static final EntityCodec<MigrationDemoCustomerEntity> CODEC = new Codec();
    public static final com.reactor.cachedb.core.model.SourceMapping<MigrationDemoCustomerEntity> SOURCE = com.reactor.cachedb.core.model.SourceMapping.entity(METADATA, CODEC);

    private MigrationDemoCustomerEntityCacheBinding() {
    }

    public static MigrationDemoCustomerEntity withId(MigrationDemoCustomerEntity entity, java.lang.Long id) {
        java.util.Objects.requireNonNull(entity, "entity");
        java.util.Objects.requireNonNull(id, "id");
        entity.customerId = id;
        return entity;
    }

    private static final class Metadata implements EntityMetadata<MigrationDemoCustomerEntity, java.lang.Long> {
        @Override
        public String entityName() {
            return "MigrationDemoCustomerEntity";
        }

        @Override
        public String tableName() {
            return "cachedb_migration_demo_customers";
        }

        @Override
        public String redisNamespace() {
            return "migration-demo-customers";
        }

        @Override
        public String idColumn() {
            return "customer_id";
        }

        @Override
        public String versionColumn() {
            return "entity_version";
        }

        @Override
        public String deletedColumn() {
            return null;
        }

        @Override
        public String activeMarkerValue() {
            return "false";
        }

        @Override
        public String deletedMarkerValue() {
            return "true";
        }

        @Override
        public Class<MigrationDemoCustomerEntity> entityType() {
            return MigrationDemoCustomerEntity.class;
        }

        @Override
        public Function<MigrationDemoCustomerEntity, java.lang.Long> idAccessor() {
            return entity -> entity.customerId;
        }

        @Override
        public List<String> columns() {
            return List.of("customer_id", "tax_number", "customer_type", "customer_status", "country_code", "created_at");
        }

        @Override
        public Map<String, String> columnTypes() {
            LinkedHashMap<String, String> columnTypes = new LinkedHashMap<>();
            columnTypes.put("customer_id", "java.lang.Long");
            columnTypes.put("tax_number", "java.lang.String");
            columnTypes.put("customer_type", "java.lang.String");
            columnTypes.put("customer_status", "java.lang.String");
            columnTypes.put("country_code", "java.lang.String");
            columnTypes.put("created_at", "java.time.Instant");
            return columnTypes;
        }

        @Override
        public Map<String, List<String>> partitionedSortIndexes() {
            return Map.of();
        }

        @Override
        public List<RelationDefinition> relations() {
            return List.of();
        }
    }

    private static final class Codec implements EntityCodec<MigrationDemoCustomerEntity> {
        @Override
        public String toRedisValue(MigrationDemoCustomerEntity entity) {
            LinkedHashMap<String, String> values = new LinkedHashMap<>();
            values.put("customer_id", entity.customerId == null ? null : String.valueOf(entity.customerId));
            values.put("tax_number", entity.taxNumber);
            values.put("customer_type", entity.customerType);
            values.put("customer_status", entity.customerStatus);
            values.put("country_code", entity.countryCode);
            values.put("created_at", entity.createdAt == null ? null : String.valueOf(entity.createdAt));
            return LengthPrefixedPayloadCodec.encode(values);
        }

        @Override
        public MigrationDemoCustomerEntity fromRedisValue(String encoded) {
            Map<String, String> values = LengthPrefixedPayloadCodec.decode(encoded);
            MigrationDemoCustomerEntity entity = new MigrationDemoCustomerEntity();
            entity.customerId = values.get("customer_id") == null ? null : Long.valueOf(values.get("customer_id"));
            entity.taxNumber = values.get("tax_number");
            entity.customerType = values.get("customer_type");
            entity.customerStatus = values.get("customer_status");
            entity.countryCode = values.get("country_code");
            entity.createdAt = values.get("created_at") == null ? null : java.time.Instant.parse(values.get("created_at"));
            return entity;
        }

        @Override
        public MigrationDemoCustomerEntity fromColumns(Map<String, Object> columns) {
            MigrationDemoCustomerEntity entity = new MigrationDemoCustomerEntity();
            entity.customerId = columnValue(columns, "customer_id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "customer_id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "customer_id"))));
            entity.taxNumber = columnValue(columns, "tax_number") == null ? null : String.valueOf(columnValue(columns, "tax_number"));
            entity.customerType = columnValue(columns, "customer_type") == null ? null : String.valueOf(columnValue(columns, "customer_type"));
            entity.customerStatus = columnValue(columns, "customer_status") == null ? null : String.valueOf(columnValue(columns, "customer_status"));
            entity.countryCode = columnValue(columns, "country_code") == null ? null : String.valueOf(columnValue(columns, "country_code"));
            entity.createdAt = columnValue(columns, "created_at") instanceof java.time.Instant instant ? instant : (columnValue(columns, "created_at") instanceof java.sql.Timestamp timestamp ? timestamp.toInstant() : (columnValue(columns, "created_at") instanceof java.time.OffsetDateTime offsetDateTime ? offsetDateTime.toInstant() : (columnValue(columns, "created_at") == null ? null : java.time.Instant.parse(String.valueOf(columnValue(columns, "created_at"))))));
            return entity;
        }

        @Override
        public Map<String, Object> toColumns(MigrationDemoCustomerEntity entity) {
            LinkedHashMap<String, Object> columns = new LinkedHashMap<>();
            columns.put("customer_id", entity.customerId);
            columns.put("tax_number", entity.taxNumber);
            columns.put("customer_type", entity.customerType);
            columns.put("customer_status", entity.customerStatus);
            columns.put("country_code", entity.countryCode);
            columns.put("created_at", entity.createdAt);
            return columns;
        }
    }

    public static EntityRepository<MigrationDemoCustomerEntity, java.lang.Long> repository(CacheSession session) {
        return session.repository(METADATA, CODEC);
    }

    public static EntityRepository<MigrationDemoCustomerEntity, java.lang.Long> repository(CacheSession session, CachePolicy cachePolicy) {
        return session.repository(METADATA, CODEC, cachePolicy);
    }

    public static void register(CacheDatabase cacheDatabase) {
        cacheDatabase.register(METADATA, CODEC);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase) {
        registerJdbcBacked(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
    }

    public static void registerJdbcSource(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
    }

    public static void registerDeclaredLoaders(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<MigrationDemoCustomerEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<MigrationDemoCustomerEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<MigrationDemoCustomerEntity> relationBatchLoader, EntityPageLoader<MigrationDemoCustomerEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<MigrationDemoCustomerEntity> relationBatchLoader, EntityPageLoader<MigrationDemoCustomerEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<MigrationDemoCustomerEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<MigrationDemoCustomerEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<MigrationDemoCustomerEntity> relationBatchLoader, EntityPageLoader<MigrationDemoCustomerEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<MigrationDemoCustomerEntity> relationBatchLoader, EntityPageLoader<MigrationDemoCustomerEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
    }

    public static CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
        return CacheWarmPlan.builder(METADATA.entityName())
                .name(name)
                .querySpec(querySpec)
                .maxRows(maxRows)
                .build();
    }

    public static ActiveRecordInstance<MigrationDemoCustomerEntity, java.lang.Long> attach(CacheSession session, MigrationDemoCustomerEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session));
    }

    public static ActiveRecordInstance<MigrationDemoCustomerEntity, java.lang.Long> attach(CacheSession session, CachePolicy cachePolicy, MigrationDemoCustomerEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session, cachePolicy));
    }

    public static MigrationDemoCustomerEntity save(CacheSession session, MigrationDemoCustomerEntity entity) {
        return repository(session).save(entity);
    }

    public static MigrationDemoCustomerEntity save(CacheSession session, CachePolicy cachePolicy, MigrationDemoCustomerEntity entity) {
        return repository(session, cachePolicy).save(entity);
    }

    public static Optional<MigrationDemoCustomerEntity> findById(CacheSession session, java.lang.Long id) {
        return repository(session).findById(id);
    }

    public static Optional<MigrationDemoCustomerEntity> findById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        return repository(session, cachePolicy).findById(id);
    }

    public static List<MigrationDemoCustomerEntity> findPage(CacheSession session, PageWindow pageWindow) {
        return repository(session).findPage(pageWindow);
    }

    public static List<MigrationDemoCustomerEntity> findPage(CacheSession session, CachePolicy cachePolicy, PageWindow pageWindow) {
        return repository(session, cachePolicy).findPage(pageWindow);
    }

    public static List<MigrationDemoCustomerEntity> query(CacheSession session, QuerySpec querySpec) {
        return repository(session).query(querySpec);
    }

    public static List<MigrationDemoCustomerEntity> query(CacheSession session, CachePolicy cachePolicy, QuerySpec querySpec) {
        return repository(session, cachePolicy).query(querySpec);
    }

    public static void deleteById(CacheSession session, java.lang.Long id) {
        repository(session).deleteById(id);
    }

    public static void deleteById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        repository(session, cachePolicy).deleteById(id);
    }

    public static Scope using(CacheSession session) {
        return new Scope(session, null);
    }

    public static Scope using(CacheSession session, CachePolicy cachePolicy) {
        return new Scope(session, cachePolicy);
    }

    public static final class Scope {
        private final CacheSession cacheSession;
        private final EntityRepository<MigrationDemoCustomerEntity, java.lang.Long> repository;
        private volatile SourceRepository<MigrationDemoCustomerEntity, java.lang.Long> sourceRepository;

        private Scope(CacheSession cacheSession, CachePolicy cachePolicy) {
            this.cacheSession = cacheSession;
            this.repository = cachePolicy == null ? MigrationDemoCustomerEntityCacheBinding.repository(cacheSession) : MigrationDemoCustomerEntityCacheBinding.repository(cacheSession, cachePolicy);
        }

        public EntityRepository<MigrationDemoCustomerEntity, java.lang.Long> repository() {
            return repository;
        }

        public ActiveRecordInstance<MigrationDemoCustomerEntity, java.lang.Long> attach(MigrationDemoCustomerEntity entity) {
            return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository);
        }

        public MigrationDemoCustomerEntity save(MigrationDemoCustomerEntity entity) {
            return repository.save(entity);
        }

        public WriteReceipt<MigrationDemoCustomerEntity, java.lang.Long> saveWithReceipt(MigrationDemoCustomerEntity entity) {
            return repository.saveWithReceipt(entity);
        }

        public WriteReceipt<MigrationDemoCustomerEntity, java.lang.Long> save(MigrationDemoCustomerEntity entity, long expectedVersion) {
            return repository.save(entity, expectedVersion);
        }

        public WriteReceipt<MigrationDemoCustomerEntity, java.lang.Long> saveAfter(MigrationDemoCustomerEntity entity, WriteDependency dependency) {
            return repository.saveAfter(entity, dependency);
        }

        public List<WriteReceipt<MigrationDemoCustomerEntity, java.lang.Long>> saveAll(java.util.Collection<MigrationDemoCustomerEntity> entities) {
            return repository.saveAll(entities);
        }

        public Optional<MigrationDemoCustomerEntity> findById(java.lang.Long id) {
            return repository.findById(id);
        }

        public Optional<VersionedEntity<MigrationDemoCustomerEntity>> findVersionedById(java.lang.Long id) {
            return repository.findVersionedById(id);
        }

        public Optional<WriteDependency> dependency(java.lang.Long id) {
            return repository.findVersionedById(id).map(versioned -> new WriteDependency(METADATA.redisNamespace(), String.valueOf(id), versioned.version()));
        }

        public List<MigrationDemoCustomerEntity> findPage(PageWindow pageWindow) {
            return repository.findPage(pageWindow);
        }

        public List<MigrationDemoCustomerEntity> query(QuerySpec querySpec) {
            return repository.query(querySpec);
        }

        public <K> Map<K, List<MigrationDemoCustomerEntity>> queryPartitions(PartitionedQuerySpec<K> querySpec) {
            return repository.queryPartitions(querySpec);
        }

        public SourceRepository<MigrationDemoCustomerEntity, java.lang.Long> source() {
            SourceRepository<MigrationDemoCustomerEntity, java.lang.Long> resolved = sourceRepository;
            if (resolved == null) {
                synchronized (this) {
                    resolved = sourceRepository;
                    if (resolved == null) {
                        resolved = cacheSession.sourceRepository(METADATA, CODEC);
                        sourceRepository = resolved;
                    }
                }
            }
            return resolved;
        }

        public void deleteById(java.lang.Long id) {
            repository.deleteById(id);
        }

        public CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
            return MigrationDemoCustomerEntityCacheBinding.warmPlan(name, querySpec, maxRows);
        }
    }
}
