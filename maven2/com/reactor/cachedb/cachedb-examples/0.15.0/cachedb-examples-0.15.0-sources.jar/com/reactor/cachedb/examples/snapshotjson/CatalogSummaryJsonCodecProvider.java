package com.reactor.cachedb.examples.snapshotjson;
public final class CatalogSummaryJsonCodecProvider implements com.reactor.cachedb.core.codec.GeneratedJsonCodecProvider {
 public com.reactor.cachedb.core.codec.JsonArrayCodec<?> codecFor(Class<?> type) { return type == com.reactor.cachedb.examples.snapshotjson.CatalogSummary.class ? CatalogSummaryJsonCodec.INSTANCE : null; }
}
