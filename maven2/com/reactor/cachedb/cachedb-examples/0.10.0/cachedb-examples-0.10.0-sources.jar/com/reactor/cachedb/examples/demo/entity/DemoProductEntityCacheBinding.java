package com.reactor.cachedb.examples.demo.entity;

import com.reactor.cachedb.core.codec.LengthPrefixedPayloadCodec;
import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.api.EntityRepository;
import com.reactor.cachedb.core.api.ProjectionRepository;
import com.reactor.cachedb.core.api.SourceRepository;
import com.reactor.cachedb.core.active.ActiveRecordInstance;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.PageWindow;
import com.reactor.cachedb.core.plan.FetchPlan;
import com.reactor.cachedb.core.model.EntityCodec;
import com.reactor.cachedb.core.model.EntityMetadata;
import com.reactor.cachedb.core.model.WriteDependency;
import com.reactor.cachedb.core.model.WriteReceipt;
import com.reactor.cachedb.core.page.EntityPageLoader;
import com.reactor.cachedb.core.page.VersionedEntity;
import com.reactor.cachedb.core.model.RelationDefinition;
import com.reactor.cachedb.core.model.RelationKind;
import com.reactor.cachedb.core.projection.EntityProjection;
import com.reactor.cachedb.core.query.QuerySpec;
import com.reactor.cachedb.core.query.PartitionedQuerySpec;
import com.reactor.cachedb.core.query.QuerySort;
import com.reactor.cachedb.core.route.RouteCacheContract;
import com.reactor.cachedb.core.route.RouteCacheContext;
import com.reactor.cachedb.core.route.RouteCacheStrictMode;
import com.reactor.cachedb.core.relation.RelationBatchLoader;
import com.reactor.cachedb.core.relation.CompositeRelationBatchLoader;
import com.reactor.cachedb.core.relation.PartitionedRelationBatchLoader;
import com.reactor.cachedb.starter.CacheDatabase;
import com.reactor.cachedb.starter.CacheWarmPlan;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public final class DemoProductEntityCacheBinding {
    public static final EntityMetadata<DemoProductEntity, java.lang.Long> METADATA = new Metadata();
    public static final EntityCodec<DemoProductEntity> CODEC = new Codec();

    private DemoProductEntityCacheBinding() {
    }

    public static DemoProductEntity withId(DemoProductEntity entity, java.lang.Long id) {
        java.util.Objects.requireNonNull(entity, "entity");
        java.util.Objects.requireNonNull(id, "id");
        entity.id = id;
        return entity;
    }

    private static final class Metadata implements EntityMetadata<DemoProductEntity, java.lang.Long> {
        @Override
        public String entityName() {
            return "DemoProductEntity";
        }

        @Override
        public String tableName() {
            return "cachedb_demo_products";
        }

        @Override
        public String redisNamespace() {
            return "demo-products";
        }

        @Override
        public String idColumn() {
            return "id";
        }

        @Override
        public String versionColumn() {
            return "entity_version";
        }

        @Override
        public String deletedColumn() {
            return null;
        }

        @Override
        public String activeMarkerValue() {
            return "false";
        }

        @Override
        public String deletedMarkerValue() {
            return "true";
        }

        @Override
        public Class<DemoProductEntity> entityType() {
            return DemoProductEntity.class;
        }

        @Override
        public Function<DemoProductEntity, java.lang.Long> idAccessor() {
            return entity -> entity.id;
        }

        @Override
        public List<String> columns() {
            return List.of("id", "sku", "category", "price", "stock");
        }

        @Override
        public Map<String, String> columnTypes() {
            LinkedHashMap<String, String> columnTypes = new LinkedHashMap<>();
            columnTypes.put("id", "java.lang.Long");
            columnTypes.put("sku", "java.lang.String");
            columnTypes.put("category", "java.lang.String");
            columnTypes.put("price", "java.lang.Double");
            columnTypes.put("stock", "java.lang.Integer");
            return columnTypes;
        }

        @Override
        public Map<String, List<String>> partitionedSortIndexes() {
            return Map.of();
        }

        @Override
        public List<RelationDefinition> relations() {
            return List.of();
        }
    }

    private static final class Codec implements EntityCodec<DemoProductEntity> {
        @Override
        public String toRedisValue(DemoProductEntity entity) {
            LinkedHashMap<String, String> values = new LinkedHashMap<>();
            values.put("id", entity.id == null ? null : String.valueOf(entity.id));
            values.put("sku", entity.sku);
            values.put("category", entity.category);
            values.put("price", entity.price == null ? null : String.valueOf(entity.price));
            values.put("stock", entity.stock == null ? null : String.valueOf(entity.stock));
            return LengthPrefixedPayloadCodec.encode(values);
        }

        @Override
        public DemoProductEntity fromRedisValue(String encoded) {
            Map<String, String> values = LengthPrefixedPayloadCodec.decode(encoded);
            DemoProductEntity entity = new DemoProductEntity();
            entity.id = values.get("id") == null ? null : Long.valueOf(values.get("id"));
            entity.sku = values.get("sku");
            entity.category = values.get("category");
            entity.price = values.get("price") == null ? null : Double.valueOf(values.get("price"));
            entity.stock = values.get("stock") == null ? null : Integer.valueOf(values.get("stock"));
            return entity;
        }

        @Override
        public DemoProductEntity fromColumns(Map<String, Object> columns) {
            DemoProductEntity entity = new DemoProductEntity();
            entity.id = columnValue(columns, "id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "id"))));
            entity.sku = columnValue(columns, "sku") == null ? null : String.valueOf(columnValue(columns, "sku"));
            entity.category = columnValue(columns, "category") == null ? null : String.valueOf(columnValue(columns, "category"));
            entity.price = columnValue(columns, "price") instanceof Number number ? Double.valueOf(number.doubleValue()) : (columnValue(columns, "price") == null ? null : Double.valueOf(String.valueOf(columnValue(columns, "price"))));
            entity.stock = columnValue(columns, "stock") instanceof Number number ? Integer.valueOf(number.intValue()) : (columnValue(columns, "stock") == null ? null : Integer.valueOf(String.valueOf(columnValue(columns, "stock"))));
            return entity;
        }

        @Override
        public Map<String, Object> toColumns(DemoProductEntity entity) {
            LinkedHashMap<String, Object> columns = new LinkedHashMap<>();
            columns.put("id", entity.id);
            columns.put("sku", entity.sku);
            columns.put("category", entity.category);
            columns.put("price", entity.price);
            columns.put("stock", entity.stock);
            return columns;
        }
    }

    public static EntityRepository<DemoProductEntity, java.lang.Long> repository(CacheSession session) {
        return session.repository(METADATA, CODEC);
    }

    public static EntityRepository<DemoProductEntity, java.lang.Long> repository(CacheSession session, CachePolicy cachePolicy) {
        return session.repository(METADATA, CODEC, cachePolicy);
    }

    public static void register(CacheDatabase cacheDatabase) {
        cacheDatabase.register(METADATA, CODEC);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase) {
        registerJdbcBacked(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
    }

    public static void registerJdbcSource(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
    }

    public static void registerDeclaredLoaders(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<DemoProductEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoProductEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<DemoProductEntity> relationBatchLoader, EntityPageLoader<DemoProductEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoProductEntity> relationBatchLoader, EntityPageLoader<DemoProductEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<DemoProductEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoProductEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<DemoProductEntity> relationBatchLoader, EntityPageLoader<DemoProductEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoProductEntity> relationBatchLoader, EntityPageLoader<DemoProductEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
    }

    public static CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
        return CacheWarmPlan.builder(METADATA.entityName())
                .name(name)
                .querySpec(querySpec)
                .maxRows(maxRows)
                .build();
    }

    public static ActiveRecordInstance<DemoProductEntity, java.lang.Long> attach(CacheSession session, DemoProductEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session));
    }

    public static ActiveRecordInstance<DemoProductEntity, java.lang.Long> attach(CacheSession session, CachePolicy cachePolicy, DemoProductEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session, cachePolicy));
    }

    public static DemoProductEntity save(CacheSession session, DemoProductEntity entity) {
        return repository(session).save(entity);
    }

    public static DemoProductEntity save(CacheSession session, CachePolicy cachePolicy, DemoProductEntity entity) {
        return repository(session, cachePolicy).save(entity);
    }

    public static Optional<DemoProductEntity> findById(CacheSession session, java.lang.Long id) {
        return repository(session).findById(id);
    }

    public static Optional<DemoProductEntity> findById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        return repository(session, cachePolicy).findById(id);
    }

    public static List<DemoProductEntity> findPage(CacheSession session, PageWindow pageWindow) {
        return repository(session).findPage(pageWindow);
    }

    public static List<DemoProductEntity> findPage(CacheSession session, CachePolicy cachePolicy, PageWindow pageWindow) {
        return repository(session, cachePolicy).findPage(pageWindow);
    }

    public static List<DemoProductEntity> query(CacheSession session, QuerySpec querySpec) {
        return repository(session).query(querySpec);
    }

    public static List<DemoProductEntity> query(CacheSession session, CachePolicy cachePolicy, QuerySpec querySpec) {
        return repository(session, cachePolicy).query(querySpec);
    }

    public static void deleteById(CacheSession session, java.lang.Long id) {
        repository(session).deleteById(id);
    }

    public static void deleteById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        repository(session, cachePolicy).deleteById(id);
    }

    public static Scope using(CacheSession session) {
        return new Scope(session, null);
    }

    public static Scope using(CacheSession session, CachePolicy cachePolicy) {
        return new Scope(session, cachePolicy);
    }

    public static final class Scope {
        private final CacheSession cacheSession;
        private final EntityRepository<DemoProductEntity, java.lang.Long> repository;
        private volatile SourceRepository<DemoProductEntity, java.lang.Long> sourceRepository;

        private Scope(CacheSession cacheSession, CachePolicy cachePolicy) {
            this.cacheSession = cacheSession;
            this.repository = cachePolicy == null ? DemoProductEntityCacheBinding.repository(cacheSession) : DemoProductEntityCacheBinding.repository(cacheSession, cachePolicy);
        }

        public EntityRepository<DemoProductEntity, java.lang.Long> repository() {
            return repository;
        }

        public ActiveRecordInstance<DemoProductEntity, java.lang.Long> attach(DemoProductEntity entity) {
            return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository);
        }

        public DemoProductEntity save(DemoProductEntity entity) {
            return repository.save(entity);
        }

        public WriteReceipt<DemoProductEntity, java.lang.Long> saveWithReceipt(DemoProductEntity entity) {
            return repository.saveWithReceipt(entity);
        }

        public WriteReceipt<DemoProductEntity, java.lang.Long> save(DemoProductEntity entity, long expectedVersion) {
            return repository.save(entity, expectedVersion);
        }

        public WriteReceipt<DemoProductEntity, java.lang.Long> saveAfter(DemoProductEntity entity, WriteDependency dependency) {
            return repository.saveAfter(entity, dependency);
        }

        public List<WriteReceipt<DemoProductEntity, java.lang.Long>> saveAll(java.util.Collection<DemoProductEntity> entities) {
            return repository.saveAll(entities);
        }

        public Optional<DemoProductEntity> findById(java.lang.Long id) {
            return repository.findById(id);
        }

        public Optional<VersionedEntity<DemoProductEntity>> findVersionedById(java.lang.Long id) {
            return repository.findVersionedById(id);
        }

        public Optional<WriteDependency> dependency(java.lang.Long id) {
            return repository.findVersionedById(id).map(versioned -> new WriteDependency(METADATA.redisNamespace(), String.valueOf(id), versioned.version()));
        }

        public List<DemoProductEntity> findPage(PageWindow pageWindow) {
            return repository.findPage(pageWindow);
        }

        public List<DemoProductEntity> query(QuerySpec querySpec) {
            return repository.query(querySpec);
        }

        public <K> Map<K, List<DemoProductEntity>> queryPartitions(PartitionedQuerySpec<K> querySpec) {
            return repository.queryPartitions(querySpec);
        }

        public SourceRepository<DemoProductEntity, java.lang.Long> source() {
            SourceRepository<DemoProductEntity, java.lang.Long> resolved = sourceRepository;
            if (resolved == null) {
                synchronized (this) {
                    resolved = sourceRepository;
                    if (resolved == null) {
                        resolved = cacheSession.sourceRepository(METADATA, CODEC);
                        sourceRepository = resolved;
                    }
                }
            }
            return resolved;
        }

        public void deleteById(java.lang.Long id) {
            repository.deleteById(id);
        }

        public CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
            return DemoProductEntityCacheBinding.warmPlan(name, querySpec, maxRows);
        }
    }
}
