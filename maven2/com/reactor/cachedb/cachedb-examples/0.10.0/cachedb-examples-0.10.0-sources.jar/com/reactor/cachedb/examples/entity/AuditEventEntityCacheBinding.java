package com.reactor.cachedb.examples.entity;

import com.reactor.cachedb.core.codec.LengthPrefixedPayloadCodec;
import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.api.EntityRepository;
import com.reactor.cachedb.core.api.ProjectionRepository;
import com.reactor.cachedb.core.api.SourceRepository;
import com.reactor.cachedb.core.active.ActiveRecordInstance;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.PageWindow;
import com.reactor.cachedb.core.plan.FetchPlan;
import com.reactor.cachedb.core.model.EntityCodec;
import com.reactor.cachedb.core.model.EntityMetadata;
import com.reactor.cachedb.core.model.WriteDependency;
import com.reactor.cachedb.core.model.WriteReceipt;
import com.reactor.cachedb.core.page.EntityPageLoader;
import com.reactor.cachedb.core.page.VersionedEntity;
import com.reactor.cachedb.core.model.RelationDefinition;
import com.reactor.cachedb.core.model.RelationKind;
import com.reactor.cachedb.core.projection.EntityProjection;
import com.reactor.cachedb.core.query.QuerySpec;
import com.reactor.cachedb.core.query.PartitionedQuerySpec;
import com.reactor.cachedb.core.query.QuerySort;
import com.reactor.cachedb.core.route.RouteCacheContract;
import com.reactor.cachedb.core.route.RouteCacheContext;
import com.reactor.cachedb.core.route.RouteCacheStrictMode;
import com.reactor.cachedb.core.relation.RelationBatchLoader;
import com.reactor.cachedb.core.relation.CompositeRelationBatchLoader;
import com.reactor.cachedb.core.relation.PartitionedRelationBatchLoader;
import com.reactor.cachedb.starter.CacheDatabase;
import com.reactor.cachedb.starter.CacheWarmPlan;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public final class AuditEventEntityCacheBinding {
    public static final EntityMetadata<AuditEventEntity, java.lang.Long> METADATA = new Metadata();
    public static final EntityCodec<AuditEventEntity> CODEC = new Codec();

    private static final com.reactor.cachedb.examples.codec.TagValueCodec TAGVALUE_CODEC = new com.reactor.cachedb.examples.codec.TagValueCodec();

    private AuditEventEntityCacheBinding() {
    }

    public static AuditEventEntity withId(AuditEventEntity entity, java.lang.Long id) {
        java.util.Objects.requireNonNull(entity, "entity");
        java.util.Objects.requireNonNull(id, "id");
        entity.id = id;
        return entity;
    }

    private static final class Metadata implements EntityMetadata<AuditEventEntity, java.lang.Long> {
        @Override
        public String entityName() {
            return "AuditEventEntity";
        }

        @Override
        public String tableName() {
            return "cachedb_example_audit_events";
        }

        @Override
        public String redisNamespace() {
            return "audit-events";
        }

        @Override
        public String idColumn() {
            return "id";
        }

        @Override
        public String versionColumn() {
            return "entity_version";
        }

        @Override
        public String deletedColumn() {
            return null;
        }

        @Override
        public String activeMarkerValue() {
            return "false";
        }

        @Override
        public String deletedMarkerValue() {
            return "true";
        }

        @Override
        public Class<AuditEventEntity> entityType() {
            return AuditEventEntity.class;
        }

        @Override
        public Function<AuditEventEntity, java.lang.Long> idAccessor() {
            return entity -> entity.id;
        }

        @Override
        public List<String> columns() {
            return List.of("id", "account_state", "created_at", "tag_value");
        }

        @Override
        public Map<String, String> columnTypes() {
            LinkedHashMap<String, String> columnTypes = new LinkedHashMap<>();
            columnTypes.put("id", "java.lang.Long");
            columnTypes.put("account_state", "java.lang.String");
            columnTypes.put("created_at", "java.time.Instant");
            columnTypes.put("tag_value", "java.lang.String");
            return columnTypes;
        }

        @Override
        public Map<String, List<String>> partitionedSortIndexes() {
            return Map.of();
        }

        @Override
        public List<RelationDefinition> relations() {
            return List.of();
        }
    }

    private static final class Codec implements EntityCodec<AuditEventEntity> {
        @Override
        public String toRedisValue(AuditEventEntity entity) {
            LinkedHashMap<String, String> values = new LinkedHashMap<>();
            values.put("id", entity.id == null ? null : String.valueOf(entity.id));
            values.put("account_state", entity.accountState == null ? null : entity.accountState.name());
            values.put("created_at", entity.createdAt == null ? null : String.valueOf(entity.createdAt));
            values.put("tag_value", TAGVALUE_CODEC.encode(entity.tagValue));
            return LengthPrefixedPayloadCodec.encode(values);
        }

        @Override
        public AuditEventEntity fromRedisValue(String encoded) {
            Map<String, String> values = LengthPrefixedPayloadCodec.decode(encoded);
            AuditEventEntity entity = new AuditEventEntity();
            entity.id = values.get("id") == null ? null : Long.valueOf(values.get("id"));
            entity.accountState = values.get("account_state") == null ? null : com.reactor.cachedb.examples.entity.AccountState.valueOf(values.get("account_state"));
            entity.createdAt = values.get("created_at") == null ? null : java.time.Instant.parse(values.get("created_at"));
            entity.tagValue = TAGVALUE_CODEC.decode(values.get("tag_value"));
            return entity;
        }

        @Override
        public AuditEventEntity fromColumns(Map<String, Object> columns) {
            AuditEventEntity entity = new AuditEventEntity();
            entity.id = columnValue(columns, "id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "id"))));
            entity.accountState = columnValue(columns, "account_state") == null ? null : com.reactor.cachedb.examples.entity.AccountState.valueOf(String.valueOf(columnValue(columns, "account_state")));
            entity.createdAt = columnValue(columns, "created_at") instanceof java.time.Instant instant ? instant : (columnValue(columns, "created_at") instanceof java.sql.Timestamp timestamp ? timestamp.toInstant() : (columnValue(columns, "created_at") instanceof java.time.OffsetDateTime offsetDateTime ? offsetDateTime.toInstant() : (columnValue(columns, "created_at") == null ? null : java.time.Instant.parse(String.valueOf(columnValue(columns, "created_at"))))));
            entity.tagValue = columnValue(columns, "tag_value") == null ? null : TAGVALUE_CODEC.decode(String.valueOf(columnValue(columns, "tag_value")));
            return entity;
        }

        @Override
        public Map<String, Object> toColumns(AuditEventEntity entity) {
            LinkedHashMap<String, Object> columns = new LinkedHashMap<>();
            columns.put("id", entity.id);
            columns.put("account_state", entity.accountState == null ? null : entity.accountState.name());
            columns.put("created_at", entity.createdAt);
            columns.put("tag_value", TAGVALUE_CODEC.toColumnValue(entity.tagValue));
            return columns;
        }
    }

    public static EntityRepository<AuditEventEntity, java.lang.Long> repository(CacheSession session) {
        return session.repository(METADATA, CODEC);
    }

    public static EntityRepository<AuditEventEntity, java.lang.Long> repository(CacheSession session, CachePolicy cachePolicy) {
        return session.repository(METADATA, CODEC, cachePolicy);
    }

    public static void register(CacheDatabase cacheDatabase) {
        cacheDatabase.register(METADATA, CODEC);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase) {
        registerJdbcBacked(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
    }

    public static void registerJdbcSource(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
    }

    public static void registerDeclaredLoaders(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<AuditEventEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<AuditEventEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<AuditEventEntity> relationBatchLoader, EntityPageLoader<AuditEventEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<AuditEventEntity> relationBatchLoader, EntityPageLoader<AuditEventEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<AuditEventEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<AuditEventEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<AuditEventEntity> relationBatchLoader, EntityPageLoader<AuditEventEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<AuditEventEntity> relationBatchLoader, EntityPageLoader<AuditEventEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
    }

    public static CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
        return CacheWarmPlan.builder(METADATA.entityName())
                .name(name)
                .querySpec(querySpec)
                .maxRows(maxRows)
                .build();
    }

    public static ActiveRecordInstance<AuditEventEntity, java.lang.Long> attach(CacheSession session, AuditEventEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session));
    }

    public static ActiveRecordInstance<AuditEventEntity, java.lang.Long> attach(CacheSession session, CachePolicy cachePolicy, AuditEventEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session, cachePolicy));
    }

    public static AuditEventEntity save(CacheSession session, AuditEventEntity entity) {
        return repository(session).save(entity);
    }

    public static AuditEventEntity save(CacheSession session, CachePolicy cachePolicy, AuditEventEntity entity) {
        return repository(session, cachePolicy).save(entity);
    }

    public static Optional<AuditEventEntity> findById(CacheSession session, java.lang.Long id) {
        return repository(session).findById(id);
    }

    public static Optional<AuditEventEntity> findById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        return repository(session, cachePolicy).findById(id);
    }

    public static List<AuditEventEntity> findPage(CacheSession session, PageWindow pageWindow) {
        return repository(session).findPage(pageWindow);
    }

    public static List<AuditEventEntity> findPage(CacheSession session, CachePolicy cachePolicy, PageWindow pageWindow) {
        return repository(session, cachePolicy).findPage(pageWindow);
    }

    public static List<AuditEventEntity> query(CacheSession session, QuerySpec querySpec) {
        return repository(session).query(querySpec);
    }

    public static List<AuditEventEntity> query(CacheSession session, CachePolicy cachePolicy, QuerySpec querySpec) {
        return repository(session, cachePolicy).query(querySpec);
    }

    public static void deleteById(CacheSession session, java.lang.Long id) {
        repository(session).deleteById(id);
    }

    public static void deleteById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        repository(session, cachePolicy).deleteById(id);
    }

    public static Scope using(CacheSession session) {
        return new Scope(session, null);
    }

    public static Scope using(CacheSession session, CachePolicy cachePolicy) {
        return new Scope(session, cachePolicy);
    }

    public static final class Scope {
        private final CacheSession cacheSession;
        private final EntityRepository<AuditEventEntity, java.lang.Long> repository;
        private volatile SourceRepository<AuditEventEntity, java.lang.Long> sourceRepository;

        private Scope(CacheSession cacheSession, CachePolicy cachePolicy) {
            this.cacheSession = cacheSession;
            this.repository = cachePolicy == null ? AuditEventEntityCacheBinding.repository(cacheSession) : AuditEventEntityCacheBinding.repository(cacheSession, cachePolicy);
        }

        public EntityRepository<AuditEventEntity, java.lang.Long> repository() {
            return repository;
        }

        public ActiveRecordInstance<AuditEventEntity, java.lang.Long> attach(AuditEventEntity entity) {
            return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository);
        }

        public AuditEventEntity save(AuditEventEntity entity) {
            return repository.save(entity);
        }

        public WriteReceipt<AuditEventEntity, java.lang.Long> saveWithReceipt(AuditEventEntity entity) {
            return repository.saveWithReceipt(entity);
        }

        public WriteReceipt<AuditEventEntity, java.lang.Long> save(AuditEventEntity entity, long expectedVersion) {
            return repository.save(entity, expectedVersion);
        }

        public WriteReceipt<AuditEventEntity, java.lang.Long> saveAfter(AuditEventEntity entity, WriteDependency dependency) {
            return repository.saveAfter(entity, dependency);
        }

        public List<WriteReceipt<AuditEventEntity, java.lang.Long>> saveAll(java.util.Collection<AuditEventEntity> entities) {
            return repository.saveAll(entities);
        }

        public Optional<AuditEventEntity> findById(java.lang.Long id) {
            return repository.findById(id);
        }

        public Optional<VersionedEntity<AuditEventEntity>> findVersionedById(java.lang.Long id) {
            return repository.findVersionedById(id);
        }

        public Optional<WriteDependency> dependency(java.lang.Long id) {
            return repository.findVersionedById(id).map(versioned -> new WriteDependency(METADATA.redisNamespace(), String.valueOf(id), versioned.version()));
        }

        public List<AuditEventEntity> findPage(PageWindow pageWindow) {
            return repository.findPage(pageWindow);
        }

        public List<AuditEventEntity> query(QuerySpec querySpec) {
            return repository.query(querySpec);
        }

        public <K> Map<K, List<AuditEventEntity>> queryPartitions(PartitionedQuerySpec<K> querySpec) {
            return repository.queryPartitions(querySpec);
        }

        public SourceRepository<AuditEventEntity, java.lang.Long> source() {
            SourceRepository<AuditEventEntity, java.lang.Long> resolved = sourceRepository;
            if (resolved == null) {
                synchronized (this) {
                    resolved = sourceRepository;
                    if (resolved == null) {
                        resolved = cacheSession.sourceRepository(METADATA, CODEC);
                        sourceRepository = resolved;
                    }
                }
            }
            return resolved;
        }

        public void deleteById(java.lang.Long id) {
            repository.deleteById(id);
        }

        public CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
            return AuditEventEntityCacheBinding.warmPlan(name, querySpec, maxRows);
        }
    }
}
