package com.reactor.cachedb.examples.demo.entity;

/** Compile-time generated field metamodel. */
public final class MigrationDemoOrderEntityFields {
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoOrderEntity, java.lang.Long> orderId = new com.reactor.cachedb.core.query.CacheField<>("orderId", "order_id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoOrderEntity, java.lang.Long> customerId = new com.reactor.cachedb.core.query.CacheField<>("customerId", "customer_id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoOrderEntity, java.time.Instant> orderDate = new com.reactor.cachedb.core.query.CacheField<>("orderDate", "order_date", java.time.Instant.class);
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoOrderEntity, java.lang.Double> orderAmount = new com.reactor.cachedb.core.query.CacheField<>("orderAmount", "order_amount", java.lang.Double.class);
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoOrderEntity, java.lang.String> currencyCode = new com.reactor.cachedb.core.query.CacheField<>("currencyCode", "currency_code", java.lang.String.class);
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoOrderEntity, java.lang.String> orderType = new com.reactor.cachedb.core.query.CacheField<>("orderType", "order_type", java.lang.String.class);
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoOrderEntity, java.lang.Double> rankScore = new com.reactor.cachedb.core.query.CacheField<>("rankScore", "rank_score", java.lang.Double.class);
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoOrderEntity, java.time.Instant> createdAt = new com.reactor.cachedb.core.query.CacheField<>("createdAt", "created_at", java.time.Instant.class);

    private MigrationDemoOrderEntityFields() {
    }
}
