package com.reactor.cachedb.examples.entity;

/** Compile-time generated field metamodel. */
public final class UserEntityFields {
    public static final com.reactor.cachedb.core.query.CacheField<UserEntity, java.lang.Long> id = new com.reactor.cachedb.core.query.CacheField<>("id", "id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<UserEntity, java.lang.String> username = new com.reactor.cachedb.core.query.CacheField<>("username", "username", java.lang.String.class);
    public static final com.reactor.cachedb.core.query.CacheField<UserEntity, java.lang.String> status = new com.reactor.cachedb.core.query.CacheField<>("status", "status", java.lang.String.class);

    private UserEntityFields() {
    }
}
