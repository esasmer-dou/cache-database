package com.reactor.cachedb.examples.demo.entity;

/** Compile-time generated field metamodel. */
public final class MigrationDemoCustomerEntityFields {
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoCustomerEntity, java.lang.Long> customerId = new com.reactor.cachedb.core.query.CacheField<>("customerId", "customer_id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoCustomerEntity, java.lang.String> taxNumber = new com.reactor.cachedb.core.query.CacheField<>("taxNumber", "tax_number", java.lang.String.class);
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoCustomerEntity, java.lang.String> customerType = new com.reactor.cachedb.core.query.CacheField<>("customerType", "customer_type", java.lang.String.class);
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoCustomerEntity, java.lang.String> customerStatus = new com.reactor.cachedb.core.query.CacheField<>("customerStatus", "customer_status", java.lang.String.class);
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoCustomerEntity, java.lang.String> countryCode = new com.reactor.cachedb.core.query.CacheField<>("countryCode", "country_code", java.lang.String.class);
    public static final com.reactor.cachedb.core.query.CacheField<MigrationDemoCustomerEntity, java.time.Instant> createdAt = new com.reactor.cachedb.core.query.CacheField<>("createdAt", "created_at", java.time.Instant.class);

    private MigrationDemoCustomerEntityFields() {
    }
}
