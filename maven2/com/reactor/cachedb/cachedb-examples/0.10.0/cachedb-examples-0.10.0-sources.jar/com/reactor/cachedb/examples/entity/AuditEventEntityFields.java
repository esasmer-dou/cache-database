package com.reactor.cachedb.examples.entity;

/** Compile-time generated field metamodel. */
public final class AuditEventEntityFields {
    public static final com.reactor.cachedb.core.query.CacheField<AuditEventEntity, java.lang.Long> id = new com.reactor.cachedb.core.query.CacheField<>("id", "id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<AuditEventEntity, com.reactor.cachedb.examples.entity.AccountState> accountState = new com.reactor.cachedb.core.query.CacheField<>("accountState", "account_state", com.reactor.cachedb.examples.entity.AccountState.class);
    public static final com.reactor.cachedb.core.query.CacheField<AuditEventEntity, java.time.Instant> createdAt = new com.reactor.cachedb.core.query.CacheField<>("createdAt", "created_at", java.time.Instant.class);
    public static final com.reactor.cachedb.core.query.CacheField<AuditEventEntity, com.reactor.cachedb.examples.entity.TagValue> tagValue = new com.reactor.cachedb.core.query.CacheField<>("tagValue", "tag_value", com.reactor.cachedb.examples.entity.TagValue.class);

    private AuditEventEntityFields() {
    }
}
