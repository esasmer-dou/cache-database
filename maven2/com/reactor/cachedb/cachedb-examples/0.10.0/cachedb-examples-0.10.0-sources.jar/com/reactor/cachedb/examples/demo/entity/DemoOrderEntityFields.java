package com.reactor.cachedb.examples.demo.entity;

/** Compile-time generated field metamodel. */
public final class DemoOrderEntityFields {
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderEntity, java.lang.Long> id = new com.reactor.cachedb.core.query.CacheField<>("id", "id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderEntity, java.lang.Long> customerId = new com.reactor.cachedb.core.query.CacheField<>("customerId", "customer_id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderEntity, java.lang.Long> productId = new com.reactor.cachedb.core.query.CacheField<>("productId", "product_id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderEntity, java.lang.Double> totalAmount = new com.reactor.cachedb.core.query.CacheField<>("totalAmount", "total_amount", java.lang.Double.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderEntity, java.lang.Integer> lineItemCount = new com.reactor.cachedb.core.query.CacheField<>("lineItemCount", "line_item_count", java.lang.Integer.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderEntity, java.lang.String> status = new com.reactor.cachedb.core.query.CacheField<>("status", "status", java.lang.String.class);

    private DemoOrderEntityFields() {
    }
}
