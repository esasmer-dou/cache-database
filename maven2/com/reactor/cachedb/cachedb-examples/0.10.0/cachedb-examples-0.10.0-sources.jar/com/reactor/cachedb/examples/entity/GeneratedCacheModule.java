package com.reactor.cachedb.examples.entity;

import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.CachePolicyCatalog;
import com.reactor.cachedb.starter.CacheDatabase;

public final class GeneratedCacheModule {
    private GeneratedCacheModule() {
    }

    public static void register(CacheDatabase cacheDatabase) {
        GeneratedCacheBindings.register(cacheDatabase);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        GeneratedCacheBindings.register(cacheDatabase, cachePolicy);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase) {
        registerJdbcBacked(cacheDatabase, CachePolicyCatalog.empty());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicyCatalog policyCatalog) {
        GeneratedCacheBindings.registerJdbcSources(cacheDatabase, policyCatalog);
        GeneratedCacheBindings.registerDeclaredLoaders(cacheDatabase, policyCatalog);
    }

    public static Scope using(CacheSession cacheSession) {
        return new Scope(cacheSession, null);
    }

    public static Scope using(CacheSession cacheSession, CachePolicy cachePolicy) {
        return new Scope(cacheSession, cachePolicy);
    }

    public static final class Scope {
        private final CacheSession cacheSession;
        private final CachePolicy cachePolicy;
        private volatile AuditEventEntityCacheBinding.Scope auditEventsScope;
        private volatile OrderEntityCacheBinding.Scope ordersScope;
        private volatile UserEntityCacheBinding.Scope usersScope;

        private Scope(CacheSession cacheSession, CachePolicy cachePolicy) {
            this.cacheSession = java.util.Objects.requireNonNull(cacheSession, "cacheSession");
            this.cachePolicy = cachePolicy;
        }

        public AuditEventEntityCacheBinding.Scope auditEvents() {
            AuditEventEntityCacheBinding.Scope resolved = auditEventsScope;
            if (resolved == null) {
                synchronized (this) {
                    resolved = auditEventsScope;
                    if (resolved == null) {
                        resolved = cachePolicy == null ? AuditEventEntityCacheBinding.using(cacheSession) : AuditEventEntityCacheBinding.using(cacheSession, cachePolicy);
                        auditEventsScope = resolved;
                    }
                }
            }
            return resolved;
        }

        public OrderEntityCacheBinding.Scope orders() {
            OrderEntityCacheBinding.Scope resolved = ordersScope;
            if (resolved == null) {
                synchronized (this) {
                    resolved = ordersScope;
                    if (resolved == null) {
                        resolved = cachePolicy == null ? OrderEntityCacheBinding.using(cacheSession) : OrderEntityCacheBinding.using(cacheSession, cachePolicy);
                        ordersScope = resolved;
                    }
                }
            }
            return resolved;
        }

        public UserEntityCacheBinding.Scope users() {
            UserEntityCacheBinding.Scope resolved = usersScope;
            if (resolved == null) {
                synchronized (this) {
                    resolved = usersScope;
                    if (resolved == null) {
                        resolved = cachePolicy == null ? UserEntityCacheBinding.using(cacheSession) : UserEntityCacheBinding.using(cacheSession, cachePolicy);
                        usersScope = resolved;
                    }
                }
            }
            return resolved;
        }
    }
}
