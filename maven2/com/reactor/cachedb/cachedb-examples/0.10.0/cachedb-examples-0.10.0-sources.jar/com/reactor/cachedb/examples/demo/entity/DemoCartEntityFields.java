package com.reactor.cachedb.examples.demo.entity;

/** Compile-time generated field metamodel. */
public final class DemoCartEntityFields {
    public static final com.reactor.cachedb.core.query.CacheField<DemoCartEntity, java.lang.Long> id = new com.reactor.cachedb.core.query.CacheField<>("id", "id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoCartEntity, java.lang.Long> customerId = new com.reactor.cachedb.core.query.CacheField<>("customerId", "customer_id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoCartEntity, java.lang.Long> productId = new com.reactor.cachedb.core.query.CacheField<>("productId", "product_id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoCartEntity, java.lang.Integer> quantity = new com.reactor.cachedb.core.query.CacheField<>("quantity", "quantity", java.lang.Integer.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoCartEntity, java.lang.String> status = new com.reactor.cachedb.core.query.CacheField<>("status", "status", java.lang.String.class);

    private DemoCartEntityFields() {
    }
}
