package com.reactor.cachedb.examples.demo.entity;

/** Compile-time generated field metamodel. */
public final class DemoOrderLineEntityFields {
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderLineEntity, java.lang.Long> id = new com.reactor.cachedb.core.query.CacheField<>("id", "id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderLineEntity, java.lang.Long> orderId = new com.reactor.cachedb.core.query.CacheField<>("orderId", "order_id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderLineEntity, java.lang.Long> productId = new com.reactor.cachedb.core.query.CacheField<>("productId", "product_id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderLineEntity, java.lang.Integer> lineNumber = new com.reactor.cachedb.core.query.CacheField<>("lineNumber", "line_number", java.lang.Integer.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderLineEntity, java.lang.String> sku = new com.reactor.cachedb.core.query.CacheField<>("sku", "sku", java.lang.String.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderLineEntity, java.lang.Integer> quantity = new com.reactor.cachedb.core.query.CacheField<>("quantity", "quantity", java.lang.Integer.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderLineEntity, java.lang.Double> unitPrice = new com.reactor.cachedb.core.query.CacheField<>("unitPrice", "unit_price", java.lang.Double.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderLineEntity, java.lang.Double> lineTotal = new com.reactor.cachedb.core.query.CacheField<>("lineTotal", "line_total", java.lang.Double.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoOrderLineEntity, java.lang.String> status = new com.reactor.cachedb.core.query.CacheField<>("status", "status", java.lang.String.class);

    private DemoOrderLineEntityFields() {
    }
}
