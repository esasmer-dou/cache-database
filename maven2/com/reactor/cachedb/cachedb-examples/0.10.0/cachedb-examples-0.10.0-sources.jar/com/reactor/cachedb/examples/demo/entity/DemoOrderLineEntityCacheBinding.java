package com.reactor.cachedb.examples.demo.entity;

import com.reactor.cachedb.core.codec.LengthPrefixedPayloadCodec;
import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.api.EntityRepository;
import com.reactor.cachedb.core.api.ProjectionRepository;
import com.reactor.cachedb.core.api.SourceRepository;
import com.reactor.cachedb.core.active.ActiveRecordInstance;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.PageWindow;
import com.reactor.cachedb.core.plan.FetchPlan;
import com.reactor.cachedb.core.model.EntityCodec;
import com.reactor.cachedb.core.model.EntityMetadata;
import com.reactor.cachedb.core.model.WriteDependency;
import com.reactor.cachedb.core.model.WriteReceipt;
import com.reactor.cachedb.core.page.EntityPageLoader;
import com.reactor.cachedb.core.page.VersionedEntity;
import com.reactor.cachedb.core.model.RelationDefinition;
import com.reactor.cachedb.core.model.RelationKind;
import com.reactor.cachedb.core.projection.EntityProjection;
import com.reactor.cachedb.core.query.QuerySpec;
import com.reactor.cachedb.core.query.PartitionedQuerySpec;
import com.reactor.cachedb.core.query.QuerySort;
import com.reactor.cachedb.core.route.RouteCacheContract;
import com.reactor.cachedb.core.route.RouteCacheContext;
import com.reactor.cachedb.core.route.RouteCacheStrictMode;
import com.reactor.cachedb.core.relation.RelationBatchLoader;
import com.reactor.cachedb.core.relation.CompositeRelationBatchLoader;
import com.reactor.cachedb.core.relation.PartitionedRelationBatchLoader;
import com.reactor.cachedb.starter.CacheDatabase;
import com.reactor.cachedb.starter.CacheWarmPlan;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public final class DemoOrderLineEntityCacheBinding {
    public static final EntityMetadata<DemoOrderLineEntity, java.lang.Long> METADATA = new Metadata();
    public static final EntityCodec<DemoOrderLineEntity> CODEC = new Codec();

    private DemoOrderLineEntityCacheBinding() {
    }

    public static DemoOrderLineEntity withId(DemoOrderLineEntity entity, java.lang.Long id) {
        java.util.Objects.requireNonNull(entity, "entity");
        java.util.Objects.requireNonNull(id, "id");
        entity.id = id;
        return entity;
    }

    private static final class Metadata implements EntityMetadata<DemoOrderLineEntity, java.lang.Long> {
        @Override
        public String entityName() {
            return "DemoOrderLineEntity";
        }

        @Override
        public String tableName() {
            return "cachedb_demo_order_lines";
        }

        @Override
        public String redisNamespace() {
            return "demo-order-lines";
        }

        @Override
        public String idColumn() {
            return "id";
        }

        @Override
        public String versionColumn() {
            return "entity_version";
        }

        @Override
        public String deletedColumn() {
            return null;
        }

        @Override
        public String activeMarkerValue() {
            return "false";
        }

        @Override
        public String deletedMarkerValue() {
            return "true";
        }

        @Override
        public Class<DemoOrderLineEntity> entityType() {
            return DemoOrderLineEntity.class;
        }

        @Override
        public Function<DemoOrderLineEntity, java.lang.Long> idAccessor() {
            return entity -> entity.id;
        }

        @Override
        public List<String> columns() {
            return List.of("id", "order_id", "product_id", "line_number", "sku", "quantity", "unit_price", "line_total", "status");
        }

        @Override
        public Map<String, String> columnTypes() {
            LinkedHashMap<String, String> columnTypes = new LinkedHashMap<>();
            columnTypes.put("id", "java.lang.Long");
            columnTypes.put("order_id", "java.lang.Long");
            columnTypes.put("product_id", "java.lang.Long");
            columnTypes.put("line_number", "java.lang.Integer");
            columnTypes.put("sku", "java.lang.String");
            columnTypes.put("quantity", "java.lang.Integer");
            columnTypes.put("unit_price", "java.lang.Double");
            columnTypes.put("line_total", "java.lang.Double");
            columnTypes.put("status", "java.lang.String");
            return columnTypes;
        }

        @Override
        public Map<String, List<String>> partitionedSortIndexes() {
            return Map.of();
        }

        @Override
        public List<RelationDefinition> relations() {
            return List.of();
        }
    }

    private static final class Codec implements EntityCodec<DemoOrderLineEntity> {
        @Override
        public String toRedisValue(DemoOrderLineEntity entity) {
            LinkedHashMap<String, String> values = new LinkedHashMap<>();
            values.put("id", entity.id == null ? null : String.valueOf(entity.id));
            values.put("order_id", entity.orderId == null ? null : String.valueOf(entity.orderId));
            values.put("product_id", entity.productId == null ? null : String.valueOf(entity.productId));
            values.put("line_number", entity.lineNumber == null ? null : String.valueOf(entity.lineNumber));
            values.put("sku", entity.sku);
            values.put("quantity", entity.quantity == null ? null : String.valueOf(entity.quantity));
            values.put("unit_price", entity.unitPrice == null ? null : String.valueOf(entity.unitPrice));
            values.put("line_total", entity.lineTotal == null ? null : String.valueOf(entity.lineTotal));
            values.put("status", entity.status);
            return LengthPrefixedPayloadCodec.encode(values);
        }

        @Override
        public DemoOrderLineEntity fromRedisValue(String encoded) {
            Map<String, String> values = LengthPrefixedPayloadCodec.decode(encoded);
            DemoOrderLineEntity entity = new DemoOrderLineEntity();
            entity.id = values.get("id") == null ? null : Long.valueOf(values.get("id"));
            entity.orderId = values.get("order_id") == null ? null : Long.valueOf(values.get("order_id"));
            entity.productId = values.get("product_id") == null ? null : Long.valueOf(values.get("product_id"));
            entity.lineNumber = values.get("line_number") == null ? null : Integer.valueOf(values.get("line_number"));
            entity.sku = values.get("sku");
            entity.quantity = values.get("quantity") == null ? null : Integer.valueOf(values.get("quantity"));
            entity.unitPrice = values.get("unit_price") == null ? null : Double.valueOf(values.get("unit_price"));
            entity.lineTotal = values.get("line_total") == null ? null : Double.valueOf(values.get("line_total"));
            entity.status = values.get("status");
            return entity;
        }

        @Override
        public DemoOrderLineEntity fromColumns(Map<String, Object> columns) {
            DemoOrderLineEntity entity = new DemoOrderLineEntity();
            entity.id = columnValue(columns, "id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "id"))));
            entity.orderId = columnValue(columns, "order_id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "order_id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "order_id"))));
            entity.productId = columnValue(columns, "product_id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "product_id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "product_id"))));
            entity.lineNumber = columnValue(columns, "line_number") instanceof Number number ? Integer.valueOf(number.intValue()) : (columnValue(columns, "line_number") == null ? null : Integer.valueOf(String.valueOf(columnValue(columns, "line_number"))));
            entity.sku = columnValue(columns, "sku") == null ? null : String.valueOf(columnValue(columns, "sku"));
            entity.quantity = columnValue(columns, "quantity") instanceof Number number ? Integer.valueOf(number.intValue()) : (columnValue(columns, "quantity") == null ? null : Integer.valueOf(String.valueOf(columnValue(columns, "quantity"))));
            entity.unitPrice = columnValue(columns, "unit_price") instanceof Number number ? Double.valueOf(number.doubleValue()) : (columnValue(columns, "unit_price") == null ? null : Double.valueOf(String.valueOf(columnValue(columns, "unit_price"))));
            entity.lineTotal = columnValue(columns, "line_total") instanceof Number number ? Double.valueOf(number.doubleValue()) : (columnValue(columns, "line_total") == null ? null : Double.valueOf(String.valueOf(columnValue(columns, "line_total"))));
            entity.status = columnValue(columns, "status") == null ? null : String.valueOf(columnValue(columns, "status"));
            return entity;
        }

        @Override
        public Map<String, Object> toColumns(DemoOrderLineEntity entity) {
            LinkedHashMap<String, Object> columns = new LinkedHashMap<>();
            columns.put("id", entity.id);
            columns.put("order_id", entity.orderId);
            columns.put("product_id", entity.productId);
            columns.put("line_number", entity.lineNumber);
            columns.put("sku", entity.sku);
            columns.put("quantity", entity.quantity);
            columns.put("unit_price", entity.unitPrice);
            columns.put("line_total", entity.lineTotal);
            columns.put("status", entity.status);
            return columns;
        }
    }

    public static com.reactor.cachedb.core.projection.EntityProjection<com.reactor.cachedb.examples.demo.entity.DemoOrderLineEntity,com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel,java.lang.Long> orderLinePreviewProjection() {
        return DemoOrderLineEntity.orderLinePreviewProjection();
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel, java.lang.Long> orderLinePreview(CacheSession session) {
        return repository(session).projected(orderLinePreviewProjection());
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel, java.lang.Long> orderLinePreview(CacheSession session, CachePolicy cachePolicy) {
        return repository(session, cachePolicy).projected(orderLinePreviewProjection());
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel, java.lang.Long> orderLinePreview(EntityRepository<DemoOrderLineEntity, java.lang.Long> repository) {
        return repository.projected(orderLinePreviewProjection());
    }

    public static QuerySpec previewLinesForOrdersQuery(java.util.List<java.lang.Long> orderIds, int totalLimit) {
        return DemoOrderLineEntity.previewLinesForOrdersQuery(orderIds, totalLimit);
    }

    public static List<DemoOrderLineEntity> previewLinesForOrders(CacheSession cacheSession, java.util.List<java.lang.Long> orderIds, int totalLimit) {
        return repository(cacheSession).query(previewLinesForOrdersQuery(orderIds, totalLimit));
    }

    public static List<DemoOrderLineEntity> previewLinesForOrders(CacheSession cacheSession, CachePolicy cachePolicy, java.util.List<java.lang.Long> orderIds, int totalLimit) {
        return repository(cacheSession, cachePolicy).query(previewLinesForOrdersQuery(orderIds, totalLimit));
    }

    public static List<DemoOrderLineEntity> previewLinesForOrders(EntityRepository<DemoOrderLineEntity, java.lang.Long> entityRepository, java.util.List<java.lang.Long> orderIds, int totalLimit) {
        return entityRepository.query(previewLinesForOrdersQuery(orderIds, totalLimit));
    }

    public static <P> List<P> previewLinesForOrders(ProjectionRepository<P, java.lang.Long> projectionRepository, java.util.List<java.lang.Long> orderIds, int totalLimit) {
        return projectionRepository.query(previewLinesForOrdersQuery(orderIds, totalLimit));
    }

    public static EntityRepository<DemoOrderLineEntity, java.lang.Long> repository(CacheSession session) {
        return session.repository(METADATA, CODEC);
    }

    public static EntityRepository<DemoOrderLineEntity, java.lang.Long> repository(CacheSession session, CachePolicy cachePolicy) {
        return session.repository(METADATA, CODEC, cachePolicy);
    }

    public static void register(CacheDatabase cacheDatabase) {
        cacheDatabase.register(METADATA, CODEC);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase) {
        registerJdbcBacked(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void registerJdbcSource(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void registerDeclaredLoaders(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader, EntityPageLoader<DemoOrderLineEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader, EntityPageLoader<DemoOrderLineEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader, EntityPageLoader<DemoOrderLineEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoOrderLineEntity> relationBatchLoader, EntityPageLoader<DemoOrderLineEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, orderLinePreviewProjection());
    }

    public static CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
        return CacheWarmPlan.builder(METADATA.entityName())
                .name(name)
                .querySpec(querySpec)
                .maxRows(maxRows)
                .build();
    }

    public static ActiveRecordInstance<DemoOrderLineEntity, java.lang.Long> attach(CacheSession session, DemoOrderLineEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session));
    }

    public static ActiveRecordInstance<DemoOrderLineEntity, java.lang.Long> attach(CacheSession session, CachePolicy cachePolicy, DemoOrderLineEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session, cachePolicy));
    }

    public static DemoOrderLineEntity save(CacheSession session, DemoOrderLineEntity entity) {
        return repository(session).save(entity);
    }

    public static DemoOrderLineEntity save(CacheSession session, CachePolicy cachePolicy, DemoOrderLineEntity entity) {
        return repository(session, cachePolicy).save(entity);
    }

    public static Optional<DemoOrderLineEntity> findById(CacheSession session, java.lang.Long id) {
        return repository(session).findById(id);
    }

    public static Optional<DemoOrderLineEntity> findById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        return repository(session, cachePolicy).findById(id);
    }

    public static List<DemoOrderLineEntity> findPage(CacheSession session, PageWindow pageWindow) {
        return repository(session).findPage(pageWindow);
    }

    public static List<DemoOrderLineEntity> findPage(CacheSession session, CachePolicy cachePolicy, PageWindow pageWindow) {
        return repository(session, cachePolicy).findPage(pageWindow);
    }

    public static List<DemoOrderLineEntity> query(CacheSession session, QuerySpec querySpec) {
        return repository(session).query(querySpec);
    }

    public static List<DemoOrderLineEntity> query(CacheSession session, CachePolicy cachePolicy, QuerySpec querySpec) {
        return repository(session, cachePolicy).query(querySpec);
    }

    public static void deleteById(CacheSession session, java.lang.Long id) {
        repository(session).deleteById(id);
    }

    public static void deleteById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        repository(session, cachePolicy).deleteById(id);
    }

    public static Scope using(CacheSession session) {
        return new Scope(session, null);
    }

    public static Scope using(CacheSession session, CachePolicy cachePolicy) {
        return new Scope(session, cachePolicy);
    }

    public static final class Scope {
        private final CacheSession cacheSession;
        private final EntityRepository<DemoOrderLineEntity, java.lang.Long> repository;
        private volatile SourceRepository<DemoOrderLineEntity, java.lang.Long> sourceRepository;
        private final Queries queries;
        private final Projections projections;

        private Scope(CacheSession cacheSession, CachePolicy cachePolicy) {
            this.cacheSession = cacheSession;
            this.repository = cachePolicy == null ? DemoOrderLineEntityCacheBinding.repository(cacheSession) : DemoOrderLineEntityCacheBinding.repository(cacheSession, cachePolicy);
            this.queries = new Queries(this);
            this.projections = new Projections(this);
        }

        public EntityRepository<DemoOrderLineEntity, java.lang.Long> repository() {
            return repository;
        }

        public ActiveRecordInstance<DemoOrderLineEntity, java.lang.Long> attach(DemoOrderLineEntity entity) {
            return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository);
        }

        public DemoOrderLineEntity save(DemoOrderLineEntity entity) {
            return repository.save(entity);
        }

        public WriteReceipt<DemoOrderLineEntity, java.lang.Long> saveWithReceipt(DemoOrderLineEntity entity) {
            return repository.saveWithReceipt(entity);
        }

        public WriteReceipt<DemoOrderLineEntity, java.lang.Long> save(DemoOrderLineEntity entity, long expectedVersion) {
            return repository.save(entity, expectedVersion);
        }

        public WriteReceipt<DemoOrderLineEntity, java.lang.Long> saveAfter(DemoOrderLineEntity entity, WriteDependency dependency) {
            return repository.saveAfter(entity, dependency);
        }

        public List<WriteReceipt<DemoOrderLineEntity, java.lang.Long>> saveAll(java.util.Collection<DemoOrderLineEntity> entities) {
            return repository.saveAll(entities);
        }

        public Optional<DemoOrderLineEntity> findById(java.lang.Long id) {
            return repository.findById(id);
        }

        public Optional<VersionedEntity<DemoOrderLineEntity>> findVersionedById(java.lang.Long id) {
            return repository.findVersionedById(id);
        }

        public Optional<WriteDependency> dependency(java.lang.Long id) {
            return repository.findVersionedById(id).map(versioned -> new WriteDependency(METADATA.redisNamespace(), String.valueOf(id), versioned.version()));
        }

        public List<DemoOrderLineEntity> findPage(PageWindow pageWindow) {
            return repository.findPage(pageWindow);
        }

        public List<DemoOrderLineEntity> query(QuerySpec querySpec) {
            return repository.query(querySpec);
        }

        public <K> Map<K, List<DemoOrderLineEntity>> queryPartitions(PartitionedQuerySpec<K> querySpec) {
            return repository.queryPartitions(querySpec);
        }

        public SourceRepository<DemoOrderLineEntity, java.lang.Long> source() {
            SourceRepository<DemoOrderLineEntity, java.lang.Long> resolved = sourceRepository;
            if (resolved == null) {
                synchronized (this) {
                    resolved = sourceRepository;
                    if (resolved == null) {
                        resolved = cacheSession.sourceRepository(METADATA, CODEC);
                        sourceRepository = resolved;
                    }
                }
            }
            return resolved;
        }

        public void deleteById(java.lang.Long id) {
            repository.deleteById(id);
        }

        public CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
            return DemoOrderLineEntityCacheBinding.warmPlan(name, querySpec, maxRows);
        }

        public Queries queries() {
            return queries;
        }

        public Projections projections() {
            return projections;
        }
    }

    public static final class Queries {
        private final Scope scope;

        private Queries(Scope scope) {
            this.scope = scope;
        }

        public QuerySpec previewLinesForOrdersQuery(java.util.List<java.lang.Long> orderIds, int totalLimit) {
            return DemoOrderLineEntityCacheBinding.previewLinesForOrdersQuery(orderIds, totalLimit);
        }

        public List<DemoOrderLineEntity> previewLinesForOrders(java.util.List<java.lang.Long> orderIds, int totalLimit) {
            return scope.repository().query(previewLinesForOrdersQuery(orderIds, totalLimit));
        }
    }

    public static final class Projections {
        private final Scope scope;
        private volatile ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel, java.lang.Long> orderLinePreview;

        private Projections(Scope scope) {
            this.scope = scope;
        }

        public com.reactor.cachedb.core.projection.EntityProjection<com.reactor.cachedb.examples.demo.entity.DemoOrderLineEntity,com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel,java.lang.Long> orderLinePreviewProjection() {
            return DemoOrderLineEntityCacheBinding.orderLinePreviewProjection();
        }

        public ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel, java.lang.Long> orderLinePreview() {
            ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderLinePreviewReadModel, java.lang.Long> resolved = orderLinePreview;
            if (resolved == null) {
                synchronized (this) {
                    resolved = orderLinePreview;
                    if (resolved == null) {
                        resolved = scope.repository().projected(orderLinePreviewProjection());
                        orderLinePreview = resolved;
                    }
                }
            }
            return resolved;
        }
    }
}
