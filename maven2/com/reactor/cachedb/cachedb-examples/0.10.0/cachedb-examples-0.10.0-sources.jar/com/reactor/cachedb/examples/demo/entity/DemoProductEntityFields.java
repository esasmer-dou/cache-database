package com.reactor.cachedb.examples.demo.entity;

/** Compile-time generated field metamodel. */
public final class DemoProductEntityFields {
    public static final com.reactor.cachedb.core.query.CacheField<DemoProductEntity, java.lang.Long> id = new com.reactor.cachedb.core.query.CacheField<>("id", "id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoProductEntity, java.lang.String> sku = new com.reactor.cachedb.core.query.CacheField<>("sku", "sku", java.lang.String.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoProductEntity, java.lang.String> category = new com.reactor.cachedb.core.query.CacheField<>("category", "category", java.lang.String.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoProductEntity, java.lang.Double> price = new com.reactor.cachedb.core.query.CacheField<>("price", "price", java.lang.Double.class);
    public static final com.reactor.cachedb.core.query.CacheField<DemoProductEntity, java.lang.Integer> stock = new com.reactor.cachedb.core.query.CacheField<>("stock", "stock", java.lang.Integer.class);

    private DemoProductEntityFields() {
    }
}
