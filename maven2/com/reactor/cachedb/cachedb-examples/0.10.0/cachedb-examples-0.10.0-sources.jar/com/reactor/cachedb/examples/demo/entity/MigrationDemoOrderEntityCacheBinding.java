package com.reactor.cachedb.examples.demo.entity;

import com.reactor.cachedb.core.codec.LengthPrefixedPayloadCodec;
import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.api.EntityRepository;
import com.reactor.cachedb.core.api.ProjectionRepository;
import com.reactor.cachedb.core.api.SourceRepository;
import com.reactor.cachedb.core.active.ActiveRecordInstance;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.PageWindow;
import com.reactor.cachedb.core.plan.FetchPlan;
import com.reactor.cachedb.core.model.EntityCodec;
import com.reactor.cachedb.core.model.EntityMetadata;
import com.reactor.cachedb.core.model.WriteDependency;
import com.reactor.cachedb.core.model.WriteReceipt;
import com.reactor.cachedb.core.page.EntityPageLoader;
import com.reactor.cachedb.core.page.VersionedEntity;
import com.reactor.cachedb.core.model.RelationDefinition;
import com.reactor.cachedb.core.model.RelationKind;
import com.reactor.cachedb.core.projection.EntityProjection;
import com.reactor.cachedb.core.query.QuerySpec;
import com.reactor.cachedb.core.query.PartitionedQuerySpec;
import com.reactor.cachedb.core.query.QuerySort;
import com.reactor.cachedb.core.route.RouteCacheContract;
import com.reactor.cachedb.core.route.RouteCacheContext;
import com.reactor.cachedb.core.route.RouteCacheStrictMode;
import com.reactor.cachedb.core.relation.RelationBatchLoader;
import com.reactor.cachedb.core.relation.CompositeRelationBatchLoader;
import com.reactor.cachedb.core.relation.PartitionedRelationBatchLoader;
import com.reactor.cachedb.starter.CacheDatabase;
import com.reactor.cachedb.starter.CacheWarmPlan;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public final class MigrationDemoOrderEntityCacheBinding {
    public static final EntityMetadata<MigrationDemoOrderEntity, java.lang.Long> METADATA = new Metadata();
    public static final EntityCodec<MigrationDemoOrderEntity> CODEC = new Codec();

    private MigrationDemoOrderEntityCacheBinding() {
    }

    public static MigrationDemoOrderEntity withId(MigrationDemoOrderEntity entity, java.lang.Long id) {
        java.util.Objects.requireNonNull(entity, "entity");
        java.util.Objects.requireNonNull(id, "id");
        entity.orderId = id;
        return entity;
    }

    private static final class Metadata implements EntityMetadata<MigrationDemoOrderEntity, java.lang.Long> {
        @Override
        public String entityName() {
            return "MigrationDemoOrderEntity";
        }

        @Override
        public String tableName() {
            return "cachedb_migration_demo_orders";
        }

        @Override
        public String redisNamespace() {
            return "migration-demo-orders";
        }

        @Override
        public String idColumn() {
            return "order_id";
        }

        @Override
        public String versionColumn() {
            return "entity_version";
        }

        @Override
        public String deletedColumn() {
            return null;
        }

        @Override
        public String activeMarkerValue() {
            return "false";
        }

        @Override
        public String deletedMarkerValue() {
            return "true";
        }

        @Override
        public Class<MigrationDemoOrderEntity> entityType() {
            return MigrationDemoOrderEntity.class;
        }

        @Override
        public Function<MigrationDemoOrderEntity, java.lang.Long> idAccessor() {
            return entity -> entity.orderId;
        }

        @Override
        public List<String> columns() {
            return List.of("order_id", "customer_id", "order_date", "order_amount", "currency_code", "order_type", "rank_score", "created_at");
        }

        @Override
        public Map<String, String> columnTypes() {
            LinkedHashMap<String, String> columnTypes = new LinkedHashMap<>();
            columnTypes.put("order_id", "java.lang.Long");
            columnTypes.put("customer_id", "java.lang.Long");
            columnTypes.put("order_date", "java.time.Instant");
            columnTypes.put("order_amount", "java.lang.Double");
            columnTypes.put("currency_code", "java.lang.String");
            columnTypes.put("order_type", "java.lang.String");
            columnTypes.put("rank_score", "java.lang.Double");
            columnTypes.put("created_at", "java.time.Instant");
            return columnTypes;
        }

        @Override
        public Map<String, List<String>> partitionedSortIndexes() {
            return Map.of();
        }

        @Override
        public List<RelationDefinition> relations() {
            return List.of();
        }
    }

    private static final class Codec implements EntityCodec<MigrationDemoOrderEntity> {
        @Override
        public String toRedisValue(MigrationDemoOrderEntity entity) {
            LinkedHashMap<String, String> values = new LinkedHashMap<>();
            values.put("order_id", entity.orderId == null ? null : String.valueOf(entity.orderId));
            values.put("customer_id", entity.customerId == null ? null : String.valueOf(entity.customerId));
            values.put("order_date", entity.orderDate == null ? null : String.valueOf(entity.orderDate));
            values.put("order_amount", entity.orderAmount == null ? null : String.valueOf(entity.orderAmount));
            values.put("currency_code", entity.currencyCode);
            values.put("order_type", entity.orderType);
            values.put("rank_score", entity.rankScore == null ? null : String.valueOf(entity.rankScore));
            values.put("created_at", entity.createdAt == null ? null : String.valueOf(entity.createdAt));
            return LengthPrefixedPayloadCodec.encode(values);
        }

        @Override
        public MigrationDemoOrderEntity fromRedisValue(String encoded) {
            Map<String, String> values = LengthPrefixedPayloadCodec.decode(encoded);
            MigrationDemoOrderEntity entity = new MigrationDemoOrderEntity();
            entity.orderId = values.get("order_id") == null ? null : Long.valueOf(values.get("order_id"));
            entity.customerId = values.get("customer_id") == null ? null : Long.valueOf(values.get("customer_id"));
            entity.orderDate = values.get("order_date") == null ? null : java.time.Instant.parse(values.get("order_date"));
            entity.orderAmount = values.get("order_amount") == null ? null : Double.valueOf(values.get("order_amount"));
            entity.currencyCode = values.get("currency_code");
            entity.orderType = values.get("order_type");
            entity.rankScore = values.get("rank_score") == null ? null : Double.valueOf(values.get("rank_score"));
            entity.createdAt = values.get("created_at") == null ? null : java.time.Instant.parse(values.get("created_at"));
            return entity;
        }

        @Override
        public MigrationDemoOrderEntity fromColumns(Map<String, Object> columns) {
            MigrationDemoOrderEntity entity = new MigrationDemoOrderEntity();
            entity.orderId = columnValue(columns, "order_id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "order_id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "order_id"))));
            entity.customerId = columnValue(columns, "customer_id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "customer_id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "customer_id"))));
            entity.orderDate = columnValue(columns, "order_date") instanceof java.time.Instant instant ? instant : (columnValue(columns, "order_date") instanceof java.sql.Timestamp timestamp ? timestamp.toInstant() : (columnValue(columns, "order_date") instanceof java.time.OffsetDateTime offsetDateTime ? offsetDateTime.toInstant() : (columnValue(columns, "order_date") == null ? null : java.time.Instant.parse(String.valueOf(columnValue(columns, "order_date"))))));
            entity.orderAmount = columnValue(columns, "order_amount") instanceof Number number ? Double.valueOf(number.doubleValue()) : (columnValue(columns, "order_amount") == null ? null : Double.valueOf(String.valueOf(columnValue(columns, "order_amount"))));
            entity.currencyCode = columnValue(columns, "currency_code") == null ? null : String.valueOf(columnValue(columns, "currency_code"));
            entity.orderType = columnValue(columns, "order_type") == null ? null : String.valueOf(columnValue(columns, "order_type"));
            entity.rankScore = columnValue(columns, "rank_score") instanceof Number number ? Double.valueOf(number.doubleValue()) : (columnValue(columns, "rank_score") == null ? null : Double.valueOf(String.valueOf(columnValue(columns, "rank_score"))));
            entity.createdAt = columnValue(columns, "created_at") instanceof java.time.Instant instant ? instant : (columnValue(columns, "created_at") instanceof java.sql.Timestamp timestamp ? timestamp.toInstant() : (columnValue(columns, "created_at") instanceof java.time.OffsetDateTime offsetDateTime ? offsetDateTime.toInstant() : (columnValue(columns, "created_at") == null ? null : java.time.Instant.parse(String.valueOf(columnValue(columns, "created_at"))))));
            return entity;
        }

        @Override
        public Map<String, Object> toColumns(MigrationDemoOrderEntity entity) {
            LinkedHashMap<String, Object> columns = new LinkedHashMap<>();
            columns.put("order_id", entity.orderId);
            columns.put("customer_id", entity.customerId);
            columns.put("order_date", entity.orderDate);
            columns.put("order_amount", entity.orderAmount);
            columns.put("currency_code", entity.currencyCode);
            columns.put("order_type", entity.orderType);
            columns.put("rank_score", entity.rankScore);
            columns.put("created_at", entity.createdAt);
            return columns;
        }
    }

    public static com.reactor.cachedb.core.projection.EntityProjection<com.reactor.cachedb.examples.demo.entity.MigrationDemoOrderEntity,com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderSummaryView,java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection() {
        return MigrationDemoOrderEntity.migrationSummaryProjection();
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderSummaryView, java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHot(CacheSession session) {
        return repository(session).projected(MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderSummaryView, java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHot(CacheSession session, CachePolicy cachePolicy) {
        return repository(session, cachePolicy).projected(MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderSummaryView, java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHot(EntityRepository<MigrationDemoOrderEntity, java.lang.Long> repository) {
        return repository.projected(MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
    }

    public static com.reactor.cachedb.core.projection.EntityProjection<com.reactor.cachedb.examples.demo.entity.MigrationDemoOrderEntity,com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderRankedView,java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection() {
        return MigrationDemoOrderEntity.migrationRankedProjection();
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderRankedView, java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHot(CacheSession session) {
        return repository(session).projected(MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderRankedView, java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHot(CacheSession session, CachePolicy cachePolicy) {
        return repository(session, cachePolicy).projected(MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderRankedView, java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHot(EntityRepository<MigrationDemoOrderEntity, java.lang.Long> repository) {
        return repository.projected(MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static EntityRepository<MigrationDemoOrderEntity, java.lang.Long> repository(CacheSession session) {
        return session.repository(METADATA, CODEC);
    }

    public static EntityRepository<MigrationDemoOrderEntity, java.lang.Long> repository(CacheSession session, CachePolicy cachePolicy) {
        return session.repository(METADATA, CODEC, cachePolicy);
    }

    public static void register(CacheDatabase cacheDatabase) {
        cacheDatabase.register(METADATA, CODEC);
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy);
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase) {
        registerJdbcBacked(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static void registerJdbcSource(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static void registerDeclaredLoaders(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<MigrationDemoOrderEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<MigrationDemoOrderEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<MigrationDemoOrderEntity> relationBatchLoader, EntityPageLoader<MigrationDemoOrderEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<MigrationDemoOrderEntity> relationBatchLoader, EntityPageLoader<MigrationDemoOrderEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<MigrationDemoOrderEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<MigrationDemoOrderEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<MigrationDemoOrderEntity> relationBatchLoader, EntityPageLoader<MigrationDemoOrderEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<MigrationDemoOrderEntity> relationBatchLoader, EntityPageLoader<MigrationDemoOrderEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
        cacheDatabase.registerProjection(METADATA, MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
    }

    public static CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
        return CacheWarmPlan.builder(METADATA.entityName())
                .name(name)
                .querySpec(querySpec)
                .maxRows(maxRows)
                .build();
    }

    public static ActiveRecordInstance<MigrationDemoOrderEntity, java.lang.Long> attach(CacheSession session, MigrationDemoOrderEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session));
    }

    public static ActiveRecordInstance<MigrationDemoOrderEntity, java.lang.Long> attach(CacheSession session, CachePolicy cachePolicy, MigrationDemoOrderEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session, cachePolicy));
    }

    public static MigrationDemoOrderEntity save(CacheSession session, MigrationDemoOrderEntity entity) {
        return repository(session).save(entity);
    }

    public static MigrationDemoOrderEntity save(CacheSession session, CachePolicy cachePolicy, MigrationDemoOrderEntity entity) {
        return repository(session, cachePolicy).save(entity);
    }

    public static Optional<MigrationDemoOrderEntity> findById(CacheSession session, java.lang.Long id) {
        return repository(session).findById(id);
    }

    public static Optional<MigrationDemoOrderEntity> findById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        return repository(session, cachePolicy).findById(id);
    }

    public static List<MigrationDemoOrderEntity> findPage(CacheSession session, PageWindow pageWindow) {
        return repository(session).findPage(pageWindow);
    }

    public static List<MigrationDemoOrderEntity> findPage(CacheSession session, CachePolicy cachePolicy, PageWindow pageWindow) {
        return repository(session, cachePolicy).findPage(pageWindow);
    }

    public static List<MigrationDemoOrderEntity> query(CacheSession session, QuerySpec querySpec) {
        return repository(session).query(querySpec);
    }

    public static List<MigrationDemoOrderEntity> query(CacheSession session, CachePolicy cachePolicy, QuerySpec querySpec) {
        return repository(session, cachePolicy).query(querySpec);
    }

    public static void deleteById(CacheSession session, java.lang.Long id) {
        repository(session).deleteById(id);
    }

    public static void deleteById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        repository(session, cachePolicy).deleteById(id);
    }

    public static Scope using(CacheSession session) {
        return new Scope(session, null);
    }

    public static Scope using(CacheSession session, CachePolicy cachePolicy) {
        return new Scope(session, cachePolicy);
    }

    public static final class Scope {
        private final CacheSession cacheSession;
        private final EntityRepository<MigrationDemoOrderEntity, java.lang.Long> repository;
        private volatile SourceRepository<MigrationDemoOrderEntity, java.lang.Long> sourceRepository;
        private final Projections projections;

        private Scope(CacheSession cacheSession, CachePolicy cachePolicy) {
            this.cacheSession = cacheSession;
            this.repository = cachePolicy == null ? MigrationDemoOrderEntityCacheBinding.repository(cacheSession) : MigrationDemoOrderEntityCacheBinding.repository(cacheSession, cachePolicy);
            this.projections = new Projections(this);
        }

        public EntityRepository<MigrationDemoOrderEntity, java.lang.Long> repository() {
            return repository;
        }

        public ActiveRecordInstance<MigrationDemoOrderEntity, java.lang.Long> attach(MigrationDemoOrderEntity entity) {
            return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository);
        }

        public MigrationDemoOrderEntity save(MigrationDemoOrderEntity entity) {
            return repository.save(entity);
        }

        public WriteReceipt<MigrationDemoOrderEntity, java.lang.Long> saveWithReceipt(MigrationDemoOrderEntity entity) {
            return repository.saveWithReceipt(entity);
        }

        public WriteReceipt<MigrationDemoOrderEntity, java.lang.Long> save(MigrationDemoOrderEntity entity, long expectedVersion) {
            return repository.save(entity, expectedVersion);
        }

        public WriteReceipt<MigrationDemoOrderEntity, java.lang.Long> saveAfter(MigrationDemoOrderEntity entity, WriteDependency dependency) {
            return repository.saveAfter(entity, dependency);
        }

        public List<WriteReceipt<MigrationDemoOrderEntity, java.lang.Long>> saveAll(java.util.Collection<MigrationDemoOrderEntity> entities) {
            return repository.saveAll(entities);
        }

        public Optional<MigrationDemoOrderEntity> findById(java.lang.Long id) {
            return repository.findById(id);
        }

        public Optional<VersionedEntity<MigrationDemoOrderEntity>> findVersionedById(java.lang.Long id) {
            return repository.findVersionedById(id);
        }

        public Optional<WriteDependency> dependency(java.lang.Long id) {
            return repository.findVersionedById(id).map(versioned -> new WriteDependency(METADATA.redisNamespace(), String.valueOf(id), versioned.version()));
        }

        public List<MigrationDemoOrderEntity> findPage(PageWindow pageWindow) {
            return repository.findPage(pageWindow);
        }

        public List<MigrationDemoOrderEntity> query(QuerySpec querySpec) {
            return repository.query(querySpec);
        }

        public <K> Map<K, List<MigrationDemoOrderEntity>> queryPartitions(PartitionedQuerySpec<K> querySpec) {
            return repository.queryPartitions(querySpec);
        }

        public SourceRepository<MigrationDemoOrderEntity, java.lang.Long> source() {
            SourceRepository<MigrationDemoOrderEntity, java.lang.Long> resolved = sourceRepository;
            if (resolved == null) {
                synchronized (this) {
                    resolved = sourceRepository;
                    if (resolved == null) {
                        resolved = cacheSession.sourceRepository(METADATA, CODEC);
                        sourceRepository = resolved;
                    }
                }
            }
            return resolved;
        }

        public void deleteById(java.lang.Long id) {
            repository.deleteById(id);
        }

        public CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
            return MigrationDemoOrderEntityCacheBinding.warmPlan(name, querySpec, maxRows);
        }

        public Projections projections() {
            return projections;
        }
    }

    public static final class Projections {
        private final Scope scope;
        private volatile ProjectionRepository<com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderSummaryView, java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHot;
        private volatile ProjectionRepository<com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderRankedView, java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHot;

        private Projections(Scope scope) {
            this.scope = scope;
        }

        public com.reactor.cachedb.core.projection.EntityProjection<com.reactor.cachedb.examples.demo.entity.MigrationDemoOrderEntity,com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderSummaryView,java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection() {
            return MigrationDemoOrderEntityCacheBinding.MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection();
        }

        public ProjectionRepository<com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderSummaryView, java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHot() {
            ProjectionRepository<com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderSummaryView, java.lang.Long> resolved = MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHot;
            if (resolved == null) {
                synchronized (this) {
                    resolved = MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHot;
                    if (resolved == null) {
                        resolved = scope.repository().projected(MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHotProjection());
                        MigrationDemoCustomerEntityMigrationDemoOrderEntitySummaryHot = resolved;
                    }
                }
            }
            return resolved;
        }

        public com.reactor.cachedb.core.projection.EntityProjection<com.reactor.cachedb.examples.demo.entity.MigrationDemoOrderEntity,com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderRankedView,java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection() {
            return MigrationDemoOrderEntityCacheBinding.MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection();
        }

        public ProjectionRepository<com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderRankedView, java.lang.Long> MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHot() {
            ProjectionRepository<com.reactor.cachedb.examples.demo.DemoMigrationReadModelPatterns.MigrationOrderRankedView, java.lang.Long> resolved = MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHot;
            if (resolved == null) {
                synchronized (this) {
                    resolved = MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHot;
                    if (resolved == null) {
                        resolved = scope.repository().projected(MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHotProjection());
                        MigrationDemoCustomerEntityMigrationDemoOrderEntityRankedHot = resolved;
                    }
                }
            }
            return resolved;
        }
    }
}
