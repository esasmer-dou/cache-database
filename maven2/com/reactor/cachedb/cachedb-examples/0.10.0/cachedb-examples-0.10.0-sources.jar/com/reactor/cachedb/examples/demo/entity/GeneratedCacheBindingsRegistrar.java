package com.reactor.cachedb.examples.demo.entity;

import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.CachePolicyCatalog;
import com.reactor.cachedb.starter.CacheDatabase;

public final class GeneratedCacheBindingsRegistrar implements com.reactor.cachedb.starter.GeneratedCacheBindingsRegistrar {
    @Override
    public String packageName() {
        return "com.reactor.cachedb.examples.demo.entity";
    }

    @Override
    public void register(CacheDatabase cacheDatabase) {
        GeneratedCacheBindings.register(cacheDatabase);
    }

    @Override
    public void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        GeneratedCacheBindings.register(cacheDatabase, cachePolicy);
    }

    @Override
    public java.util.List<String> entityNames() {
        return java.util.List.of("DemoCartEntity", "DemoCustomerEntity", "DemoOrderEntity", "DemoOrderLineEntity", "DemoProductEntity", "MigrationDemoCustomerEntity", "MigrationDemoOrderEntity");
    }

    @Override
    public void registerJdbcSources(CacheDatabase cacheDatabase, CachePolicyCatalog policyCatalog) {
        GeneratedCacheBindings.registerJdbcSources(cacheDatabase, policyCatalog);
    }

    @Override
    public void registerDeclaredLoaders(CacheDatabase cacheDatabase, CachePolicyCatalog policyCatalog) {
        GeneratedCacheBindings.registerDeclaredLoaders(cacheDatabase, policyCatalog);
    }
}
