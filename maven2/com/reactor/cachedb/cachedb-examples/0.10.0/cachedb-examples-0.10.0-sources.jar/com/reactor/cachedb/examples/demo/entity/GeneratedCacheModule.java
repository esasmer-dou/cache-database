package com.reactor.cachedb.examples.demo.entity;

import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.CachePolicyCatalog;
import com.reactor.cachedb.starter.CacheDatabase;

public final class GeneratedCacheModule {
    private GeneratedCacheModule() {
    }

    public static void register(CacheDatabase cacheDatabase) {
        GeneratedCacheBindings.register(cacheDatabase);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        GeneratedCacheBindings.register(cacheDatabase, cachePolicy);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase) {
        registerJdbcBacked(cacheDatabase, CachePolicyCatalog.empty());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicyCatalog policyCatalog) {
        GeneratedCacheBindings.registerJdbcSources(cacheDatabase, policyCatalog);
        GeneratedCacheBindings.registerDeclaredLoaders(cacheDatabase, policyCatalog);
    }

    public static Scope using(CacheSession cacheSession) {
        return new Scope(cacheSession, null);
    }

    public static Scope using(CacheSession cacheSession, CachePolicy cachePolicy) {
        return new Scope(cacheSession, cachePolicy);
    }

    public static final class Scope {
        private final CacheSession cacheSession;
        private final CachePolicy cachePolicy;
        private volatile DemoCartEntityCacheBinding.Scope demoCartsScope;
        private volatile DemoCustomerEntityCacheBinding.Scope demoCustomersScope;
        private volatile DemoOrderEntityCacheBinding.Scope demoOrdersScope;
        private volatile DemoOrderLineEntityCacheBinding.Scope demoOrderLinesScope;
        private volatile DemoProductEntityCacheBinding.Scope demoProductsScope;
        private volatile MigrationDemoCustomerEntityCacheBinding.Scope migrationDemoCustomersScope;
        private volatile MigrationDemoOrderEntityCacheBinding.Scope migrationDemoOrdersScope;

        private Scope(CacheSession cacheSession, CachePolicy cachePolicy) {
            this.cacheSession = java.util.Objects.requireNonNull(cacheSession, "cacheSession");
            this.cachePolicy = cachePolicy;
        }

        public DemoCartEntityCacheBinding.Scope demoCarts() {
            DemoCartEntityCacheBinding.Scope resolved = demoCartsScope;
            if (resolved == null) {
                synchronized (this) {
                    resolved = demoCartsScope;
                    if (resolved == null) {
                        resolved = cachePolicy == null ? DemoCartEntityCacheBinding.using(cacheSession) : DemoCartEntityCacheBinding.using(cacheSession, cachePolicy);
                        demoCartsScope = resolved;
                    }
                }
            }
            return resolved;
        }

        public DemoCustomerEntityCacheBinding.Scope demoCustomers() {
            DemoCustomerEntityCacheBinding.Scope resolved = demoCustomersScope;
            if (resolved == null) {
                synchronized (this) {
                    resolved = demoCustomersScope;
                    if (resolved == null) {
                        resolved = cachePolicy == null ? DemoCustomerEntityCacheBinding.using(cacheSession) : DemoCustomerEntityCacheBinding.using(cacheSession, cachePolicy);
                        demoCustomersScope = resolved;
                    }
                }
            }
            return resolved;
        }

        public DemoOrderEntityCacheBinding.Scope demoOrders() {
            DemoOrderEntityCacheBinding.Scope resolved = demoOrdersScope;
            if (resolved == null) {
                synchronized (this) {
                    resolved = demoOrdersScope;
                    if (resolved == null) {
                        resolved = cachePolicy == null ? DemoOrderEntityCacheBinding.using(cacheSession) : DemoOrderEntityCacheBinding.using(cacheSession, cachePolicy);
                        demoOrdersScope = resolved;
                    }
                }
            }
            return resolved;
        }

        public DemoOrderLineEntityCacheBinding.Scope demoOrderLines() {
            DemoOrderLineEntityCacheBinding.Scope resolved = demoOrderLinesScope;
            if (resolved == null) {
                synchronized (this) {
                    resolved = demoOrderLinesScope;
                    if (resolved == null) {
                        resolved = cachePolicy == null ? DemoOrderLineEntityCacheBinding.using(cacheSession) : DemoOrderLineEntityCacheBinding.using(cacheSession, cachePolicy);
                        demoOrderLinesScope = resolved;
                    }
                }
            }
            return resolved;
        }

        public DemoProductEntityCacheBinding.Scope demoProducts() {
            DemoProductEntityCacheBinding.Scope resolved = demoProductsScope;
            if (resolved == null) {
                synchronized (this) {
                    resolved = demoProductsScope;
                    if (resolved == null) {
                        resolved = cachePolicy == null ? DemoProductEntityCacheBinding.using(cacheSession) : DemoProductEntityCacheBinding.using(cacheSession, cachePolicy);
                        demoProductsScope = resolved;
                    }
                }
            }
            return resolved;
        }

        public MigrationDemoCustomerEntityCacheBinding.Scope migrationDemoCustomers() {
            MigrationDemoCustomerEntityCacheBinding.Scope resolved = migrationDemoCustomersScope;
            if (resolved == null) {
                synchronized (this) {
                    resolved = migrationDemoCustomersScope;
                    if (resolved == null) {
                        resolved = cachePolicy == null ? MigrationDemoCustomerEntityCacheBinding.using(cacheSession) : MigrationDemoCustomerEntityCacheBinding.using(cacheSession, cachePolicy);
                        migrationDemoCustomersScope = resolved;
                    }
                }
            }
            return resolved;
        }

        public MigrationDemoOrderEntityCacheBinding.Scope migrationDemoOrders() {
            MigrationDemoOrderEntityCacheBinding.Scope resolved = migrationDemoOrdersScope;
            if (resolved == null) {
                synchronized (this) {
                    resolved = migrationDemoOrdersScope;
                    if (resolved == null) {
                        resolved = cachePolicy == null ? MigrationDemoOrderEntityCacheBinding.using(cacheSession) : MigrationDemoOrderEntityCacheBinding.using(cacheSession, cachePolicy);
                        migrationDemoOrdersScope = resolved;
                    }
                }
            }
            return resolved;
        }
    }
}
