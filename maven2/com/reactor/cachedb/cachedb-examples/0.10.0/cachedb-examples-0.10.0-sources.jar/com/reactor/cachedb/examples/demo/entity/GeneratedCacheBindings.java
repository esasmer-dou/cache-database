package com.reactor.cachedb.examples.demo.entity;

import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.CachePolicyCatalog;
import com.reactor.cachedb.starter.CacheDatabase;

public final class GeneratedCacheBindings {
    private GeneratedCacheBindings() {
    }

    public static void register(CacheDatabase cacheDatabase) {
        DemoCartEntityCacheBinding.register(cacheDatabase);
        DemoCustomerEntityCacheBinding.register(cacheDatabase);
        DemoOrderEntityCacheBinding.register(cacheDatabase);
        DemoOrderLineEntityCacheBinding.register(cacheDatabase);
        DemoProductEntityCacheBinding.register(cacheDatabase);
        MigrationDemoCustomerEntityCacheBinding.register(cacheDatabase);
        MigrationDemoOrderEntityCacheBinding.register(cacheDatabase);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        DemoCartEntityCacheBinding.register(cacheDatabase, cachePolicy);
        DemoCustomerEntityCacheBinding.register(cacheDatabase, cachePolicy);
        DemoOrderEntityCacheBinding.register(cacheDatabase, cachePolicy);
        DemoOrderLineEntityCacheBinding.register(cacheDatabase, cachePolicy);
        DemoProductEntityCacheBinding.register(cacheDatabase, cachePolicy);
        MigrationDemoCustomerEntityCacheBinding.register(cacheDatabase, cachePolicy);
        MigrationDemoOrderEntityCacheBinding.register(cacheDatabase, cachePolicy);
    }

    public static void registerJdbcSources(CacheDatabase cacheDatabase, CachePolicyCatalog policyCatalog) {
        CachePolicyCatalog resolvedCatalog = policyCatalog == null ? CachePolicyCatalog.empty() : policyCatalog;
        CachePolicy fallback = cacheDatabase.config().resourceLimits().defaultCachePolicy();
        DemoCartEntityCacheBinding.registerJdbcSource(cacheDatabase, resolvedCatalog.resolve("DemoCartEntity", fallback));
        DemoCustomerEntityCacheBinding.registerJdbcSource(cacheDatabase, resolvedCatalog.resolve("DemoCustomerEntity", fallback));
        DemoOrderEntityCacheBinding.registerJdbcSource(cacheDatabase, resolvedCatalog.resolve("DemoOrderEntity", fallback));
        DemoOrderLineEntityCacheBinding.registerJdbcSource(cacheDatabase, resolvedCatalog.resolve("DemoOrderLineEntity", fallback));
        DemoProductEntityCacheBinding.registerJdbcSource(cacheDatabase, resolvedCatalog.resolve("DemoProductEntity", fallback));
        MigrationDemoCustomerEntityCacheBinding.registerJdbcSource(cacheDatabase, resolvedCatalog.resolve("MigrationDemoCustomerEntity", fallback));
        MigrationDemoOrderEntityCacheBinding.registerJdbcSource(cacheDatabase, resolvedCatalog.resolve("MigrationDemoOrderEntity", fallback));
    }

    public static void registerDeclaredLoaders(CacheDatabase cacheDatabase, CachePolicyCatalog policyCatalog) {
        CachePolicyCatalog resolvedCatalog = policyCatalog == null ? CachePolicyCatalog.empty() : policyCatalog;
        CachePolicy fallback = cacheDatabase.config().resourceLimits().defaultCachePolicy();
        DemoCartEntityCacheBinding.registerDeclaredLoaders(cacheDatabase, resolvedCatalog.resolve("DemoCartEntity", fallback));
        DemoCustomerEntityCacheBinding.registerDeclaredLoaders(cacheDatabase, resolvedCatalog.resolve("DemoCustomerEntity", fallback));
        DemoOrderEntityCacheBinding.registerDeclaredLoaders(cacheDatabase, resolvedCatalog.resolve("DemoOrderEntity", fallback));
        DemoOrderLineEntityCacheBinding.registerDeclaredLoaders(cacheDatabase, resolvedCatalog.resolve("DemoOrderLineEntity", fallback));
        DemoProductEntityCacheBinding.registerDeclaredLoaders(cacheDatabase, resolvedCatalog.resolve("DemoProductEntity", fallback));
        MigrationDemoCustomerEntityCacheBinding.registerDeclaredLoaders(cacheDatabase, resolvedCatalog.resolve("MigrationDemoCustomerEntity", fallback));
        MigrationDemoOrderEntityCacheBinding.registerDeclaredLoaders(cacheDatabase, resolvedCatalog.resolve("MigrationDemoOrderEntity", fallback));
    }
}
