package com.reactor.cachedb.examples.entity;

import com.reactor.cachedb.core.codec.LengthPrefixedPayloadCodec;
import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.api.EntityRepository;
import com.reactor.cachedb.core.api.ProjectionRepository;
import com.reactor.cachedb.core.api.SourceRepository;
import com.reactor.cachedb.core.active.ActiveRecordInstance;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.PageWindow;
import com.reactor.cachedb.core.plan.FetchPlan;
import com.reactor.cachedb.core.model.EntityCodec;
import com.reactor.cachedb.core.model.EntityMetadata;
import com.reactor.cachedb.core.model.WriteDependency;
import com.reactor.cachedb.core.model.WriteReceipt;
import com.reactor.cachedb.core.page.EntityPageLoader;
import com.reactor.cachedb.core.page.VersionedEntity;
import com.reactor.cachedb.core.model.RelationDefinition;
import com.reactor.cachedb.core.model.RelationKind;
import com.reactor.cachedb.core.projection.EntityProjection;
import com.reactor.cachedb.core.query.QuerySpec;
import com.reactor.cachedb.core.query.PartitionedQuerySpec;
import com.reactor.cachedb.core.query.QuerySort;
import com.reactor.cachedb.core.route.RouteCacheContract;
import com.reactor.cachedb.core.route.RouteCacheContext;
import com.reactor.cachedb.core.route.RouteCacheStrictMode;
import com.reactor.cachedb.core.relation.RelationBatchLoader;
import com.reactor.cachedb.core.relation.CompositeRelationBatchLoader;
import com.reactor.cachedb.core.relation.PartitionedRelationBatchLoader;
import com.reactor.cachedb.starter.CacheDatabase;
import com.reactor.cachedb.starter.CacheWarmPlan;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public final class UserEntityCacheBinding {
    public static final EntityMetadata<UserEntity, java.lang.Long> METADATA = new Metadata();
    public static final EntityCodec<UserEntity> CODEC = new Codec();

    private UserEntityCacheBinding() {
    }

    public static UserEntity withId(UserEntity entity, java.lang.Long id) {
        java.util.Objects.requireNonNull(entity, "entity");
        java.util.Objects.requireNonNull(id, "id");
        entity.id = id;
        return entity;
    }

    private static final class Metadata implements EntityMetadata<UserEntity, java.lang.Long> {
        @Override
        public String entityName() {
            return "UserEntity";
        }

        @Override
        public String tableName() {
            return "cachedb_example_users";
        }

        @Override
        public String redisNamespace() {
            return "users";
        }

        @Override
        public String idColumn() {
            return "id";
        }

        @Override
        public String versionColumn() {
            return "entity_version";
        }

        @Override
        public String deletedColumn() {
            return null;
        }

        @Override
        public String activeMarkerValue() {
            return "false";
        }

        @Override
        public String deletedMarkerValue() {
            return "true";
        }

        @Override
        public Class<UserEntity> entityType() {
            return UserEntity.class;
        }

        @Override
        public Function<UserEntity, java.lang.Long> idAccessor() {
            return entity -> entity.id;
        }

        @Override
        public List<String> columns() {
            return List.of("id", "username", "status");
        }

        @Override
        public Map<String, String> columnTypes() {
            LinkedHashMap<String, String> columnTypes = new LinkedHashMap<>();
            columnTypes.put("id", "java.lang.Long");
            columnTypes.put("username", "java.lang.String");
            columnTypes.put("status", "java.lang.String");
            return columnTypes;
        }

        @Override
        public Map<String, List<String>> partitionedSortIndexes() {
            return Map.of();
        }

        @Override
        public List<RelationDefinition> relations() {
            return List.of(
                    new RelationDefinition("orders", "OrderEntity", "userId", RelationKind.ONE_TO_MANY, true)
            );
        }
    }

    private static final class Codec implements EntityCodec<UserEntity> {
        @Override
        public String toRedisValue(UserEntity entity) {
            LinkedHashMap<String, String> values = new LinkedHashMap<>();
            values.put("id", entity.id == null ? null : String.valueOf(entity.id));
            values.put("username", entity.username);
            values.put("status", entity.status);
            return LengthPrefixedPayloadCodec.encode(values);
        }

        @Override
        public UserEntity fromRedisValue(String encoded) {
            Map<String, String> values = LengthPrefixedPayloadCodec.decode(encoded);
            UserEntity entity = new UserEntity();
            entity.id = values.get("id") == null ? null : Long.valueOf(values.get("id"));
            entity.username = values.get("username");
            entity.status = values.get("status");
            return entity;
        }

        @Override
        public UserEntity fromColumns(Map<String, Object> columns) {
            UserEntity entity = new UserEntity();
            entity.id = columnValue(columns, "id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "id"))));
            entity.username = columnValue(columns, "username") == null ? null : String.valueOf(columnValue(columns, "username"));
            entity.status = columnValue(columns, "status") == null ? null : String.valueOf(columnValue(columns, "status"));
            return entity;
        }

        @Override
        public Map<String, Object> toColumns(UserEntity entity) {
            LinkedHashMap<String, Object> columns = new LinkedHashMap<>();
            columns.put("id", entity.id);
            columns.put("username", entity.username);
            columns.put("status", entity.status);
            return columns;
        }
    }

    public static RelationBatchLoader<UserEntity> relationLoader(CacheDatabase cacheDatabase) {
        return relationLoader(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static RelationBatchLoader<UserEntity> relationLoader(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        return new CompositeRelationBatchLoader<>(List.of(
                new com.reactor.cachedb.examples.loader.UserOrdersRelationBatchLoader(),
                new PartitionedRelationBatchLoader<>("orders", 100, 32, com.reactor.cachedb.examples.entity.OrderEntityCacheBinding.repository(cacheDatabase), parent -> parent.id, (parent, children) -> parent.orders = children, "user_id", QuerySort.asc("id"))
        ));
    }

    public static EntityPageLoader<UserEntity> pageLoader(CacheDatabase cacheDatabase) {
        return pageLoader(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static EntityPageLoader<UserEntity> pageLoader(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        return new com.reactor.cachedb.examples.loader.UserPageLoader();
    }

    public static QuerySpec activeUsersQuery(int limit) {
        return UserEntity.activeUsersQuery(limit);
    }

    public static List<UserEntity> activeUsers(CacheSession cacheSession, int limit) {
        return repository(cacheSession).query(activeUsersQuery(limit));
    }

    public static List<UserEntity> activeUsers(CacheSession cacheSession, CachePolicy cachePolicy, int limit) {
        return repository(cacheSession, cachePolicy).query(activeUsersQuery(limit));
    }

    public static List<UserEntity> activeUsers(EntityRepository<UserEntity, java.lang.Long> entityRepository, int limit) {
        return entityRepository.query(activeUsersQuery(limit));
    }

    public static <P> List<P> activeUsers(ProjectionRepository<P, java.lang.Long> projectionRepository, int limit) {
        return projectionRepository.query(activeUsersQuery(limit));
    }

    public static FetchPlan ordersPreviewFetchPlan(int relationLimit) {
        return UserEntity.ordersPreviewFetchPlan(relationLimit);
    }

    public static EntityRepository<UserEntity, java.lang.Long> ordersPreviewRepository(CacheSession cacheSession, int relationLimit) {
        return repository(cacheSession).withFetchPlan(ordersPreviewFetchPlan(relationLimit));
    }

    public static EntityRepository<UserEntity, java.lang.Long> ordersPreviewRepository(CacheSession cacheSession, CachePolicy cachePolicy, int relationLimit) {
        return repository(cacheSession, cachePolicy).withFetchPlan(ordersPreviewFetchPlan(relationLimit));
    }

    public static EntityRepository<UserEntity, java.lang.Long> ordersPreviewRepository(EntityRepository<UserEntity, java.lang.Long> entityRepository, int relationLimit) {
        return entityRepository.withFetchPlan(ordersPreviewFetchPlan(relationLimit));
    }

    public static PageWindow usersPageWindow(int pageNumber, int pageSize) {
        return UserEntity.usersPageWindow(pageNumber, pageSize);
    }

    public static List<UserEntity> usersPage(CacheSession cacheSession, int pageNumber, int pageSize) {
        return repository(cacheSession).findPage(usersPageWindow(pageNumber, pageSize));
    }

    public static List<UserEntity> usersPage(CacheSession cacheSession, CachePolicy cachePolicy, int pageNumber, int pageSize) {
        return repository(cacheSession, cachePolicy).findPage(usersPageWindow(pageNumber, pageSize));
    }

    public static List<UserEntity> usersPage(EntityRepository<UserEntity, java.lang.Long> entityRepository, int pageNumber, int pageSize) {
        return entityRepository.findPage(usersPageWindow(pageNumber, pageSize));
    }

    public static UserEntity activateUserCommand(long id, java.lang.String username) {
        return UserEntity.activateUserCommand(id, username);
    }

    public static UserEntity activateUser(CacheSession cacheSession, long id, java.lang.String username) {
        return repository(cacheSession).save(activateUserCommand(id, username));
    }

    public static UserEntity activateUser(CacheSession cacheSession, CachePolicy cachePolicy, long id, java.lang.String username) {
        return repository(cacheSession, cachePolicy).save(activateUserCommand(id, username));
    }

    public static UserEntity activateUser(EntityRepository<UserEntity, java.lang.Long> entityRepository, long id, java.lang.String username) {
        return entityRepository.save(activateUserCommand(id, username));
    }

    public static java.lang.Long deleteUserId(long id) {
        return UserEntity.deleteUserId(id);
    }

    public static void deleteUser(CacheSession cacheSession, long id) {
        repository(cacheSession).deleteById(deleteUserId(id));
    }

    public static void deleteUser(CacheSession cacheSession, CachePolicy cachePolicy, long id) {
        repository(cacheSession, cachePolicy).deleteById(deleteUserId(id));
    }

    public static void deleteUser(EntityRepository<UserEntity, java.lang.Long> entityRepository, long id) {
        entityRepository.deleteById(deleteUserId(id));
    }

    public static EntityRepository<UserEntity, java.lang.Long> repository(CacheSession session) {
        return session.repository(METADATA, CODEC);
    }

    public static EntityRepository<UserEntity, java.lang.Long> repository(CacheSession session, CachePolicy cachePolicy) {
        return session.repository(METADATA, CODEC, cachePolicy);
    }

    public static void register(CacheDatabase cacheDatabase) {
        register(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationLoader(cacheDatabase, cachePolicy), pageLoader(cacheDatabase, cachePolicy));
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase) {
        registerJdbcBacked(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationLoader(cacheDatabase, cachePolicy), pageLoader(cacheDatabase, cachePolicy));
    }

    public static void registerJdbcSource(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
    }

    public static void registerDeclaredLoaders(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationLoader(cacheDatabase, cachePolicy), pageLoader(cacheDatabase, cachePolicy));
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<UserEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<UserEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<UserEntity> relationBatchLoader, EntityPageLoader<UserEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<UserEntity> relationBatchLoader, EntityPageLoader<UserEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<UserEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<UserEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<UserEntity> relationBatchLoader, EntityPageLoader<UserEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<UserEntity> relationBatchLoader, EntityPageLoader<UserEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
    }

    public static CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
        return CacheWarmPlan.builder(METADATA.entityName())
                .name(name)
                .querySpec(querySpec)
                .maxRows(maxRows)
                .build();
    }

    public static ActiveRecordInstance<UserEntity, java.lang.Long> attach(CacheSession session, UserEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session));
    }

    public static ActiveRecordInstance<UserEntity, java.lang.Long> attach(CacheSession session, CachePolicy cachePolicy, UserEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session, cachePolicy));
    }

    public static UserEntity save(CacheSession session, UserEntity entity) {
        return repository(session).save(entity);
    }

    public static UserEntity save(CacheSession session, CachePolicy cachePolicy, UserEntity entity) {
        return repository(session, cachePolicy).save(entity);
    }

    public static Optional<UserEntity> findById(CacheSession session, java.lang.Long id) {
        return repository(session).findById(id);
    }

    public static Optional<UserEntity> findById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        return repository(session, cachePolicy).findById(id);
    }

    public static List<UserEntity> findPage(CacheSession session, PageWindow pageWindow) {
        return repository(session).findPage(pageWindow);
    }

    public static List<UserEntity> findPage(CacheSession session, CachePolicy cachePolicy, PageWindow pageWindow) {
        return repository(session, cachePolicy).findPage(pageWindow);
    }

    public static List<UserEntity> query(CacheSession session, QuerySpec querySpec) {
        return repository(session).query(querySpec);
    }

    public static List<UserEntity> query(CacheSession session, CachePolicy cachePolicy, QuerySpec querySpec) {
        return repository(session, cachePolicy).query(querySpec);
    }

    public static void deleteById(CacheSession session, java.lang.Long id) {
        repository(session).deleteById(id);
    }

    public static void deleteById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        repository(session, cachePolicy).deleteById(id);
    }

    public static Scope using(CacheSession session) {
        return new Scope(session, null);
    }

    public static Scope using(CacheSession session, CachePolicy cachePolicy) {
        return new Scope(session, cachePolicy);
    }

    public static final class Scope {
        private final CacheSession cacheSession;
        private final EntityRepository<UserEntity, java.lang.Long> repository;
        private volatile SourceRepository<UserEntity, java.lang.Long> sourceRepository;
        private final Queries queries;
        private final Fetches fetches;
        private final Pages pages;
        private final Commands commands;
        private final Deletes deletes;

        private Scope(CacheSession cacheSession, CachePolicy cachePolicy) {
            this.cacheSession = cacheSession;
            this.repository = cachePolicy == null ? UserEntityCacheBinding.repository(cacheSession) : UserEntityCacheBinding.repository(cacheSession, cachePolicy);
            this.queries = new Queries(this);
            this.fetches = new Fetches(this);
            this.pages = new Pages(this);
            this.commands = new Commands(this);
            this.deletes = new Deletes(this);
        }

        public EntityRepository<UserEntity, java.lang.Long> repository() {
            return repository;
        }

        public ActiveRecordInstance<UserEntity, java.lang.Long> attach(UserEntity entity) {
            return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository);
        }

        public UserEntity save(UserEntity entity) {
            return repository.save(entity);
        }

        public WriteReceipt<UserEntity, java.lang.Long> saveWithReceipt(UserEntity entity) {
            return repository.saveWithReceipt(entity);
        }

        public WriteReceipt<UserEntity, java.lang.Long> save(UserEntity entity, long expectedVersion) {
            return repository.save(entity, expectedVersion);
        }

        public WriteReceipt<UserEntity, java.lang.Long> saveAfter(UserEntity entity, WriteDependency dependency) {
            return repository.saveAfter(entity, dependency);
        }

        public List<WriteReceipt<UserEntity, java.lang.Long>> saveAll(java.util.Collection<UserEntity> entities) {
            return repository.saveAll(entities);
        }

        public Optional<UserEntity> findById(java.lang.Long id) {
            return repository.findById(id);
        }

        public Optional<VersionedEntity<UserEntity>> findVersionedById(java.lang.Long id) {
            return repository.findVersionedById(id);
        }

        public Optional<WriteDependency> dependency(java.lang.Long id) {
            return repository.findVersionedById(id).map(versioned -> new WriteDependency(METADATA.redisNamespace(), String.valueOf(id), versioned.version()));
        }

        public List<UserEntity> findPage(PageWindow pageWindow) {
            return repository.findPage(pageWindow);
        }

        public List<UserEntity> query(QuerySpec querySpec) {
            return repository.query(querySpec);
        }

        public <K> Map<K, List<UserEntity>> queryPartitions(PartitionedQuerySpec<K> querySpec) {
            return repository.queryPartitions(querySpec);
        }

        public SourceRepository<UserEntity, java.lang.Long> source() {
            SourceRepository<UserEntity, java.lang.Long> resolved = sourceRepository;
            if (resolved == null) {
                synchronized (this) {
                    resolved = sourceRepository;
                    if (resolved == null) {
                        resolved = cacheSession.sourceRepository(METADATA, CODEC);
                        sourceRepository = resolved;
                    }
                }
            }
            return resolved;
        }

        public void deleteById(java.lang.Long id) {
            repository.deleteById(id);
        }

        public CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
            return UserEntityCacheBinding.warmPlan(name, querySpec, maxRows);
        }

        public Queries queries() {
            return queries;
        }

        public Fetches fetches() {
            return fetches;
        }

        public Pages pages() {
            return pages;
        }

        public Commands commands() {
            return commands;
        }

        public Deletes deletes() {
            return deletes;
        }
    }

    public static final class Queries {
        private final Scope scope;

        private Queries(Scope scope) {
            this.scope = scope;
        }

        public QuerySpec activeUsersQuery(int limit) {
            return UserEntityCacheBinding.activeUsersQuery(limit);
        }

        public List<UserEntity> activeUsers(int limit) {
            return scope.repository().query(activeUsersQuery(limit));
        }
    }

    public static final class Fetches {
        private final Scope scope;

        private Fetches(Scope scope) {
            this.scope = scope;
        }

        public FetchPlan ordersPreviewFetchPlan(int relationLimit) {
            return UserEntityCacheBinding.ordersPreviewFetchPlan(relationLimit);
        }

        public EntityRepository<UserEntity, java.lang.Long> ordersPreview(int relationLimit) {
            return scope.repository().withFetchPlan(ordersPreviewFetchPlan(relationLimit));
        }
    }

    public static final class Pages {
        private final Scope scope;

        private Pages(Scope scope) {
            this.scope = scope;
        }

        public PageWindow usersPageWindow(int pageNumber, int pageSize) {
            return UserEntityCacheBinding.usersPageWindow(pageNumber, pageSize);
        }

        public List<UserEntity> usersPage(int pageNumber, int pageSize) {
            return scope.repository().findPage(usersPageWindow(pageNumber, pageSize));
        }
    }

    public static final class Commands {
        private final Scope scope;

        private Commands(Scope scope) {
            this.scope = scope;
        }

        public UserEntity activateUserCommand(long id, java.lang.String username) {
            return UserEntityCacheBinding.activateUserCommand(id, username);
        }

        public UserEntity activateUser(long id, java.lang.String username) {
            return scope.repository().save(activateUserCommand(id, username));
        }
    }

    public static final class Deletes {
        private final Scope scope;

        private Deletes(Scope scope) {
            this.scope = scope;
        }

        public java.lang.Long deleteUserId(long id) {
            return UserEntityCacheBinding.deleteUserId(id);
        }

        public void deleteUser(long id) {
            scope.repository().deleteById(deleteUserId(id));
        }
    }
}
