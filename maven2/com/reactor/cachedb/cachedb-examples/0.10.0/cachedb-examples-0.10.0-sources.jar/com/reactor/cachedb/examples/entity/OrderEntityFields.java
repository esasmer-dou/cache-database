package com.reactor.cachedb.examples.entity;

/** Compile-time generated field metamodel. */
public final class OrderEntityFields {
    public static final com.reactor.cachedb.core.query.CacheField<OrderEntity, java.lang.Long> id = new com.reactor.cachedb.core.query.CacheField<>("id", "id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<OrderEntity, java.lang.Long> userId = new com.reactor.cachedb.core.query.CacheField<>("userId", "user_id", java.lang.Long.class);
    public static final com.reactor.cachedb.core.query.CacheField<OrderEntity, java.lang.Double> totalAmount = new com.reactor.cachedb.core.query.CacheField<>("totalAmount", "total_amount", java.lang.Double.class);
    public static final com.reactor.cachedb.core.query.CacheField<OrderEntity, java.lang.String> status = new com.reactor.cachedb.core.query.CacheField<>("status", "status", java.lang.String.class);

    private OrderEntityFields() {
    }
}
