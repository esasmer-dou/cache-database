package com.reactor.cachedb.examples.demo.entity;

import com.reactor.cachedb.core.codec.LengthPrefixedPayloadCodec;
import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.api.EntityRepository;
import com.reactor.cachedb.core.api.ProjectionRepository;
import com.reactor.cachedb.core.api.SourceRepository;
import com.reactor.cachedb.core.active.ActiveRecordInstance;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.PageWindow;
import com.reactor.cachedb.core.plan.FetchPlan;
import com.reactor.cachedb.core.model.EntityCodec;
import com.reactor.cachedb.core.model.EntityMetadata;
import com.reactor.cachedb.core.model.WriteDependency;
import com.reactor.cachedb.core.model.WriteReceipt;
import com.reactor.cachedb.core.page.EntityPageLoader;
import com.reactor.cachedb.core.page.VersionedEntity;
import com.reactor.cachedb.core.model.RelationDefinition;
import com.reactor.cachedb.core.model.RelationKind;
import com.reactor.cachedb.core.projection.EntityProjection;
import com.reactor.cachedb.core.query.QuerySpec;
import com.reactor.cachedb.core.query.PartitionedQuerySpec;
import com.reactor.cachedb.core.query.QuerySort;
import com.reactor.cachedb.core.route.RouteCacheContract;
import com.reactor.cachedb.core.route.RouteCacheContext;
import com.reactor.cachedb.core.route.RouteCacheStrictMode;
import com.reactor.cachedb.core.relation.RelationBatchLoader;
import com.reactor.cachedb.core.relation.CompositeRelationBatchLoader;
import com.reactor.cachedb.core.relation.PartitionedRelationBatchLoader;
import com.reactor.cachedb.starter.CacheDatabase;
import com.reactor.cachedb.starter.CacheWarmPlan;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public final class DemoOrderEntityCacheBinding {
    public static final EntityMetadata<DemoOrderEntity, java.lang.Long> METADATA = new Metadata();
    public static final EntityCodec<DemoOrderEntity> CODEC = new Codec();

    private DemoOrderEntityCacheBinding() {
    }

    public static DemoOrderEntity withId(DemoOrderEntity entity, java.lang.Long id) {
        java.util.Objects.requireNonNull(entity, "entity");
        java.util.Objects.requireNonNull(id, "id");
        entity.id = id;
        return entity;
    }

    private static final class Metadata implements EntityMetadata<DemoOrderEntity, java.lang.Long> {
        @Override
        public String entityName() {
            return "DemoOrderEntity";
        }

        @Override
        public String tableName() {
            return "cachedb_demo_orders";
        }

        @Override
        public String redisNamespace() {
            return "demo-orders";
        }

        @Override
        public String idColumn() {
            return "id";
        }

        @Override
        public String versionColumn() {
            return "entity_version";
        }

        @Override
        public String deletedColumn() {
            return null;
        }

        @Override
        public String activeMarkerValue() {
            return "false";
        }

        @Override
        public String deletedMarkerValue() {
            return "true";
        }

        @Override
        public Class<DemoOrderEntity> entityType() {
            return DemoOrderEntity.class;
        }

        @Override
        public Function<DemoOrderEntity, java.lang.Long> idAccessor() {
            return entity -> entity.id;
        }

        @Override
        public List<String> columns() {
            return List.of("id", "customer_id", "product_id", "total_amount", "line_item_count", "status");
        }

        @Override
        public Map<String, String> columnTypes() {
            LinkedHashMap<String, String> columnTypes = new LinkedHashMap<>();
            columnTypes.put("id", "java.lang.Long");
            columnTypes.put("customer_id", "java.lang.Long");
            columnTypes.put("product_id", "java.lang.Long");
            columnTypes.put("total_amount", "java.lang.Double");
            columnTypes.put("line_item_count", "java.lang.Integer");
            columnTypes.put("status", "java.lang.String");
            return columnTypes;
        }

        @Override
        public Map<String, List<String>> partitionedSortIndexes() {
            return Map.of();
        }

        @Override
        public List<RelationDefinition> relations() {
            return List.of(
                    new RelationDefinition("orderLines", "DemoOrderLineEntity", "orderId", RelationKind.ONE_TO_MANY, true)
            );
        }
    }

    private static final class Codec implements EntityCodec<DemoOrderEntity> {
        @Override
        public String toRedisValue(DemoOrderEntity entity) {
            LinkedHashMap<String, String> values = new LinkedHashMap<>();
            values.put("id", entity.id == null ? null : String.valueOf(entity.id));
            values.put("customer_id", entity.customerId == null ? null : String.valueOf(entity.customerId));
            values.put("product_id", entity.productId == null ? null : String.valueOf(entity.productId));
            values.put("total_amount", entity.totalAmount == null ? null : String.valueOf(entity.totalAmount));
            values.put("line_item_count", entity.lineItemCount == null ? null : String.valueOf(entity.lineItemCount));
            values.put("status", entity.status);
            return LengthPrefixedPayloadCodec.encode(values);
        }

        @Override
        public DemoOrderEntity fromRedisValue(String encoded) {
            Map<String, String> values = LengthPrefixedPayloadCodec.decode(encoded);
            DemoOrderEntity entity = new DemoOrderEntity();
            entity.id = values.get("id") == null ? null : Long.valueOf(values.get("id"));
            entity.customerId = values.get("customer_id") == null ? null : Long.valueOf(values.get("customer_id"));
            entity.productId = values.get("product_id") == null ? null : Long.valueOf(values.get("product_id"));
            entity.totalAmount = values.get("total_amount") == null ? null : Double.valueOf(values.get("total_amount"));
            entity.lineItemCount = values.get("line_item_count") == null ? null : Integer.valueOf(values.get("line_item_count"));
            entity.status = values.get("status");
            return entity;
        }

        @Override
        public DemoOrderEntity fromColumns(Map<String, Object> columns) {
            DemoOrderEntity entity = new DemoOrderEntity();
            entity.id = columnValue(columns, "id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "id"))));
            entity.customerId = columnValue(columns, "customer_id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "customer_id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "customer_id"))));
            entity.productId = columnValue(columns, "product_id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "product_id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "product_id"))));
            entity.totalAmount = columnValue(columns, "total_amount") instanceof Number number ? Double.valueOf(number.doubleValue()) : (columnValue(columns, "total_amount") == null ? null : Double.valueOf(String.valueOf(columnValue(columns, "total_amount"))));
            entity.lineItemCount = columnValue(columns, "line_item_count") instanceof Number number ? Integer.valueOf(number.intValue()) : (columnValue(columns, "line_item_count") == null ? null : Integer.valueOf(String.valueOf(columnValue(columns, "line_item_count"))));
            entity.status = columnValue(columns, "status") == null ? null : String.valueOf(columnValue(columns, "status"));
            return entity;
        }

        @Override
        public Map<String, Object> toColumns(DemoOrderEntity entity) {
            LinkedHashMap<String, Object> columns = new LinkedHashMap<>();
            columns.put("id", entity.id);
            columns.put("customer_id", entity.customerId);
            columns.put("product_id", entity.productId);
            columns.put("total_amount", entity.totalAmount);
            columns.put("line_item_count", entity.lineItemCount);
            columns.put("status", entity.status);
            return columns;
        }
    }

    public static RelationBatchLoader<DemoOrderEntity> relationLoader(CacheDatabase cacheDatabase) {
        return relationLoader(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static RelationBatchLoader<DemoOrderEntity> relationLoader(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        return new CompositeRelationBatchLoader<>(List.of(
                new com.reactor.cachedb.examples.demo.DemoOrderLinesRelationBatchLoader(com.reactor.cachedb.examples.demo.entity.DemoOrderLineEntityCacheBinding.repository(cacheDatabase)),
                new PartitionedRelationBatchLoader<>("orderLines", 100, 32, com.reactor.cachedb.examples.demo.entity.DemoOrderLineEntityCacheBinding.repository(cacheDatabase), parent -> parent.id, (parent, children) -> parent.orderLines = children, "order_id", QuerySort.asc("id"))
        ));
    }

    public static com.reactor.cachedb.core.projection.EntityProjection<com.reactor.cachedb.examples.demo.entity.DemoOrderEntity,com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderSummaryReadModel,java.lang.Long> orderSummaryProjection() {
        return DemoOrderEntity.orderSummaryProjection();
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderSummaryReadModel, java.lang.Long> orderSummary(CacheSession session) {
        return repository(session).projected(orderSummaryProjection());
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderSummaryReadModel, java.lang.Long> orderSummary(CacheSession session, CachePolicy cachePolicy) {
        return repository(session, cachePolicy).projected(orderSummaryProjection());
    }

    public static ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderSummaryReadModel, java.lang.Long> orderSummary(EntityRepository<DemoOrderEntity, java.lang.Long> repository) {
        return repository.projected(orderSummaryProjection());
    }

    public static QuerySpec topCustomerOrdersQuery(long customerId, int limit) {
        return DemoOrderEntity.topCustomerOrdersQuery(customerId, limit);
    }

    public static List<DemoOrderEntity> topCustomerOrders(CacheSession cacheSession, long customerId, int limit) {
        return repository(cacheSession).query(topCustomerOrdersQuery(customerId, limit));
    }

    public static List<DemoOrderEntity> topCustomerOrders(CacheSession cacheSession, CachePolicy cachePolicy, long customerId, int limit) {
        return repository(cacheSession, cachePolicy).query(topCustomerOrdersQuery(customerId, limit));
    }

    public static List<DemoOrderEntity> topCustomerOrders(EntityRepository<DemoOrderEntity, java.lang.Long> entityRepository, long customerId, int limit) {
        return entityRepository.query(topCustomerOrdersQuery(customerId, limit));
    }

    public static <P> List<P> topCustomerOrders(ProjectionRepository<P, java.lang.Long> projectionRepository, long customerId, int limit) {
        return projectionRepository.query(topCustomerOrdersQuery(customerId, limit));
    }

    public static QuerySpec highLineOrdersQuery(int minimumLineCount, int limit) {
        return DemoOrderEntity.highLineOrdersQuery(minimumLineCount, limit);
    }

    public static List<DemoOrderEntity> highLineOrders(CacheSession cacheSession, int minimumLineCount, int limit) {
        return repository(cacheSession).query(highLineOrdersQuery(minimumLineCount, limit));
    }

    public static List<DemoOrderEntity> highLineOrders(CacheSession cacheSession, CachePolicy cachePolicy, int minimumLineCount, int limit) {
        return repository(cacheSession, cachePolicy).query(highLineOrdersQuery(minimumLineCount, limit));
    }

    public static List<DemoOrderEntity> highLineOrders(EntityRepository<DemoOrderEntity, java.lang.Long> entityRepository, int minimumLineCount, int limit) {
        return entityRepository.query(highLineOrdersQuery(minimumLineCount, limit));
    }

    public static <P> List<P> highLineOrders(ProjectionRepository<P, java.lang.Long> projectionRepository, int minimumLineCount, int limit) {
        return projectionRepository.query(highLineOrdersQuery(minimumLineCount, limit));
    }

    public static FetchPlan orderLinesPreviewFetchPlan(int lineLimit) {
        return DemoOrderEntity.orderLinesPreviewFetchPlan(lineLimit);
    }

    public static EntityRepository<DemoOrderEntity, java.lang.Long> orderLinesPreviewRepository(CacheSession cacheSession, int lineLimit) {
        return repository(cacheSession).withFetchPlan(orderLinesPreviewFetchPlan(lineLimit));
    }

    public static EntityRepository<DemoOrderEntity, java.lang.Long> orderLinesPreviewRepository(CacheSession cacheSession, CachePolicy cachePolicy, int lineLimit) {
        return repository(cacheSession, cachePolicy).withFetchPlan(orderLinesPreviewFetchPlan(lineLimit));
    }

    public static EntityRepository<DemoOrderEntity, java.lang.Long> orderLinesPreviewRepository(EntityRepository<DemoOrderEntity, java.lang.Long> entityRepository, int lineLimit) {
        return entityRepository.withFetchPlan(orderLinesPreviewFetchPlan(lineLimit));
    }

    public static EntityRepository<DemoOrderEntity, java.lang.Long> repository(CacheSession session) {
        return session.repository(METADATA, CODEC);
    }

    public static EntityRepository<DemoOrderEntity, java.lang.Long> repository(CacheSession session, CachePolicy cachePolicy) {
        return session.repository(METADATA, CODEC, cachePolicy);
    }

    public static void register(CacheDatabase cacheDatabase) {
        register(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationLoader(cacheDatabase, cachePolicy), null);
        cacheDatabase.registerProjection(METADATA, orderSummaryProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase) {
        registerJdbcBacked(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationLoader(cacheDatabase, cachePolicy), null);
        cacheDatabase.registerProjection(METADATA, orderSummaryProjection());
    }

    public static void registerJdbcSource(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
        cacheDatabase.registerProjection(METADATA, orderSummaryProjection());
    }

    public static void registerDeclaredLoaders(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationLoader(cacheDatabase, cachePolicy), null);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<DemoOrderEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, orderSummaryProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoOrderEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, orderSummaryProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<DemoOrderEntity> relationBatchLoader, EntityPageLoader<DemoOrderEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, orderSummaryProjection());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoOrderEntity> relationBatchLoader, EntityPageLoader<DemoOrderEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, orderSummaryProjection());
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<DemoOrderEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, orderSummaryProjection());
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoOrderEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
        cacheDatabase.registerProjection(METADATA, orderSummaryProjection());
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<DemoOrderEntity> relationBatchLoader, EntityPageLoader<DemoOrderEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, orderSummaryProjection());
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoOrderEntity> relationBatchLoader, EntityPageLoader<DemoOrderEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
        cacheDatabase.registerProjection(METADATA, orderSummaryProjection());
    }

    public static CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
        return CacheWarmPlan.builder(METADATA.entityName())
                .name(name)
                .querySpec(querySpec)
                .maxRows(maxRows)
                .build();
    }

    public static ActiveRecordInstance<DemoOrderEntity, java.lang.Long> attach(CacheSession session, DemoOrderEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session));
    }

    public static ActiveRecordInstance<DemoOrderEntity, java.lang.Long> attach(CacheSession session, CachePolicy cachePolicy, DemoOrderEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session, cachePolicy));
    }

    public static DemoOrderEntity save(CacheSession session, DemoOrderEntity entity) {
        return repository(session).save(entity);
    }

    public static DemoOrderEntity save(CacheSession session, CachePolicy cachePolicy, DemoOrderEntity entity) {
        return repository(session, cachePolicy).save(entity);
    }

    public static Optional<DemoOrderEntity> findById(CacheSession session, java.lang.Long id) {
        return repository(session).findById(id);
    }

    public static Optional<DemoOrderEntity> findById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        return repository(session, cachePolicy).findById(id);
    }

    public static List<DemoOrderEntity> findPage(CacheSession session, PageWindow pageWindow) {
        return repository(session).findPage(pageWindow);
    }

    public static List<DemoOrderEntity> findPage(CacheSession session, CachePolicy cachePolicy, PageWindow pageWindow) {
        return repository(session, cachePolicy).findPage(pageWindow);
    }

    public static List<DemoOrderEntity> query(CacheSession session, QuerySpec querySpec) {
        return repository(session).query(querySpec);
    }

    public static List<DemoOrderEntity> query(CacheSession session, CachePolicy cachePolicy, QuerySpec querySpec) {
        return repository(session, cachePolicy).query(querySpec);
    }

    public static void deleteById(CacheSession session, java.lang.Long id) {
        repository(session).deleteById(id);
    }

    public static void deleteById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        repository(session, cachePolicy).deleteById(id);
    }

    public static Scope using(CacheSession session) {
        return new Scope(session, null);
    }

    public static Scope using(CacheSession session, CachePolicy cachePolicy) {
        return new Scope(session, cachePolicy);
    }

    public static final class Scope {
        private final CacheSession cacheSession;
        private final EntityRepository<DemoOrderEntity, java.lang.Long> repository;
        private volatile SourceRepository<DemoOrderEntity, java.lang.Long> sourceRepository;
        private final Queries queries;
        private final Projections projections;
        private final Fetches fetches;

        private Scope(CacheSession cacheSession, CachePolicy cachePolicy) {
            this.cacheSession = cacheSession;
            this.repository = cachePolicy == null ? DemoOrderEntityCacheBinding.repository(cacheSession) : DemoOrderEntityCacheBinding.repository(cacheSession, cachePolicy);
            this.queries = new Queries(this);
            this.projections = new Projections(this);
            this.fetches = new Fetches(this);
        }

        public EntityRepository<DemoOrderEntity, java.lang.Long> repository() {
            return repository;
        }

        public ActiveRecordInstance<DemoOrderEntity, java.lang.Long> attach(DemoOrderEntity entity) {
            return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository);
        }

        public DemoOrderEntity save(DemoOrderEntity entity) {
            return repository.save(entity);
        }

        public WriteReceipt<DemoOrderEntity, java.lang.Long> saveWithReceipt(DemoOrderEntity entity) {
            return repository.saveWithReceipt(entity);
        }

        public WriteReceipt<DemoOrderEntity, java.lang.Long> save(DemoOrderEntity entity, long expectedVersion) {
            return repository.save(entity, expectedVersion);
        }

        public WriteReceipt<DemoOrderEntity, java.lang.Long> saveAfter(DemoOrderEntity entity, WriteDependency dependency) {
            return repository.saveAfter(entity, dependency);
        }

        public List<WriteReceipt<DemoOrderEntity, java.lang.Long>> saveAll(java.util.Collection<DemoOrderEntity> entities) {
            return repository.saveAll(entities);
        }

        public Optional<DemoOrderEntity> findById(java.lang.Long id) {
            return repository.findById(id);
        }

        public Optional<VersionedEntity<DemoOrderEntity>> findVersionedById(java.lang.Long id) {
            return repository.findVersionedById(id);
        }

        public Optional<WriteDependency> dependency(java.lang.Long id) {
            return repository.findVersionedById(id).map(versioned -> new WriteDependency(METADATA.redisNamespace(), String.valueOf(id), versioned.version()));
        }

        public List<DemoOrderEntity> findPage(PageWindow pageWindow) {
            return repository.findPage(pageWindow);
        }

        public List<DemoOrderEntity> query(QuerySpec querySpec) {
            return repository.query(querySpec);
        }

        public <K> Map<K, List<DemoOrderEntity>> queryPartitions(PartitionedQuerySpec<K> querySpec) {
            return repository.queryPartitions(querySpec);
        }

        public SourceRepository<DemoOrderEntity, java.lang.Long> source() {
            SourceRepository<DemoOrderEntity, java.lang.Long> resolved = sourceRepository;
            if (resolved == null) {
                synchronized (this) {
                    resolved = sourceRepository;
                    if (resolved == null) {
                        resolved = cacheSession.sourceRepository(METADATA, CODEC);
                        sourceRepository = resolved;
                    }
                }
            }
            return resolved;
        }

        public void deleteById(java.lang.Long id) {
            repository.deleteById(id);
        }

        public CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
            return DemoOrderEntityCacheBinding.warmPlan(name, querySpec, maxRows);
        }

        public Queries queries() {
            return queries;
        }

        public Projections projections() {
            return projections;
        }

        public Fetches fetches() {
            return fetches;
        }
    }

    public static final class Queries {
        private final Scope scope;

        private Queries(Scope scope) {
            this.scope = scope;
        }

        public QuerySpec topCustomerOrdersQuery(long customerId, int limit) {
            return DemoOrderEntityCacheBinding.topCustomerOrdersQuery(customerId, limit);
        }

        public List<DemoOrderEntity> topCustomerOrders(long customerId, int limit) {
            return scope.repository().query(topCustomerOrdersQuery(customerId, limit));
        }

        public QuerySpec highLineOrdersQuery(int minimumLineCount, int limit) {
            return DemoOrderEntityCacheBinding.highLineOrdersQuery(minimumLineCount, limit);
        }

        public List<DemoOrderEntity> highLineOrders(int minimumLineCount, int limit) {
            return scope.repository().query(highLineOrdersQuery(minimumLineCount, limit));
        }
    }

    public static final class Projections {
        private final Scope scope;
        private volatile ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderSummaryReadModel, java.lang.Long> orderSummary;

        private Projections(Scope scope) {
            this.scope = scope;
        }

        public com.reactor.cachedb.core.projection.EntityProjection<com.reactor.cachedb.examples.demo.entity.DemoOrderEntity,com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderSummaryReadModel,java.lang.Long> orderSummaryProjection() {
            return DemoOrderEntityCacheBinding.orderSummaryProjection();
        }

        public ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderSummaryReadModel, java.lang.Long> orderSummary() {
            ProjectionRepository<com.reactor.cachedb.examples.demo.DemoOrderReadModelPatterns.OrderSummaryReadModel, java.lang.Long> resolved = orderSummary;
            if (resolved == null) {
                synchronized (this) {
                    resolved = orderSummary;
                    if (resolved == null) {
                        resolved = scope.repository().projected(orderSummaryProjection());
                        orderSummary = resolved;
                    }
                }
            }
            return resolved;
        }
    }

    public static final class Fetches {
        private final Scope scope;

        private Fetches(Scope scope) {
            this.scope = scope;
        }

        public FetchPlan orderLinesPreviewFetchPlan(int lineLimit) {
            return DemoOrderEntityCacheBinding.orderLinesPreviewFetchPlan(lineLimit);
        }

        public EntityRepository<DemoOrderEntity, java.lang.Long> orderLinesPreview(int lineLimit) {
            return scope.repository().withFetchPlan(orderLinesPreviewFetchPlan(lineLimit));
        }
    }
}
