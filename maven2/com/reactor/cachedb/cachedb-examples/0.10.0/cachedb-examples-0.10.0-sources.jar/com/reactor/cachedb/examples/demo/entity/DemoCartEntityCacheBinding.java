package com.reactor.cachedb.examples.demo.entity;

import com.reactor.cachedb.core.codec.LengthPrefixedPayloadCodec;
import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.api.EntityRepository;
import com.reactor.cachedb.core.api.ProjectionRepository;
import com.reactor.cachedb.core.api.SourceRepository;
import com.reactor.cachedb.core.active.ActiveRecordInstance;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.PageWindow;
import com.reactor.cachedb.core.plan.FetchPlan;
import com.reactor.cachedb.core.model.EntityCodec;
import com.reactor.cachedb.core.model.EntityMetadata;
import com.reactor.cachedb.core.model.WriteDependency;
import com.reactor.cachedb.core.model.WriteReceipt;
import com.reactor.cachedb.core.page.EntityPageLoader;
import com.reactor.cachedb.core.page.VersionedEntity;
import com.reactor.cachedb.core.model.RelationDefinition;
import com.reactor.cachedb.core.model.RelationKind;
import com.reactor.cachedb.core.projection.EntityProjection;
import com.reactor.cachedb.core.query.QuerySpec;
import com.reactor.cachedb.core.query.PartitionedQuerySpec;
import com.reactor.cachedb.core.query.QuerySort;
import com.reactor.cachedb.core.route.RouteCacheContract;
import com.reactor.cachedb.core.route.RouteCacheContext;
import com.reactor.cachedb.core.route.RouteCacheStrictMode;
import com.reactor.cachedb.core.relation.RelationBatchLoader;
import com.reactor.cachedb.core.relation.CompositeRelationBatchLoader;
import com.reactor.cachedb.core.relation.PartitionedRelationBatchLoader;
import com.reactor.cachedb.starter.CacheDatabase;
import com.reactor.cachedb.starter.CacheWarmPlan;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public final class DemoCartEntityCacheBinding {
    public static final EntityMetadata<DemoCartEntity, java.lang.Long> METADATA = new Metadata();
    public static final EntityCodec<DemoCartEntity> CODEC = new Codec();

    private DemoCartEntityCacheBinding() {
    }

    public static DemoCartEntity withId(DemoCartEntity entity, java.lang.Long id) {
        java.util.Objects.requireNonNull(entity, "entity");
        java.util.Objects.requireNonNull(id, "id");
        entity.id = id;
        return entity;
    }

    private static final class Metadata implements EntityMetadata<DemoCartEntity, java.lang.Long> {
        @Override
        public String entityName() {
            return "DemoCartEntity";
        }

        @Override
        public String tableName() {
            return "cachedb_demo_carts";
        }

        @Override
        public String redisNamespace() {
            return "demo-carts";
        }

        @Override
        public String idColumn() {
            return "id";
        }

        @Override
        public String versionColumn() {
            return "entity_version";
        }

        @Override
        public String deletedColumn() {
            return null;
        }

        @Override
        public String activeMarkerValue() {
            return "false";
        }

        @Override
        public String deletedMarkerValue() {
            return "true";
        }

        @Override
        public Class<DemoCartEntity> entityType() {
            return DemoCartEntity.class;
        }

        @Override
        public Function<DemoCartEntity, java.lang.Long> idAccessor() {
            return entity -> entity.id;
        }

        @Override
        public List<String> columns() {
            return List.of("id", "customer_id", "product_id", "quantity", "status");
        }

        @Override
        public Map<String, String> columnTypes() {
            LinkedHashMap<String, String> columnTypes = new LinkedHashMap<>();
            columnTypes.put("id", "java.lang.Long");
            columnTypes.put("customer_id", "java.lang.Long");
            columnTypes.put("product_id", "java.lang.Long");
            columnTypes.put("quantity", "java.lang.Integer");
            columnTypes.put("status", "java.lang.String");
            return columnTypes;
        }

        @Override
        public Map<String, List<String>> partitionedSortIndexes() {
            return Map.of();
        }

        @Override
        public List<RelationDefinition> relations() {
            return List.of();
        }
    }

    private static final class Codec implements EntityCodec<DemoCartEntity> {
        @Override
        public String toRedisValue(DemoCartEntity entity) {
            LinkedHashMap<String, String> values = new LinkedHashMap<>();
            values.put("id", entity.id == null ? null : String.valueOf(entity.id));
            values.put("customer_id", entity.customerId == null ? null : String.valueOf(entity.customerId));
            values.put("product_id", entity.productId == null ? null : String.valueOf(entity.productId));
            values.put("quantity", entity.quantity == null ? null : String.valueOf(entity.quantity));
            values.put("status", entity.status);
            return LengthPrefixedPayloadCodec.encode(values);
        }

        @Override
        public DemoCartEntity fromRedisValue(String encoded) {
            Map<String, String> values = LengthPrefixedPayloadCodec.decode(encoded);
            DemoCartEntity entity = new DemoCartEntity();
            entity.id = values.get("id") == null ? null : Long.valueOf(values.get("id"));
            entity.customerId = values.get("customer_id") == null ? null : Long.valueOf(values.get("customer_id"));
            entity.productId = values.get("product_id") == null ? null : Long.valueOf(values.get("product_id"));
            entity.quantity = values.get("quantity") == null ? null : Integer.valueOf(values.get("quantity"));
            entity.status = values.get("status");
            return entity;
        }

        @Override
        public DemoCartEntity fromColumns(Map<String, Object> columns) {
            DemoCartEntity entity = new DemoCartEntity();
            entity.id = columnValue(columns, "id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "id"))));
            entity.customerId = columnValue(columns, "customer_id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "customer_id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "customer_id"))));
            entity.productId = columnValue(columns, "product_id") instanceof Number number ? Long.valueOf(number.longValue()) : (columnValue(columns, "product_id") == null ? null : Long.valueOf(String.valueOf(columnValue(columns, "product_id"))));
            entity.quantity = columnValue(columns, "quantity") instanceof Number number ? Integer.valueOf(number.intValue()) : (columnValue(columns, "quantity") == null ? null : Integer.valueOf(String.valueOf(columnValue(columns, "quantity"))));
            entity.status = columnValue(columns, "status") == null ? null : String.valueOf(columnValue(columns, "status"));
            return entity;
        }

        @Override
        public Map<String, Object> toColumns(DemoCartEntity entity) {
            LinkedHashMap<String, Object> columns = new LinkedHashMap<>();
            columns.put("id", entity.id);
            columns.put("customer_id", entity.customerId);
            columns.put("product_id", entity.productId);
            columns.put("quantity", entity.quantity);
            columns.put("status", entity.status);
            return columns;
        }
    }

    public static EntityRepository<DemoCartEntity, java.lang.Long> repository(CacheSession session) {
        return session.repository(METADATA, CODEC);
    }

    public static EntityRepository<DemoCartEntity, java.lang.Long> repository(CacheSession session, CachePolicy cachePolicy) {
        return session.repository(METADATA, CODEC, cachePolicy);
    }

    public static void register(CacheDatabase cacheDatabase) {
        cacheDatabase.register(METADATA, CODEC);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase) {
        registerJdbcBacked(cacheDatabase, cacheDatabase.config().resourceLimits().defaultCachePolicy());
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
    }

    public static void registerJdbcSource(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, null, null);
    }

    public static void registerDeclaredLoaders(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<DemoCartEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoCartEntity> relationBatchLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, RelationBatchLoader<DemoCartEntity> relationBatchLoader, EntityPageLoader<DemoCartEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
    }

    public static void registerJdbcBacked(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoCartEntity> relationBatchLoader, EntityPageLoader<DemoCartEntity> pageLoader) {
        cacheDatabase.registerJdbcBacked(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<DemoCartEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, null);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoCartEntity> relationBatchLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, null);
    }

    public static void register(CacheDatabase cacheDatabase, RelationBatchLoader<DemoCartEntity> relationBatchLoader, EntityPageLoader<DemoCartEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cacheDatabase.config().resourceLimits().defaultCachePolicy(), relationBatchLoader, pageLoader);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy, RelationBatchLoader<DemoCartEntity> relationBatchLoader, EntityPageLoader<DemoCartEntity> pageLoader) {
        cacheDatabase.register(METADATA, CODEC, cachePolicy, relationBatchLoader, pageLoader);
    }

    public static CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
        return CacheWarmPlan.builder(METADATA.entityName())
                .name(name)
                .querySpec(querySpec)
                .maxRows(maxRows)
                .build();
    }

    public static ActiveRecordInstance<DemoCartEntity, java.lang.Long> attach(CacheSession session, DemoCartEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session));
    }

    public static ActiveRecordInstance<DemoCartEntity, java.lang.Long> attach(CacheSession session, CachePolicy cachePolicy, DemoCartEntity entity) {
        return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository(session, cachePolicy));
    }

    public static DemoCartEntity save(CacheSession session, DemoCartEntity entity) {
        return repository(session).save(entity);
    }

    public static DemoCartEntity save(CacheSession session, CachePolicy cachePolicy, DemoCartEntity entity) {
        return repository(session, cachePolicy).save(entity);
    }

    public static Optional<DemoCartEntity> findById(CacheSession session, java.lang.Long id) {
        return repository(session).findById(id);
    }

    public static Optional<DemoCartEntity> findById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        return repository(session, cachePolicy).findById(id);
    }

    public static List<DemoCartEntity> findPage(CacheSession session, PageWindow pageWindow) {
        return repository(session).findPage(pageWindow);
    }

    public static List<DemoCartEntity> findPage(CacheSession session, CachePolicy cachePolicy, PageWindow pageWindow) {
        return repository(session, cachePolicy).findPage(pageWindow);
    }

    public static List<DemoCartEntity> query(CacheSession session, QuerySpec querySpec) {
        return repository(session).query(querySpec);
    }

    public static List<DemoCartEntity> query(CacheSession session, CachePolicy cachePolicy, QuerySpec querySpec) {
        return repository(session, cachePolicy).query(querySpec);
    }

    public static void deleteById(CacheSession session, java.lang.Long id) {
        repository(session).deleteById(id);
    }

    public static void deleteById(CacheSession session, CachePolicy cachePolicy, java.lang.Long id) {
        repository(session, cachePolicy).deleteById(id);
    }

    public static Scope using(CacheSession session) {
        return new Scope(session, null);
    }

    public static Scope using(CacheSession session, CachePolicy cachePolicy) {
        return new Scope(session, cachePolicy);
    }

    public static final class Scope {
        private final CacheSession cacheSession;
        private final EntityRepository<DemoCartEntity, java.lang.Long> repository;
        private volatile SourceRepository<DemoCartEntity, java.lang.Long> sourceRepository;

        private Scope(CacheSession cacheSession, CachePolicy cachePolicy) {
            this.cacheSession = cacheSession;
            this.repository = cachePolicy == null ? DemoCartEntityCacheBinding.repository(cacheSession) : DemoCartEntityCacheBinding.repository(cacheSession, cachePolicy);
        }

        public EntityRepository<DemoCartEntity, java.lang.Long> repository() {
            return repository;
        }

        public ActiveRecordInstance<DemoCartEntity, java.lang.Long> attach(DemoCartEntity entity) {
            return new ActiveRecordInstance<>(entity, METADATA.idAccessor().apply(entity), repository);
        }

        public DemoCartEntity save(DemoCartEntity entity) {
            return repository.save(entity);
        }

        public WriteReceipt<DemoCartEntity, java.lang.Long> saveWithReceipt(DemoCartEntity entity) {
            return repository.saveWithReceipt(entity);
        }

        public WriteReceipt<DemoCartEntity, java.lang.Long> save(DemoCartEntity entity, long expectedVersion) {
            return repository.save(entity, expectedVersion);
        }

        public WriteReceipt<DemoCartEntity, java.lang.Long> saveAfter(DemoCartEntity entity, WriteDependency dependency) {
            return repository.saveAfter(entity, dependency);
        }

        public List<WriteReceipt<DemoCartEntity, java.lang.Long>> saveAll(java.util.Collection<DemoCartEntity> entities) {
            return repository.saveAll(entities);
        }

        public Optional<DemoCartEntity> findById(java.lang.Long id) {
            return repository.findById(id);
        }

        public Optional<VersionedEntity<DemoCartEntity>> findVersionedById(java.lang.Long id) {
            return repository.findVersionedById(id);
        }

        public Optional<WriteDependency> dependency(java.lang.Long id) {
            return repository.findVersionedById(id).map(versioned -> new WriteDependency(METADATA.redisNamespace(), String.valueOf(id), versioned.version()));
        }

        public List<DemoCartEntity> findPage(PageWindow pageWindow) {
            return repository.findPage(pageWindow);
        }

        public List<DemoCartEntity> query(QuerySpec querySpec) {
            return repository.query(querySpec);
        }

        public <K> Map<K, List<DemoCartEntity>> queryPartitions(PartitionedQuerySpec<K> querySpec) {
            return repository.queryPartitions(querySpec);
        }

        public SourceRepository<DemoCartEntity, java.lang.Long> source() {
            SourceRepository<DemoCartEntity, java.lang.Long> resolved = sourceRepository;
            if (resolved == null) {
                synchronized (this) {
                    resolved = sourceRepository;
                    if (resolved == null) {
                        resolved = cacheSession.sourceRepository(METADATA, CODEC);
                        sourceRepository = resolved;
                    }
                }
            }
            return resolved;
        }

        public void deleteById(java.lang.Long id) {
            repository.deleteById(id);
        }

        public CacheWarmPlan warmPlan(String name, QuerySpec querySpec, int maxRows) {
            return DemoCartEntityCacheBinding.warmPlan(name, querySpec, maxRows);
        }
    }
}
