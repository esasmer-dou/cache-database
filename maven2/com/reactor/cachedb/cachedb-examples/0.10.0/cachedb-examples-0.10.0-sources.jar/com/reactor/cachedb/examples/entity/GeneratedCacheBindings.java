package com.reactor.cachedb.examples.entity;

import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.cache.CachePolicyCatalog;
import com.reactor.cachedb.starter.CacheDatabase;

public final class GeneratedCacheBindings {
    private GeneratedCacheBindings() {
    }

    public static void register(CacheDatabase cacheDatabase) {
        AuditEventEntityCacheBinding.register(cacheDatabase);
        OrderEntityCacheBinding.register(cacheDatabase);
        UserEntityCacheBinding.register(cacheDatabase);
    }

    public static void register(CacheDatabase cacheDatabase, CachePolicy cachePolicy) {
        AuditEventEntityCacheBinding.register(cacheDatabase, cachePolicy);
        OrderEntityCacheBinding.register(cacheDatabase, cachePolicy);
        UserEntityCacheBinding.register(cacheDatabase, cachePolicy);
    }

    public static void registerJdbcSources(CacheDatabase cacheDatabase, CachePolicyCatalog policyCatalog) {
        CachePolicyCatalog resolvedCatalog = policyCatalog == null ? CachePolicyCatalog.empty() : policyCatalog;
        CachePolicy fallback = cacheDatabase.config().resourceLimits().defaultCachePolicy();
        AuditEventEntityCacheBinding.registerJdbcSource(cacheDatabase, resolvedCatalog.resolve("AuditEventEntity", fallback));
        OrderEntityCacheBinding.registerJdbcSource(cacheDatabase, resolvedCatalog.resolve("OrderEntity", fallback));
        UserEntityCacheBinding.registerJdbcSource(cacheDatabase, resolvedCatalog.resolve("UserEntity", fallback));
    }

    public static void registerDeclaredLoaders(CacheDatabase cacheDatabase, CachePolicyCatalog policyCatalog) {
        CachePolicyCatalog resolvedCatalog = policyCatalog == null ? CachePolicyCatalog.empty() : policyCatalog;
        CachePolicy fallback = cacheDatabase.config().resourceLimits().defaultCachePolicy();
        AuditEventEntityCacheBinding.registerDeclaredLoaders(cacheDatabase, resolvedCatalog.resolve("AuditEventEntity", fallback));
        OrderEntityCacheBinding.registerDeclaredLoaders(cacheDatabase, resolvedCatalog.resolve("OrderEntity", fallback));
        UserEntityCacheBinding.registerDeclaredLoaders(cacheDatabase, resolvedCatalog.resolve("UserEntity", fallback));
    }
}
