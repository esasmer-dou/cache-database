package com.reactor.cachedb.examples.snapshotjson;

public final class CatalogSummaryJsonCodec extends com.reactor.cachedb.json.StreamingJsonCodec<com.reactor.cachedb.examples.snapshotjson.CatalogSummary> implements com.reactor.cachedb.json.GeneratedJsonWriter<com.reactor.cachedb.examples.snapshotjson.CatalogSummary> {
 public static final CatalogSummaryJsonCodec INSTANCE = new CatalogSummaryJsonCodec();
 public CatalogSummaryJsonCodec() { super(); }
 public CatalogSummaryJsonCodec(com.reactor.cachedb.json.JsonCodecLimits limits) { super(limits); }
 public Class<com.reactor.cachedb.examples.snapshotjson.CatalogSummary> valueType() { return com.reactor.cachedb.examples.snapshotjson.CatalogSummary.class; }
 public com.reactor.cachedb.examples.snapshotjson.CatalogSummary readValue(com.google.gson.stream.JsonReader reader, com.reactor.cachedb.json.JsonCodecLimits limits) throws java.io.IOException {
 if (com.reactor.cachedb.json.JsonStrings.isNull(reader)) return null;
 java.lang.String v0 = null;
 reader.beginObject();
 while (reader.hasNext()) {
 String key = reader.nextName();
 switch (key) {
 case "title" -> { v0 = com.reactor.cachedb.json.JsonStrings.read(reader, limits); }
 default -> throw new java.io.IOException("Unknown JSON field: " + key);
 }
 }
 reader.endObject();
 return new com.reactor.cachedb.examples.snapshotjson.CatalogSummary(v0);
 }
 public void writeValue(com.google.gson.stream.JsonWriter writer, com.reactor.cachedb.examples.snapshotjson.CatalogSummary value, com.reactor.cachedb.json.JsonCodecLimits limits) throws java.io.IOException {
 if (value == null) { writer.nullValue(); return; }
 writer.beginObject();
 var field0 = value.title();
 writer.name("title");
 com.reactor.cachedb.json.JsonStrings.write(writer, field0, limits);
 writer.endObject();
 }
 public void writeValue(com.reactor.cachedb.json.JsonTokenWriter writer, com.reactor.cachedb.examples.snapshotjson.CatalogSummary value, com.reactor.cachedb.json.JsonCodecLimits limits) throws java.io.IOException {
 if (value == null) { writer.nullValue(); return; }
 writer.beginObject();
 var field0 = value.title();
 writer.name("title");
 com.reactor.cachedb.json.JsonStrings.write(writer, field0, limits);
 writer.endObject();
 }
}
