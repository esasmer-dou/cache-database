package com.reactor.cachedb.oracle;

import com.reactor.cachedb.core.config.WriteBehindConfig;
import com.reactor.cachedb.core.model.OperationType;
import com.reactor.cachedb.core.queue.FailureClassifyingFlusher;
import com.reactor.cachedb.core.queue.QueuedWriteOperation;
import com.reactor.cachedb.core.queue.StoragePerformanceCollector;
import com.reactor.cachedb.core.queue.WriteBehindFlusherFactory;
import com.reactor.cachedb.core.queue.WriteFailureDetails;
import com.reactor.cachedb.core.registry.EntityRegistry;
import com.reactor.cachedb.jdbc.AbstractJdbcWriteBehindFlusher;
import com.reactor.cachedb.jdbc.JdbcWriteBehindSupport;
import com.reactor.cachedb.jdbc.JdbcWriteFence;
import com.reactor.cachedb.jdbc.VersionGuardedWriteSupport;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

public final class OracleWriteBehindFlusher extends AbstractJdbcWriteBehindFlusher implements FailureClassifyingFlusher {
    private static final int ORA_UNIQUE_CONSTRAINT = 1;

    private final OracleDatabaseDialect dialect = new OracleDatabaseDialect();

    @Override
    protected com.reactor.cachedb.jdbc.JdbcDatabaseDialect dialectForValidation() { return dialect; }
    private final OracleFailureClassifier failureClassifier = new OracleFailureClassifier();
    private final StoragePerformanceCollector performanceCollector;
    private final OracleWriteBehindOptions options;
    private final int transactionBatchSize;

    public OracleWriteBehindFlusher(DataSource dataSource, EntityRegistry entityRegistry) {
        this(
                dataSource,
                entityRegistry,
                WriteBehindConfig.defaults(),
                null,
                OracleWriteBehindOptions.defaults());
    }

    public OracleWriteBehindFlusher(
            DataSource dataSource, EntityRegistry entityRegistry, WriteBehindConfig config) {
        this(dataSource, entityRegistry, config, null, OracleWriteBehindOptions.defaults());
    }

    public OracleWriteBehindFlusher(
            DataSource dataSource,
            EntityRegistry entityRegistry,
            WriteBehindConfig config,
            OracleWriteBehindOptions options) {
        this(dataSource, entityRegistry, config, null, options);
    }

    public OracleWriteBehindFlusher(
            DataSource dataSource,
            EntityRegistry entityRegistry,
            WriteBehindConfig config,
            StoragePerformanceCollector performanceCollector,
            OracleWriteBehindOptions options) {
        super(dataSource, java.util.Objects.requireNonNull(entityRegistry, "entityRegistry"), JdbcWriteFence.Provider.ORACLE,
                (options == null ? OracleWriteBehindOptions.defaults() : options).queryTimeoutSeconds(), config);
        this.performanceCollector = performanceCollector;
        this.options = options == null ? OracleWriteBehindOptions.defaults() : options;
        WriteBehindConfig resolvedConfig = config == null ? WriteBehindConfig.defaults() : config;
        this.transactionBatchSize = Math.max(1, resolvedConfig.maxFlushBatchSize());
    }

    public static WriteBehindFlusherFactory factory(OracleWriteBehindOptions options) {
        OracleWriteBehindOptions resolved =
                options == null ? OracleWriteBehindOptions.defaults() : options;
        return (dataSource, entityRegistry, config, collector) ->
                new OracleWriteBehindFlusher(
                        dataSource, entityRegistry, config, collector, resolved);
    }

    @Override
    public void flush(QueuedWriteOperation operation) throws SQLException {
        try {
            if (operation.atomicBatch()) {
                flushAtomicBatch(operation.batchOperations());
                return;
            }
            long startedAt = System.nanoTime();
            try {
                executeWithDuplicateRecovery(List.of(operation), options.duplicateRaceRetries());
            } finally {
                recordWrite(startedAt, operation.observationTag());
            }
        } catch (SQLException unsafe) {
            throw safeSqlFailure(List.of(operation), unsafe);
        }
    }

    @Override
    public void flushBatch(List<QueuedWriteOperation> operations) throws SQLException {
        try {
            long startedAt = System.nanoTime();
            try {
                if (operations.isEmpty()) return;
                var prepared = prepareWrites(operations);
                initializeWriteFence(prepared);
                for (int start = 0; start < operations.size(); start += transactionBatchSize) {
                    int end = Math.min(operations.size(), start + transactionBatchSize);
                    executeWithDuplicateRecovery(
                            operations.subList(start, end), options.duplicateRaceRetries(), prepared.slice(start, end));
                }
            } finally {
                if (!operations.isEmpty()) {
                    recordWrite(startedAt, dominantObservationTag(operations));
                }
            }
        } catch (SQLException unsafe) {
            throw safeSqlFailure(operations, unsafe);
        }
    }

    private void executeWithDuplicateRecovery(
            List<QueuedWriteOperation> operations, int retriesRemaining) throws SQLException {
        if (operations.isEmpty()) {
            return;
        }
        executeWithDuplicateRecovery(operations, retriesRemaining, prepareWrites(operations));
    }

    private void executeWithDuplicateRecovery(List<QueuedWriteOperation> operations, int retriesRemaining,
            PreparedWrites prepared) throws SQLException {
        initializeWriteFence(prepared);
        try (Connection connection = dataSource.getConnection()) {
            executeInTransaction(connection, prepared);
        } catch (SQLException failure) {
            if (!isUniqueConstraintViolation(failure) || retriesRemaining <= 0) {
                throw failure;
            }
            if (operations.size() == 1) {
                QueuedWriteOperation operation = operations.get(0);
                if (operation.type() == OperationType.DELETE) {
                    throw failure;
                }
                Long currentVersion = currentVersion(operation);
                if (currentVersion != null && currentVersion >= operation.version()) {
                    return;
                }
                if (currentVersion == null) {
                    throw failure;
                }
                executeWithDuplicateRecovery(operations, retriesRemaining - 1);
                return;
            }

            // Oracle stops a JDBC batch at the first failure. The transaction is rolled back,
            // then each operation is replayed independently so a rare insert race does not
            // degrade the normal batched path.
            for (QueuedWriteOperation operation : operations) {
                executeWithDuplicateRecovery(List.of(operation), retriesRemaining - 1);
            }
        }
    }

    @Override
    public void flushAtomicBatch(List<QueuedWriteOperation> operations) throws SQLException {
        try {
            if (operations.isEmpty()) return;
            var prepared = prepareWrites(operations);
            initializeWriteFence(prepared);
            // No per-row duplicate recovery: an atomic group must be retried as one unit.
            try (Connection connection = dataSource.getConnection()) {
                executeInTransaction(connection, prepared, true);
            }
        } catch (SQLException unsafe) {
            throw safeSqlFailure(operations, unsafe);
        }
    }

    private void executeInTransaction(Connection connection, PreparedWrites operations)
            throws SQLException {
        executeInTransaction(connection, operations, false);
    }

    private void executeInTransaction(
            Connection connection, PreparedWrites operations, boolean preserveOrder)
            throws SQLException {
        inTransaction(connection, operations, options.transactionIsolation(), null, accepted -> {
            if (preserveOrder || accepted.stream().anyMatch(op -> op.type() == OperationType.PATCH)) {
                int index = 0;
                while (index < accepted.size()) {
                    var operation = accepted.get(index);
                    if (operation.type() == OperationType.PATCH) {
                        index = patchConsecutiveBatch(connection, accepted, index);
                        continue;
                    }
                    int end = index + 1;
                    var key = StatementKey.of(operation, dialect);
                    while (end < accepted.size() && sameWriteShape(operation, accepted.get(end))) end++;
                    executeGroup(connection, key, accepted.subList(index, end));
                    index = end;
                }
                return;
            }
            var groups = groupOperations(accepted, operation -> StatementKey.of(operation, dialect));
            for (var group : groups.entrySet()) {
                executeGroup(connection, group.getKey(), group.getValue());
            }
        });
    }

    private void executeGroup(
            Connection connection, StatementKey key, List<QueuedWriteOperation> operations)
            throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(key.sql())) {
            statement.setQueryTimeout(options.queryTimeoutSeconds());
            for (QueuedWriteOperation operation : operations) {
                statement.clearParameters();
                if (operation.type() == OperationType.DELETE) {
                    bindDelete(statement, operation);
                } else {
                    bindUpsert(statement, operation, entries(operation));
                }
                statement.addBatch();
            }
            int[] outcomes = statement.executeBatch();
            statement.clearBatch();
            VersionGuardedWriteSupport.verifyBatchOutcome(
                    connection,
                    entityRegistry,
                    operations,
                    outcomes,
                    options.queryTimeoutSeconds());
        }
    }

    private void bindDelete(PreparedStatement statement, QueuedWriteOperation operation)
            throws SQLException {
        OracleValueBinder.bind(
                statement,
                1,
                operation.id(),
                columnType(operation, operation.idColumn()),
                options.emptyStringPolicy());
        statement.setLong(2, operation.version());
    }

    @Override
    protected void bindPatchValue(PreparedStatement statement, int index, String value, String type) throws SQLException {
        OracleValueBinder.bind(statement, index, value, type, options.emptyStringPolicy());
    }

    private void bindUpsert(
            PreparedStatement statement,
            QueuedWriteOperation operation,
            List<Map.Entry<String, String>> entries)
            throws SQLException {
        int parameterIndex = 1;
        for (Map.Entry<String, String> entry : entries) {
            OracleValueBinder.bind(
                    statement,
                    parameterIndex++,
                    entry.getValue(),
                    columnType(operation, entry.getKey()),
                    options.emptyStringPolicy());
        }
    }

    private List<Map.Entry<String, String>> entries(QueuedWriteOperation operation) {
        return new ArrayList<>(operation.columns().entrySet());
    }

    private String columnType(QueuedWriteOperation operation, String columnName) {
        return JdbcWriteBehindSupport.columnType(entityRegistry, operation, columnName);
    }

    private Long currentVersion(QueuedWriteOperation operation) throws SQLException {
        try (Connection connection = dataSource.getConnection()) {
            return VersionGuardedWriteSupport.currentVersion(
                    connection, entityRegistry, operation, options.queryTimeoutSeconds());
        }
    }



    private boolean isUniqueConstraintViolation(SQLException exception) {
        SQLException current = exception;
        while (current != null) {
            if (Math.abs(current.getErrorCode()) == ORA_UNIQUE_CONSTRAINT) {
                return true;
            }
            current = current.getNextException();
        }
        Throwable cause = exception.getCause();
        return cause instanceof SQLException sqlCause && isUniqueConstraintViolation(sqlCause);
    }

    private void recordWrite(long startedAtNanos, String observationTag) {
        if (performanceCollector == null) {
            return;
        }
        long elapsedMicros = (System.nanoTime() - startedAtNanos) / 1_000L;
        String normalized = observationTag == null ? "" : observationTag.trim();
        performanceCollector.recordSqlWrite(
                normalized.isBlank() ? "oracle:write-behind" : providerTag(normalized),
                elapsedMicros);
    }

    private String providerTag(String tag) {
        return tag.regionMatches(true, 0, "oracle:", 0, "oracle:".length()) ? tag : "oracle:" + tag;
    }

    private String dominantObservationTag(List<QueuedWriteOperation> operations) {
        LinkedHashMap<String, Integer> counts = new LinkedHashMap<>();
        for (QueuedWriteOperation operation : operations) {
            String tag =
                    operation.observationTag() == null ? "" : operation.observationTag().trim();
            counts.merge(tag, 1, Integer::sum);
        }
        String dominant = "";
        int maximum = -1;
        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            if (entry.getValue() > maximum) {
                dominant = entry.getKey();
                maximum = entry.getValue();
            }
        }
        return dominant;
    }

    @Override
    public WriteFailureDetails classify(Exception exception) {
        return failureClassifier.classify(exception);
    }

    private record StatementKey(OperationType type, String sql) {
        private static StatementKey of(
                QueuedWriteOperation operation, OracleDatabaseDialect dialect) {
            if (operation.type() == OperationType.DELETE) {
                return new StatementKey(operation.type(), dialect.deleteSql(operation));
            }
            List<Map.Entry<String, String>> entries =
                    new ArrayList<>(operation.columns().entrySet());
            return new StatementKey(operation.type(), dialect.upsertSql(operation, entries));
        }
    }
}
