package com.reactor.cachedb.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Declares a query without exposing physical SQL column names to application code.
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.SOURCE)
public @interface CacheRouteQuery {
    CachePredicate[] predicates() default {};

    /**
     * Confirms that predicates split across multiple groups are intentionally
     * ORed. Keeping this false makes an accidental group change a compile-time
     * error instead of silently widening a production route.
     */
    boolean explicitDisjunction() default false;

    CacheOrder[] orderBy() default {};

    /**
     * int parameter used as the bounded row limit. When omitted, the processor
     * infers the single unused int parameter or falls back to fixedLimit.
     */
    String limitParameter() default "";

    int fixedLimit() default 100;

    /**
     * WindowRequest parameter used for keyset pagination. When omitted, the
     * processor infers the single WindowRequest parameter.
     */
    String windowParameter() default "";
}
