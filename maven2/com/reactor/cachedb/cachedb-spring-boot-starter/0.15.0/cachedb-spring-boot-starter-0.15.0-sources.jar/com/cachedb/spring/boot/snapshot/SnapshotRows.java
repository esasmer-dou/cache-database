package com.reactor.cachedb.spring.boot.snapshot;

import java.util.*;
import java.util.function.Function;

/** One consistent SQL snapshot. Typed source handles avoid reflective entity traversal. */
public final class SnapshotRows {
    private final Map<SnapshotSource<?>, List<?>> rows;

    SnapshotRows(Map<SnapshotSource<?>, List<?>> rows) {
        this.rows = Map.copyOf(rows);
    }

    @SuppressWarnings("unchecked")
    public <T> List<T> get(SnapshotSource<T> source) {
        List<?> result = rows.get(source);
        if (result == null)
            throw new IllegalArgumentException("Undeclared snapshot source: " + source.name());
        return (List<T>) result;
    }

    public <T, K> Map<K, T> unique(SnapshotSource<T> source, Function<T, K> key) {
        Map<K, T> result = new HashMap<>();
        for (T row : get(source)) {
            K id = Objects.requireNonNull(key.apply(row), "Null snapshot identity");
            if (result.putIfAbsent(id, row) != null)
                throw new IllegalStateException(
                        "Duplicate identity in snapshot source " + source.name());
        }
        return Collections.unmodifiableMap(result);
    }

    public <T, K, V> Map<K, List<V>> group(
            SnapshotSource<T> source,
            Function<T, K> key,
            Function<T, V> value,
            Comparator<V> order) {
        Map<K, List<V>> result = new HashMap<>();
        for (T row : get(source)) {
            K id = Objects.requireNonNull(key.apply(row), "Null snapshot relation key");
            result.computeIfAbsent(id, ignored -> new ArrayList<>())
                    .add(Objects.requireNonNull(value.apply(row), "Null snapshot relation target"));
        }
        result.replaceAll(
                (keyValue, values) -> {
                    if (order != null) values.sort(order);
                    return List.copyOf(values);
                });
        return Collections.unmodifiableMap(result);
    }

    public SnapshotLists<String, String> lists(SnapshotRelation relation) {
        return lists(relation.source(), relation::from, relation::to, Comparator.naturalOrder());
    }

    public <F, T> SnapshotLists<F, T> lists(TypedSnapshotRelation<F, T> relation) {
        return lists(relation.source(), relation::from, relation::to, null);
    }

    public <F, T> SnapshotLists<F, T> lists(
            TypedSnapshotRelation<F, T> relation, Comparator<T> order) {
        return lists(relation.source(), relation::from, relation::to, order);
    }

    public <F, T> SnapshotMembership<F, T> membership(TypedSnapshotRelation<F, T> relation) {
        return membership(relation.source(), relation::from, relation::to);
    }

    public <T, K, V> SnapshotLists<K, V> lists(
            SnapshotSource<T> source,
            Function<T, K> key,
            Function<T, V> value,
            Comparator<V> order) {
        return new SnapshotLists<>(group(source, key, value, order));
    }

    public SnapshotMembership<String, String> membership(SnapshotRelation relation) {
        return membership(relation.source(), relation::from, relation::to);
    }

    public <T, K, V> SnapshotMembership<K, V> membership(
            SnapshotSource<T> source, Function<T, K> key, Function<T, V> value) {
        Map<K, Set<V>> result = new HashMap<>();
        for (T row : get(source)) {
            K owner = Objects.requireNonNull(key.apply(row), "Null snapshot relation key");
            V target = Objects.requireNonNull(value.apply(row), "Null snapshot relation target");
            result.computeIfAbsent(owner, ignored -> new HashSet<>()).add(target);
        }
        result.replaceAll((owner, members) -> Set.copyOf(members));
        return new SnapshotMembership<>(result);
    }
}
