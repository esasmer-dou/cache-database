package com.reactor.cachedb.core.config;

import com.reactor.cachedb.core.queue.WriteBehindFlusherFactory;

public record CacheDatabaseConfig(
        WriteBehindConfig writeBehind,
        WriteBehindFlusherFactory writeBehindFlusherFactory,
        ResourceLimits resourceLimits,
        KeyspaceConfig keyspace,
        RuntimeCoordinationConfig runtimeCoordination,
        RedisFunctionsConfig redisFunctions,
        RelationConfig relations,
        PageCacheConfig pageCache,
        ReadThroughConfig readThrough,
        ReadShapeGuardrailConfig readShapeGuardrail,
        QueryIndexConfig queryIndex,
        ProjectionRefreshConfig projectionRefresh,
        RedisGuardrailConfig redisGuardrail,
        DeadLetterRecoveryConfig deadLetterRecovery,
        AdminMonitoringConfig adminMonitoring,
        AdminReportJobConfig adminReportJob,
        AdminHttpConfig adminHttp,
        SchemaBootstrapConfig schemaBootstrap
) {
    public CacheDatabaseConfig(
            WriteBehindConfig writeBehind,
            WriteBehindFlusherFactory writeBehindFlusherFactory,
            ResourceLimits resourceLimits,
            KeyspaceConfig keyspace,
            RuntimeCoordinationConfig runtimeCoordination,
            RedisFunctionsConfig redisFunctions,
            RelationConfig relations,
            PageCacheConfig pageCache,
            ReadShapeGuardrailConfig readShapeGuardrail,
            QueryIndexConfig queryIndex,
            ProjectionRefreshConfig projectionRefresh,
            RedisGuardrailConfig redisGuardrail,
            DeadLetterRecoveryConfig deadLetterRecovery,
            AdminMonitoringConfig adminMonitoring,
            AdminReportJobConfig adminReportJob,
            AdminHttpConfig adminHttp,
            SchemaBootstrapConfig schemaBootstrap
    ) {
        this(
                writeBehind, writeBehindFlusherFactory, resourceLimits, keyspace, runtimeCoordination,
                redisFunctions, relations, pageCache, ReadThroughConfig.defaults(), readShapeGuardrail,
                queryIndex, projectionRefresh, redisGuardrail, deadLetterRecovery, adminMonitoring,
                adminReportJob, adminHttp, schemaBootstrap
        );
    }

    public CacheDatabaseConfig(
            WriteBehindConfig writeBehind,
            ResourceLimits resourceLimits,
            KeyspaceConfig keyspace,
            RuntimeCoordinationConfig runtimeCoordination,
            RedisFunctionsConfig redisFunctions,
            RelationConfig relations,
            PageCacheConfig pageCache,
            ReadShapeGuardrailConfig readShapeGuardrail,
            QueryIndexConfig queryIndex,
            ProjectionRefreshConfig projectionRefresh,
            RedisGuardrailConfig redisGuardrail,
            DeadLetterRecoveryConfig deadLetterRecovery,
            AdminMonitoringConfig adminMonitoring,
            AdminReportJobConfig adminReportJob,
            AdminHttpConfig adminHttp,
            SchemaBootstrapConfig schemaBootstrap
    ) {
        this(
                writeBehind, null, resourceLimits, keyspace, runtimeCoordination, redisFunctions,
                relations, pageCache, ReadThroughConfig.defaults(), readShapeGuardrail, queryIndex,
                projectionRefresh, redisGuardrail, deadLetterRecovery, adminMonitoring, adminReportJob,
                adminHttp, schemaBootstrap
        );
    }

    public CacheDatabaseConfig(
            WriteBehindConfig writeBehind,
            ResourceLimits resourceLimits,
            KeyspaceConfig keyspace,
            RuntimeCoordinationConfig runtimeCoordination,
            RedisFunctionsConfig redisFunctions,
            RelationConfig relations,
            PageCacheConfig pageCache,
            ReadThroughConfig readThrough,
            ReadShapeGuardrailConfig readShapeGuardrail,
            QueryIndexConfig queryIndex,
            ProjectionRefreshConfig projectionRefresh,
            RedisGuardrailConfig redisGuardrail,
            DeadLetterRecoveryConfig deadLetterRecovery,
            AdminMonitoringConfig adminMonitoring,
            AdminReportJobConfig adminReportJob,
            AdminHttpConfig adminHttp,
            SchemaBootstrapConfig schemaBootstrap
    ) {
        this(
                writeBehind,
                null,
                resourceLimits,
                keyspace,
                runtimeCoordination,
                redisFunctions,
                relations,
                pageCache,
                readThrough,
                readShapeGuardrail,
                queryIndex,
                projectionRefresh,
                redisGuardrail,
                deadLetterRecovery,
                adminMonitoring,
                adminReportJob,
                adminHttp,
                schemaBootstrap
        );
    }

    public static Builder builder() {
        return new Builder();
    }

    public static CacheDatabaseConfig defaults() {
        return builder().build();
    }

    public Builder toBuilder() {
        return builder()
                .writeBehind(writeBehind)
                .writeBehindFlusherFactory(writeBehindFlusherFactory)
                .resourceLimits(resourceLimits)
                .keyspace(keyspace)
                .runtimeCoordination(runtimeCoordination)
                .redisFunctions(redisFunctions)
                .relations(relations)
                .pageCache(pageCache)
                .readThrough(readThrough)
                .readShapeGuardrail(readShapeGuardrail)
                .queryIndex(queryIndex)
                .projectionRefresh(projectionRefresh)
                .redisGuardrail(redisGuardrail)
                .deadLetterRecovery(deadLetterRecovery)
                .adminMonitoring(adminMonitoring)
                .adminReportJob(adminReportJob)
                .adminHttp(adminHttp)
                .schemaBootstrap(schemaBootstrap);
    }

    public static final class Builder {
        private WriteBehindConfig writeBehind = WriteBehindConfig.defaults();
        private WriteBehindFlusherFactory writeBehindFlusherFactory;
        private ResourceLimits resourceLimits = ResourceLimits.defaults();
        private KeyspaceConfig keyspace = KeyspaceConfig.defaults();
        private RuntimeCoordinationConfig runtimeCoordination = RuntimeCoordinationConfig.defaults();
        private RedisFunctionsConfig redisFunctions = RedisFunctionsConfig.defaults();
        private RelationConfig relations = RelationConfig.defaults();
        private PageCacheConfig pageCache = PageCacheConfig.defaults();
        private ReadThroughConfig readThrough = ReadThroughConfig.defaults();
        private ReadShapeGuardrailConfig readShapeGuardrail = ReadShapeGuardrailConfig.defaults();
        private QueryIndexConfig queryIndex = QueryIndexConfig.defaults();
        private ProjectionRefreshConfig projectionRefresh = ProjectionRefreshConfig.defaults();
        private RedisGuardrailConfig redisGuardrail = RedisGuardrailConfig.defaults();
        private DeadLetterRecoveryConfig deadLetterRecovery = DeadLetterRecoveryConfig.defaults();
        private AdminMonitoringConfig adminMonitoring = AdminMonitoringConfig.defaults();
        private AdminReportJobConfig adminReportJob = AdminReportJobConfig.defaults();
        private AdminHttpConfig adminHttp = AdminHttpConfig.defaults();
        private SchemaBootstrapConfig schemaBootstrap = SchemaBootstrapConfig.defaults();

        public Builder writeBehind(WriteBehindConfig writeBehind) {
            this.writeBehind = writeBehind;
            return this;
        }

        public Builder writeBehindFlusherFactory(WriteBehindFlusherFactory writeBehindFlusherFactory) {
            this.writeBehindFlusherFactory = writeBehindFlusherFactory;
            return this;
        }

        public Builder resourceLimits(ResourceLimits resourceLimits) {
            this.resourceLimits = resourceLimits;
            return this;
        }

        public Builder keyspace(KeyspaceConfig keyspace) {
            this.keyspace = keyspace;
            return this;
        }

        public Builder runtimeCoordination(RuntimeCoordinationConfig runtimeCoordination) {
            this.runtimeCoordination = runtimeCoordination;
            return this;
        }

        public Builder redisFunctions(RedisFunctionsConfig redisFunctions) {
            this.redisFunctions = redisFunctions;
            return this;
        }

        public Builder relations(RelationConfig relations) {
            this.relations = relations;
            return this;
        }

        public Builder pageCache(PageCacheConfig pageCache) {
            this.pageCache = pageCache;
            return this;
        }

        public Builder readThrough(ReadThroughConfig readThrough) {
            this.readThrough = readThrough;
            return this;
        }

        public Builder readShapeGuardrail(ReadShapeGuardrailConfig readShapeGuardrail) {
            this.readShapeGuardrail = readShapeGuardrail;
            return this;
        }

        public Builder queryIndex(QueryIndexConfig queryIndex) {
            this.queryIndex = queryIndex;
            return this;
        }

        public Builder projectionRefresh(ProjectionRefreshConfig projectionRefresh) {
            this.projectionRefresh = projectionRefresh;
            return this;
        }

        public Builder redisGuardrail(RedisGuardrailConfig redisGuardrail) {
            this.redisGuardrail = redisGuardrail;
            return this;
        }

        public Builder deadLetterRecovery(DeadLetterRecoveryConfig deadLetterRecovery) {
            this.deadLetterRecovery = deadLetterRecovery;
            return this;
        }

        public Builder adminMonitoring(AdminMonitoringConfig adminMonitoring) {
            this.adminMonitoring = adminMonitoring;
            return this;
        }

        public Builder adminReportJob(AdminReportJobConfig adminReportJob) {
            this.adminReportJob = adminReportJob;
            return this;
        }

        public Builder adminHttp(AdminHttpConfig adminHttp) {
            this.adminHttp = adminHttp;
            return this;
        }

        public Builder schemaBootstrap(SchemaBootstrapConfig schemaBootstrap) {
            this.schemaBootstrap = schemaBootstrap;
            return this;
        }

        public CacheDatabaseConfig build() {
            return new CacheDatabaseConfig(
                    writeBehind,
                    writeBehindFlusherFactory,
                    resourceLimits,
                    keyspace,
                    runtimeCoordination,
                    redisFunctions,
                    relations,
                    pageCache,
                    readThrough,
                    readShapeGuardrail,
                    queryIndex,
                    projectionRefresh,
                    redisGuardrail,
                    deadLetterRecovery,
                    adminMonitoring,
                    adminReportJob,
                    adminHttp,
                    schemaBootstrap
            );
        }
    }
}
