package com.reactor.cachedb.core.cache;

public record CachePolicy(
        int hotEntityLimit,
        int pageSize,
        boolean lruEvictionEnabled,
        long entityTtlSeconds,
        long pageTtlSeconds,
        EntityHotPolicy hotPolicy,
        long accessDebounceMillis,
        int recentTouchSlots,
        NearCachePolicy nearCachePolicy) {
    public static final int UNBOUNDED = -1;
    public static final int DISABLED = 0;

    @Override
    public final boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof CachePolicy value)) return false;
        return hotEntityLimit == value.hotEntityLimit
                && pageSize == value.pageSize
                && lruEvictionEnabled == value.lruEvictionEnabled
                && entityTtlSeconds == value.entityTtlSeconds
                && pageTtlSeconds == value.pageTtlSeconds
                && java.util.Objects.equals(hotPolicy, value.hotPolicy)
                && accessDebounceMillis == value.accessDebounceMillis
                && recentTouchSlots == value.recentTouchSlots
                && nearCachePolicy.equals(value.nearCachePolicy);
    }

    @Override
    public final int hashCode() {
        int hash = Integer.hashCode(hotEntityLimit);
        hash = 31 * hash + Integer.hashCode(pageSize);
        hash = 31 * hash + Boolean.hashCode(lruEvictionEnabled);
        hash = 31 * hash + Long.hashCode(entityTtlSeconds);
        hash = 31 * hash + Long.hashCode(pageTtlSeconds);
        hash = 31 * hash + java.util.Objects.hashCode(hotPolicy);
        // Preserve the historical six-component hash; extension fields still participate in equals.
        return hash;
    }

    public CachePolicy(int hotEntityLimit, int pageSize, boolean lruEvictionEnabled,
            long entityTtlSeconds, long pageTtlSeconds, EntityHotPolicy hotPolicy,
            long accessDebounceMillis, int recentTouchSlots) {
        this(hotEntityLimit, pageSize, lruEvictionEnabled, entityTtlSeconds, pageTtlSeconds,
                hotPolicy, accessDebounceMillis, recentTouchSlots, NearCachePolicy.disabled());
    }

    public CachePolicy withNearCachePolicy(NearCachePolicy policy) {
        return new CachePolicy(hotEntityLimit, pageSize, lruEvictionEnabled, entityTtlSeconds,
                pageTtlSeconds, hotPolicy, accessDebounceMillis, recentTouchSlots, policy);
    }

    public CachePolicy(int hotEntityLimit, int pageSize, boolean lruEvictionEnabled,
            long entityTtlSeconds, long pageTtlSeconds, EntityHotPolicy hotPolicy) {
        this(hotEntityLimit, pageSize, lruEvictionEnabled, entityTtlSeconds, pageTtlSeconds, hotPolicy, 500, 8192);
    }

    public CachePolicy(
            int hotEntityLimit,
            int pageSize,
            boolean lruEvictionEnabled,
            long entityTtlSeconds,
            long pageTtlSeconds) {
        this(
                hotEntityLimit,
                pageSize,
                lruEvictionEnabled,
                entityTtlSeconds,
                pageTtlSeconds,
                EntityHotPolicy.countWindow());
    }

    public CachePolicy {
        nearCachePolicy = java.util.Objects.requireNonNull(nearCachePolicy, "nearCachePolicy");
        if (hotEntityLimit < UNBOUNDED)
            throw new IllegalArgumentException("hotEntityLimit must be -1, 0, or positive");
        if (accessDebounceMillis < 0 || accessDebounceMillis > 60_000 || recentTouchSlots < 1 || recentTouchSlots > 65_536)
            throw new IllegalArgumentException("Invalid bounded access tracking configuration");
        hotPolicy = hotPolicy == null ? EntityHotPolicy.countWindow() : hotPolicy;
        if (hotEntityLimit == DISABLED) hotPolicy = EntityHotPolicy.disabled();
    }

    public boolean admissionEnabled() {
        return hotEntityLimit != DISABLED;
    }

    public boolean shouldAdmit(java.util.Map<String, Object> columns, CacheAdmissionSource source) {
        return admissionEnabled() && hotPolicy.shouldAdmit(columns, source);
    }

    public static Builder builder() {
        return new Builder();
    }

    public static CachePolicy defaults() {
        return new CachePolicy(1_000, 100, true, 0, 60, EntityHotPolicy.countWindow());
    }

    public static final class Builder {
        private int hotEntityLimit = 1_000;
        private int pageSize = 100;
        private boolean lruEvictionEnabled = true;
        private long entityTtlSeconds = 0;
        private long pageTtlSeconds = 60;
        private EntityHotPolicy hotPolicy = EntityHotPolicy.countWindow();
        private long accessDebounceMillis = 500;
        private int recentTouchSlots = 8192;
        private NearCachePolicy nearCachePolicy = NearCachePolicy.disabled();

        public Builder nearCachePolicy(NearCachePolicy policy) { nearCachePolicy = policy; return this; }

        /** Zero retains strict every-read LRU tracking. */
        public Builder accessDebounceMillis(long millis) { accessDebounceMillis = millis; return this; }
        public Builder recentTouchSlots(int slots) { recentTouchSlots = slots; return this; }

        public Builder hotEntityLimit(int hotEntityLimit) {
            this.hotEntityLimit = hotEntityLimit;
            return this;
        }

        public Builder pageSize(int pageSize) {
            this.pageSize = pageSize;
            return this;
        }

        public Builder lruEvictionEnabled(boolean lruEvictionEnabled) {
            this.lruEvictionEnabled = lruEvictionEnabled;
            return this;
        }

        public Builder entityTtlSeconds(long entityTtlSeconds) {
            this.entityTtlSeconds = entityTtlSeconds;
            return this;
        }

        public Builder pageTtlSeconds(long pageTtlSeconds) {
            this.pageTtlSeconds = pageTtlSeconds;
            return this;
        }

        public Builder hotPolicy(EntityHotPolicy hotPolicy) {
            this.hotPolicy = hotPolicy;
            return this;
        }

        public Builder countWindow() {
            this.hotPolicy = EntityHotPolicy.countWindow();
            return this;
        }

        public Builder timeWindow(String timeColumn, long hotForSeconds) {
            this.hotPolicy = EntityHotPolicy.timeWindow(timeColumn, hotForSeconds);
            return this;
        }

        public Builder stateWindow(String stateColumn, java.util.Collection<String> stateValues) {
            this.hotPolicy = EntityHotPolicy.stateWindow(stateColumn, stateValues);
            return this;
        }

        public Builder customHotPredicate(CacheAdmissionPredicate predicate) {
            this.hotPolicy = EntityHotPolicy.customPredicate(predicate);
            return this;
        }

        public Builder compositeHotPolicy(java.util.Collection<EntityHotPolicy> children) {
            this.hotPolicy = EntityHotPolicy.allOf(children);
            return this;
        }

        public Builder compositeHotPolicy(
                EntityHotPolicyCompositeOperator operator,
                java.util.Collection<EntityHotPolicy> children) {
            this.hotPolicy =
                    EntityHotPolicy.builder()
                            .mode(EntityHotPolicyMode.COMPOSITE)
                            .compositeOperator(operator)
                            .children(children)
                            .build();
            return this;
        }

        public CachePolicy build() {
            return new CachePolicy(
                    hotEntityLimit,
                    pageSize,
                    lruEvictionEnabled,
                    entityTtlSeconds,
                    pageTtlSeconds,
                    hotPolicy,
                    accessDebounceMillis,
                    recentTouchSlots,
                    nearCachePolicy);
        }
    }
}
