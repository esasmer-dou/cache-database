package com.reactor.cachedb.starter;

import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.api.EntityRepository;
import com.reactor.cachedb.core.api.SourceRepository;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.config.AdminHttpConfig;
import com.reactor.cachedb.core.config.AdminMonitoringConfig;
import com.reactor.cachedb.core.config.CacheDatabaseConfig;
import com.reactor.cachedb.core.config.DeadLetterRecoveryConfig;
import com.reactor.cachedb.core.config.ProjectionRefreshConfig;
import com.reactor.cachedb.core.config.RuntimeCoordinationConfig;
import com.reactor.cachedb.core.config.SchemaBootstrapMode;
import com.reactor.cachedb.core.config.WriteBehindConfig;
import com.reactor.cachedb.core.model.EntityCodec;
import com.reactor.cachedb.core.model.EntityMetadata;
import com.reactor.cachedb.core.model.WriteReceipt;
import com.reactor.cachedb.core.page.EntityByIdLoader;
import com.reactor.cachedb.core.page.EntityPageLoader;
import com.reactor.cachedb.core.page.EntityQueryLoader;
import com.reactor.cachedb.core.page.NoOpEntityByIdLoader;
import com.reactor.cachedb.core.page.NoOpEntityPageLoader;
import com.reactor.cachedb.core.page.NoOpEntityQueryLoader;
import com.reactor.cachedb.core.projection.EntityProjection;
import com.reactor.cachedb.core.projection.EntityProjectionBinding;
import com.reactor.cachedb.core.query.QueryEvaluator;
import com.reactor.cachedb.core.queue.AdminReportJobSnapshot;
import com.reactor.cachedb.core.queue.DeadLetterManagement;
import com.reactor.cachedb.core.queue.LatencyMetricSnapshot;
import com.reactor.cachedb.core.queue.ProjectionRefreshFailureEntry;
import com.reactor.cachedb.core.queue.ProjectionRefreshReplayResult;
import com.reactor.cachedb.core.queue.ProjectionRefreshSnapshot;
import com.reactor.cachedb.core.queue.RecoveryCleanupSnapshot;
import com.reactor.cachedb.core.queue.StoragePerformanceCollector;
import com.reactor.cachedb.core.queue.StoragePerformanceSnapshot;
import com.reactor.cachedb.core.queue.WriteBehindFlusher;
import com.reactor.cachedb.core.queue.WriteBehindFlusherFactory;
import com.reactor.cachedb.core.registry.DefaultEntityRegistry;
import com.reactor.cachedb.core.registry.EntityBinding;
import com.reactor.cachedb.core.registry.EntityRegistry;
import com.reactor.cachedb.core.relation.NoOpRelationBatchLoader;
import com.reactor.cachedb.core.relation.RelationBatchLoader;
import com.reactor.cachedb.jdbc.JdbcEntitySourceLoader;
import com.reactor.cachedb.jdbc.JdbcSourceSqlRepository;
import com.reactor.cachedb.jdbc.JdbcStorageProviders;
import com.reactor.cachedb.redis.JedisPooledOperations;
import com.reactor.cachedb.redis.ProjectionRefreshDispatcher;
import com.reactor.cachedb.redis.RedisCacheIdGenerator;
import com.reactor.cachedb.redis.RedisClientOperations;
import com.reactor.cachedb.redis.RedisDeadLetterManagement;
import com.reactor.cachedb.redis.RedisDeadLetterRecoveryWorker;
import com.reactor.cachedb.redis.RedisDurabilityTracker;
import com.reactor.cachedb.redis.RedisFunctionArgsMapper;
import com.reactor.cachedb.redis.RedisFunctionExecutor;
import com.reactor.cachedb.redis.RedisFunctionLibrarySource;
import com.reactor.cachedb.redis.RedisFunctionLoader;
import com.reactor.cachedb.redis.RedisHotSetManager;
import com.reactor.cachedb.redis.RedisHotSetReconciliationResult;
import com.reactor.cachedb.redis.RedisIndexMaintenance;
import com.reactor.cachedb.redis.RedisKeyStrategy;
import com.reactor.cachedb.redis.RedisLeaderLease;
import com.reactor.cachedb.redis.RedisProducerGuard;
import com.reactor.cachedb.redis.RedisProjectionRefreshQueue;
import com.reactor.cachedb.redis.RedisProjectionRefreshWorker;
import com.reactor.cachedb.redis.RedisRecoveryCleanupWorker;
import com.reactor.cachedb.redis.RedisRouteCoverageStore;
import com.reactor.cachedb.redis.RedisWriteBehindQueue;
import com.reactor.cachedb.redis.RedisWriteBehindWorker;
import com.reactor.cachedb.redis.RedisWriteOperationMapper;

import redis.clients.jedis.JedisPooled;

import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;

import javax.sql.DataSource;

public final class CacheDatabase implements CacheSession, AutoCloseable {

    private final com.reactor.cachedb.core.config.CacheRuntimeOptions runtimeOptions;
    private final com.reactor.cachedb.core.trace.TraceContextPropagator runtimeTraceContextPropagator;
    public com.reactor.cachedb.core.config.CacheRuntimeOptions runtimeOptions() { return runtimeOptions; }
    public com.reactor.cachedb.core.config.NearCacheInvalidationMode nearCacheInvalidationMode() { return nearCaches.invalidationMode(); }
    public java.util.function.BooleanSupplier nearCacheTrackingReadySupplier() { return nearCaches.trackingReadySupplier(); }
    public boolean publishLegacyNearInvalidations() { return nearCaches.publishLegacyInvalidations(); }

    private final CacheDatabaseConfig config;
    private final DataSource dataSource;
    private final RedisClientOperations foregroundJedis;
    private final RedisClientOperations backgroundJedis;
    private final java.util.concurrent.CopyOnWriteArrayList<AutoCloseable> ownedResources =
            new java.util.concurrent.CopyOnWriteArrayList<>();
    private final String instanceId;
    private final DefaultCacheSession session;
    private volatile CacheDataProtection dataProtection;

    /**
     * Install explicit native plans. Plan construction still requires approved complete route/runtime
     * inventory and a real distributed TenantReadFence; registration does not create that evidence.
     */
    public synchronized CacheDataProtection configureDataProtection(
            java.util.Collection<RedisTenantPurgePlan> plans, int maxConcurrentAdministrators) {
        if (dataProtection != null) throw new IllegalStateException("Data protection is already configured");
        if (plans == null || plans.isEmpty() || plans.size() > 64)
            throw new IllegalArgumentException("Data protection requires 1..64 explicit entity plans");
        for (var plan : plans) {
            var binding = entityRegistry.find(plan.entityName).orElseThrow(
                    () -> new IllegalArgumentException("Unknown protected entity plan"));
            var metadata = binding.metadata();
            if (!metadata.tenantPurgeEnabled() || metadata.entityType() != plan.entityType()
                    || !metadata.redisNamespace().equals(plan.scope())
                    || !metadata.tableName().equals(plan.binding.source().table())
                    || !metadata.idColumn().equals(plan.binding.source().idColumn())
                    || !java.util.Objects.equals(metadata.tenantFieldName(), plan.binding.source().tenantColumn())
                    || !metadata.versionColumn().equals(plan.versionColumn)
                    || plan.redis != foregroundJedis || plan.keys != redisKeyStrategy)
                throw new IllegalArgumentException("Purge plan is not bound to this database's entity/runtime");
        }
        dataProtection = new CacheDataProtection(entityRegistry, plans, maxConcurrentAdministrators);
        return dataProtection;
    }

    public CacheDataProtection dataProtection() {
        var configured = dataProtection;
        if (configured == null) throw new com.reactor.cachedb.core.protection.ProtectionException(
                com.reactor.cachedb.core.protection.ProtectionException.Code.UNWIRED_PROTOCOL);
        return configured;
    }

    /** Borrowed actual key strategy, including Cluster/custom segments; never replace it in a purge plan. */
    public RedisKeyStrategy redisKeyStrategy() { return redisKeyStrategy; }

    private final com.reactor.cachedb.core.async.CacheAsyncExecutor asyncExecutor;
    @Override public com.reactor.cachedb.core.async.CacheAsyncExecutor asyncExecutor() { return asyncExecutor; }
    private final com.reactor.cachedb.redis.RedisRepositoryReadState pointReads;
    private final com.reactor.cachedb.redis.RedisNearCacheCoordinator nearCaches;
    /** Borrowed coordinator owned and closed by this database, not by callers or repository views. */
    public com.reactor.cachedb.redis.RedisNearCacheCoordinator nearCacheCoordinator() { return nearCaches; }
    /** Borrowed runtime shared by every synchronous repository/view in this database. */
    public com.reactor.cachedb.redis.RedisReadRuntime redisReadRuntime() { return pointReads.runtime(); }
    public com.reactor.cachedb.redis.RedisRepositoryReadState.Metrics redisReadMetrics() { return pointReads.metrics(); }
    public com.reactor.cachedb.redis.RedisRepositoryReadState.NativeReadMemory nativeReadMemory() {
        return pointReads.nativeReadMemory();
    }
    private final java.util.concurrent.CopyOnWriteArrayList<java.util.function.Consumer<com.reactor.cachedb.core.queue.QueuedWriteOperation>> durableListeners
            = new java.util.concurrent.CopyOnWriteArrayList<>();

    /** Listeners must only perform bounded, non-blocking notification; SQL has already committed. */
    public synchronized AutoCloseable onDurableEntityChange(
            java.util.function.Consumer<com.reactor.cachedb.core.queue.QueuedWriteOperation> listener) {
        java.util.Objects.requireNonNull(listener);
        if (durableListeners.size() >= 64) throw new IllegalStateException("At most 64 entity change listeners");
        durableListeners.add(listener);
        return () -> durableListeners.remove(listener);
    }

    private void publishDurableChange(com.reactor.cachedb.core.queue.QueuedWriteOperation operation) {
        for (var listener : durableListeners) {
            try { listener.accept(operation); }
            catch (RuntimeException failure) {
                System.getLogger(CacheDatabase.class.getName()).log(System.Logger.Level.WARNING,
                        "Durable entity change listener failed for " + operation.entityName(), failure);
            }
        }
    }
    private final EntityRegistry entityRegistry;
    private final RedisWriteBehindWorker writeBehindWorker;
    private final RedisDeadLetterRecoveryWorker deadLetterRecoveryWorker;
    private final RedisRecoveryCleanupWorker recoveryCleanupWorker;
    private final AdminReportJobWorker adminReportJobWorker;
    private final AdminIncidentDeliveryManager adminIncidentDeliveryManager;
    private final DeadLetterManagement deadLetterManagement;
    private final RedisFunctionLoader functionLoader;
    private final QueryEvaluator queryEvaluator;
    private final RedisProducerGuard producerGuard;
    private final RedisIndexMaintenance indexMaintenance;
    private final CacheDatabaseSchemaAdmin schemaAdmin;
    private final MonitoringHistoryBuffer monitoringHistoryBuffer;
    private final AlertRouteHistoryBuffer alertRouteHistoryBuffer;
    private final PerformanceHistoryBuffer performanceHistoryBuffer;
    private final StoragePerformanceCollector storagePerformanceCollector;
    private final RedisStoragePerformanceMirror storagePerformanceMirror;
    private final boolean adminMonitoringEnabled;
    private final ProjectionRefreshDispatcher projectionRefreshDispatcher;
    private final RedisProjectionRefreshQueue projectionRefreshQueue;
    private final RedisProjectionRefreshWorker projectionRefreshWorker;
    private final CacheDatabaseAdminContext adminContext;
    private final RedisDurabilityTracker durabilityTracker;
    private final RedisKeyStrategy redisKeyStrategy;
    private final com.reactor.cachedb.core.route.RouteCoverageStore routeCoverageStore;
    private final com.reactor.cachedb.core.repository.CacheIdGenerator idGenerator;

    // Non-tenant resident re-encryption: isolated from producer and tenant-purge wiring.
    private final CacheDatabaseReencryption reencryption = ownReencryption();

    private CacheDatabaseReencryption ownReencryption() {
        var service = new CacheDatabaseReencryption(this);
        ownResource(service);
        return service;
    }

    /** Cached database-owned handle; actual registration/provider are mandatory. Administrative only. */
    public CacheReencryptionJob reencryptionRunner(Class<?> entityClass) {
        return reencryption.factory(entityClass);
    }

    /** Bounded Redis-resident maintenance. SOURCE is explicitly unsupported, not a business save. */
    public com.reactor.cachedb.redis.RedisNonTenantReencryptionRunner.Step reencrypt(
            Class<?> entityClass, int maxRows,
            com.reactor.cachedb.redis.RedisNonTenantReencryptionRunner.Scope scope) {
        reencryption.validate(maxRows, scope);
        return reencryptionRunner(entityClass).reencrypt(maxRows, scope);
    }

    public com.reactor.cachedb.redis.RedisNonTenantReencryptionRunner.Step reencrypt(
            Class<?> entityClass, int maxRows) {
        return reencrypt(entityClass, maxRows,
                com.reactor.cachedb.redis.RedisNonTenantReencryptionRunner.Scope.REDIS_RESIDENT);
    }

    public static CacheDatabaseBootstrap bootstrap(DataSource dataSource) {
        return CacheDatabaseBootstrap.using(dataSource);
    }

    public static CacheDatabaseBootstrap bootstrap(JedisPooled jedis, DataSource dataSource) {
        return bootstrap(JedisPooledOperations.of(jedis), dataSource);
    }

    public static CacheDatabaseBootstrap bootstrap(
            RedisClientOperations jedis, DataSource dataSource) {
        return CacheDatabaseBootstrap.using(jedis, dataSource);
    }

    public static CacheDatabaseBootstrap bootstrap(
            JedisPooled foregroundJedis, JedisPooled backgroundJedis, DataSource dataSource) {
        return bootstrap(
                JedisPooledOperations.of(foregroundJedis),
                JedisPooledOperations.of(backgroundJedis),
                dataSource);
    }

    public static CacheDatabaseBootstrap bootstrap(
            RedisClientOperations foregroundJedis,
            RedisClientOperations backgroundJedis,
            DataSource dataSource) {
        return CacheDatabaseBootstrap.using(foregroundJedis, backgroundJedis, dataSource);
    }

    public static CacheDatabaseBootstrap bootstrap(String redisUri, DataSource dataSource) {
        return CacheDatabaseBootstrap.connect(redisUri, dataSource);
    }

    public static CacheDatabaseBootstrap bootstrap(
            String foregroundRedisUri, String backgroundRedisUri, DataSource dataSource) {
        return CacheDatabaseBootstrap.connect(foregroundRedisUri, backgroundRedisUri, dataSource);
    }

    public CacheDatabase(JedisPooled jedis, DataSource dataSource, CacheDatabaseConfig config) {
        this(JedisPooledOperations.of(jedis), dataSource, config);
    }

    public CacheDatabase(
            RedisClientOperations jedis, DataSource dataSource, CacheDatabaseConfig config) {
        this(jedis, jedis, dataSource, config);
    }

    public CacheDatabase(
            JedisPooled foregroundJedis,
            JedisPooled backgroundJedis,
            DataSource dataSource,
            CacheDatabaseConfig config) {
        this(
                JedisPooledOperations.of(foregroundJedis),
                JedisPooledOperations.of(backgroundJedis),
                dataSource,
                config);
    }

    public CacheDatabase(JedisPooled jedis, DataSource dataSource, CacheDatabaseConfig config,
            com.reactor.cachedb.core.config.CacheRuntimeOptions runtimeOptions) {
        this(JedisPooledOperations.of(jedis), dataSource, config, runtimeOptions);
    }

    public CacheDatabase(RedisClientOperations jedis, DataSource dataSource, CacheDatabaseConfig config,
            com.reactor.cachedb.core.config.CacheRuntimeOptions runtimeOptions) {
        this(jedis, jedis, dataSource, config, runtimeOptions);
    }

    public CacheDatabase(JedisPooled foregroundJedis, JedisPooled backgroundJedis, DataSource dataSource,
            CacheDatabaseConfig config, com.reactor.cachedb.core.config.CacheRuntimeOptions runtimeOptions) {
        this(JedisPooledOperations.of(foregroundJedis), JedisPooledOperations.of(backgroundJedis),
                dataSource, config, runtimeOptions);
    }

    public CacheDatabase(
            RedisClientOperations foregroundJedis,
            RedisClientOperations backgroundJedis,
            DataSource dataSource,
            CacheDatabaseConfig config) {
        this(foregroundJedis, backgroundJedis, dataSource, config,
                com.reactor.cachedb.core.config.CacheRuntimeOptions.defaults());
    }

    public CacheDatabase(
            RedisClientOperations foregroundJedis,
            RedisClientOperations backgroundJedis,
            DataSource dataSource,
            CacheDatabaseConfig config,
            com.reactor.cachedb.core.config.CacheRuntimeOptions runtimeOptions) {
        this.runtimeOptions = java.util.Objects.requireNonNull(runtimeOptions, "runtimeOptions");
        this.runtimeTraceContextPropagator = runtimeOptions.observationRecorder().enabled()
                && runtimeOptions.observationTraceparentSupplier() != com.reactor.cachedb.core.observe.CacheTraceparentSupplier.NONE
                ? new com.reactor.cachedb.core.observe.ObservingTraceContextPropagator(
                        config.traceContextPropagator(), runtimeOptions.observationTraceparentSupplier(), true)
                : config.traceContextPropagator();
        this.dataSource = dataSource;
        this.foregroundJedis = foregroundJedis;
        this.backgroundJedis = backgroundJedis;
        if ((foregroundJedis.clustered() || backgroundJedis.clustered()) && config.keyspace().keyPrefix().contains("{")) {
            com.reactor.cachedb.redis.ClusterHashTagKeyStrategy.validateTagged(
                    config.keyspace().keyPrefix());
            var atomicKeys =
                    new java.util.ArrayList<String>(config.writeBehind().activeStreamKeys());
            atomicKeys.add(config.writeBehind().streamKey());
            atomicKeys.add(config.writeBehind().deadLetterStreamKey());
            atomicKeys.add(config.keyspace().keyPrefix() + ":cluster-validation");
            for (var key : atomicKeys)
                com.reactor.cachedb.redis.ClusterHashTagKeyStrategy.validateTagged(key);
            if (foregroundJedis.clustered()) foregroundJedis.requireSameSlot(atomicKeys);
            if (backgroundJedis.clustered()) backgroundJedis.requireSameSlot(atomicKeys);
        }
        this.instanceId =
                RuntimeCoordinationSupport.resolveInstanceId(config.runtimeCoordination());
        RuntimeCoordinationConfig effectiveRuntimeCoordination =
                RuntimeCoordinationConfig.builder()
                        .instanceId(instanceId)
                        .appendInstanceIdToConsumerNames(
                                config.runtimeCoordination().appendInstanceIdToConsumerNames())
                        .leaderLeaseEnabled(config.runtimeCoordination().leaderLeaseEnabled())
                        .leaderLeaseSegment(config.runtimeCoordination().leaderLeaseSegment())
                        .leaderLeaseTtlMillis(config.runtimeCoordination().leaderLeaseTtlMillis())
                        .leaderLeaseRenewIntervalMillis(
                                config.runtimeCoordination().leaderLeaseRenewIntervalMillis())
                        .build();
        this.entityRegistry = new DefaultEntityRegistry(config.resourceLimits(), runtimeOptions.keyProvider());
        this.queryEvaluator = new QueryEvaluator();
        this.projectionRefreshDispatcher = null;
        this.adminMonitoringEnabled = config.adminMonitoring().enabled() && config.runtimeRole().runsWorkers();
        WriteBehindConfig effectiveWriteBehindConfig =
                RuntimeCoordinationSupport.withInstanceIdentity(
                        config.writeBehind(), config.runtimeCoordination(), instanceId);
        DeadLetterRecoveryConfig effectiveDeadLetterRecoveryConfig =
                RuntimeCoordinationSupport.withInstanceIdentity(
                        config.deadLetterRecovery(), config.runtimeCoordination(), instanceId);
        ProjectionRefreshConfig effectiveProjectionRefreshConfig =
                RuntimeCoordinationSupport.withInstanceIdentity(
                        config.projectionRefresh(), config.runtimeCoordination(), instanceId);
        AdminMonitoringConfig effectiveAdminMonitoringConfig =
                RuntimeCoordinationSupport.withInstanceIdentity(
                        config.adminMonitoring(), config.runtimeCoordination(), instanceId);
        this.storagePerformanceCollector =
                adminMonitoringEnabled
                        ? new StoragePerformanceCollector()
                        : StoragePerformanceCollector.noop();
        this.storagePerformanceMirror =
                adminMonitoringEnabled
                        ? new RedisStoragePerformanceMirror(
                                storagePerformanceCollector,
                                backgroundJedis,
                                effectiveAdminMonitoringConfig)
                        : RedisStoragePerformanceMirror.disabled(
                                storagePerformanceCollector, effectiveAdminMonitoringConfig);

        RedisWriteOperationMapper mapper = new RedisWriteOperationMapper(runtimeTraceContextPropagator, entityRegistry);
        RedisKeyStrategy keyStrategy =
                foregroundJedis.clustered() || backgroundJedis.clustered()
                ? new com.reactor.cachedb.redis.ClusterHashTagKeyStrategy(config.keyspace())
                : new RedisKeyStrategy(
                        config.keyspace().keyPrefix(),
                        config.keyspace().entitySegment(),
                        config.keyspace().pageSegment(),
                        config.keyspace().versionSegment(),
                        config.keyspace().tombstoneSegment(),
                        config.keyspace().hotSetSegment(),
                        config.keyspace().indexSegment(),
                        config.keyspace().compactionSegment());
        if (keyStrategy instanceof com.reactor.cachedb.redis.ClusterHashTagKeyStrategy clusterKeys)
            clusterKeys.registeredNamespaces(() -> entityRegistry.all().stream()
                    .map(binding -> binding.metadata().redisNamespace()).distinct().sorted().toList());
        this.routeCoverageStore =
                new RedisRouteCoverageStore(backgroundJedis, config.keyspace().keyPrefix());
        this.idGenerator =
                new RedisCacheIdGenerator(
                        backgroundJedis, config.keyspace().keyPrefix() + ":sequence");
        this.redisKeyStrategy = keyStrategy;
        // One validated fleet policy drives both reads and foreground/background write publication.
        nearCaches = new com.reactor.cachedb.redis.RedisNearCacheCoordinator(
                backgroundJedis, keyStrategy, runtimeOptions.nearCacheInvalidation());
        ownResource(nearCaches);
        if (foregroundJedis instanceof com.reactor.cachedb.redis.RedisTopologyChangeSource source)
            ownResource(source.onTopologyChange(nearCaches::topologyChanged));
        if (backgroundJedis != foregroundJedis && backgroundJedis instanceof com.reactor.cachedb.redis.RedisTopologyChangeSource source)
            ownResource(source.onTopologyChange(nearCaches::topologyChanged));
        this.durabilityTracker = new RedisDurabilityTracker(backgroundJedis, keyStrategy);
        RedisFunctionExecutor functionExecutor =
                new RedisFunctionExecutor(
                        foregroundJedis,
                        config.redisFunctions(),
                        config.redisGuardrail(),
                        effectiveWriteBehindConfig,
                        new RedisFunctionArgsMapper(runtimeTraceContextPropagator).withNearInvalidationChannel(keyStrategy.nearInvalidationChannel())
                                .withNearInvalidationPublisher(nearCaches::publishLegacyInvalidations));
        RedisFunctionExecutor backgroundFunctionExecutor =
                new RedisFunctionExecutor(
                        backgroundJedis,
                        config.redisFunctions(),
                        config.redisGuardrail(),
                        effectiveWriteBehindConfig,
                        new RedisFunctionArgsMapper(runtimeTraceContextPropagator).withNearInvalidationChannel(keyStrategy.nearInvalidationChannel())
                                .withNearInvalidationPublisher(nearCaches::publishLegacyInvalidations));
        RedisWriteBehindQueue queue =
                new RedisWriteBehindQueue(
                        foregroundJedis,
                        effectiveWriteBehindConfig.streamKey(),
                        effectiveWriteBehindConfig.compactionStreamKey(),
                        mapper,
                        config.resourceLimits().maxColumnsPerOperation(),
                        effectiveWriteBehindConfig,
                        config.redisGuardrail(),
                        keyStrategy);
        RedisHotSetManager hotSetManager = new RedisHotSetManager(foregroundJedis, keyStrategy);
        this.producerGuard =
                new RedisProducerGuard(
                        backgroundJedis,
                        config.redisGuardrail(),
                        effectiveWriteBehindConfig,
                        keyStrategy,
                        config.adminReportJob().diagnosticsStreamKey(),
                        config.adminReportJob().diagnosticsMaxLength());
        this.indexMaintenance =
                new RedisIndexMaintenance(
                        backgroundJedis,
                        entityRegistry,
                        keyStrategy,
                        config.queryIndex(),
                        config.relations(),
                        queryEvaluator);
        this.projectionRefreshQueue =
                effectiveProjectionRefreshConfig.enabled()
                        ? new RedisProjectionRefreshQueue(
                                backgroundJedis, effectiveProjectionRefreshConfig)
                        : null;
        this.projectionRefreshWorker =
                effectiveProjectionRefreshConfig.enabled() && config.runtimeRole().runsWorkers()
                        ? new RedisProjectionRefreshWorker(
                                backgroundJedis,
                                effectiveProjectionRefreshConfig,
                                projectionRefreshQueue,
                                keyStrategy,
                                entityRegistry,
                                config.queryIndex(),
                                config.relations(),
                                queryEvaluator,
                                producerGuard)
                        : null;
        WriteBehindFlusher flusher = !config.runtimeRole().runsWorkers()
                ? operation -> { throw new IllegalStateException("CLIENT_ONLY cannot flush SQL writes"); }
                : createWriteBehindFlusher(
                        dataSource,
                        entityRegistry,
                        effectiveWriteBehindConfig,
                        storagePerformanceCollector,
                        config.writeBehindFlusherFactory());
        this.functionLoader =
                new RedisFunctionLoader(
                        backgroundJedis, config.redisFunctions(), new RedisFunctionLibrarySource());

        CacheDatabaseConfig runtimeConfig =
                config.toBuilder()
                        .writeBehind(effectiveWriteBehindConfig)
                        .deadLetterRecovery(effectiveDeadLetterRecoveryConfig)
                        .projectionRefresh(effectiveProjectionRefreshConfig)
                        .adminMonitoring(effectiveAdminMonitoringConfig)
                        .runtimeCoordination(effectiveRuntimeCoordination)
                        .build();
        this.config = runtimeConfig;
        pointReads = new com.reactor.cachedb.redis.RedisRepositoryReadState(foregroundJedis, runtimeOptions.redisReadCoalescing());
        ownResource(pointReads);
        asyncExecutor = new com.reactor.cachedb.core.async.CacheAsyncExecutor(
                runtimeOptions.asyncMaxConcurrent(), runtimeOptions.asyncExecutor(),
                runtimeTraceContextPropagator,
                com.reactor.cachedb.core.async.CacheAsyncExecutor.DEFAULT_SHUTDOWN_TIMEOUT);
        ownResource(asyncExecutor);
        this.session =
                new DefaultCacheSession(
                        foregroundJedis,
                        backgroundJedis,
                        runtimeConfig,
                        entityRegistry,
                        queue,
                        keyStrategy,
                        functionExecutor,
                        producerGuard,
                        hotSetManager,
                        queryEvaluator,
                        storagePerformanceCollector,
                        projectionRefreshDispatcher,
                        projectionRefreshQueue, runtimeOptions).withNearCacheCoordinator(nearCaches).withReadRuntime(pointReads)
                        .withAsyncExecutor(asyncExecutor);
        this.writeBehindWorker =
                new RedisWriteBehindWorker(
                        backgroundJedis,
                        flusher,
                        effectiveWriteBehindConfig,
                        mapper,
                        keyStrategy,
                        backgroundFunctionExecutor).withTraceContextPropagator(runtimeTraceContextPropagator)
                        .withDurableListener(this::publishDurableChange);
        this.deadLetterRecoveryWorker =
                new RedisDeadLetterRecoveryWorker(
                        backgroundJedis,
                        flusher,
                        effectiveDeadLetterRecoveryConfig,
                        mapper,
                        keyStrategy,
                        effectiveWriteBehindConfig.deadLetterStreamKey())
                        .withTraceContextPropagator(runtimeTraceContextPropagator)
                        .withDurableListener(this::publishDurableChange);
        RedisLeaderLease recoveryCleanupLeaderLease =
                !config.runtimeRole().runsWorkers() ? null : RuntimeCoordinationSupport.leaderLease(
                        backgroundJedis,
                        config.keyspace().keyPrefix(),
                        config.runtimeCoordination(),
                        instanceId,
                        "recovery-cleanup");
        this.recoveryCleanupWorker =
                new RedisRecoveryCleanupWorker(
                        backgroundJedis,
                        effectiveDeadLetterRecoveryConfig,
                        effectiveWriteBehindConfig.deadLetterStreamKey(),
                        recoveryCleanupLeaderLease);
        this.deadLetterManagement =
                new RedisDeadLetterManagement(
                        backgroundJedis,
                        flusher,
                        effectiveDeadLetterRecoveryConfig,
                        mapper,
                        keyStrategy,
                        effectiveWriteBehindConfig.deadLetterStreamKey())
                        .withTraceContextPropagator(runtimeTraceContextPropagator)
                        .withDurableListener(this::publishDurableChange);
        if (adminMonitoringEnabled) {
            RedisLeaderLease adminReportLeaderLease =
                    RuntimeCoordinationSupport.leaderLease(
                            backgroundJedis,
                            config.keyspace().keyPrefix(),
                            config.runtimeCoordination(),
                            instanceId,
                            "admin-report-job");
            RedisLeaderLease monitoringHistoryLeaderLease =
                    RuntimeCoordinationSupport.leaderLease(
                            backgroundJedis,
                            config.keyspace().keyPrefix(),
                            config.runtimeCoordination(),
                            instanceId,
                            "monitoring-history");
            RedisLeaderLease alertRouteHistoryLeaderLease =
                    RuntimeCoordinationSupport.leaderLease(
                            backgroundJedis,
                            config.keyspace().keyPrefix(),
                            config.runtimeCoordination(),
                            instanceId,
                            "alert-route-history");
            RedisLeaderLease performanceHistoryLeaderLease =
                    RuntimeCoordinationSupport.leaderLease(
                            backgroundJedis,
                            config.keyspace().keyPrefix(),
                            config.runtimeCoordination(),
                            instanceId,
                            "performance-history");
            this.adminIncidentDeliveryManager =
                    new AdminIncidentDeliveryManager(
                            effectiveAdminMonitoringConfig, backgroundJedis);
            this.adminReportJobWorker =
                    new AdminReportJobWorker(
                            this::admin,
                            config.adminReportJob(),
                            adminReportLeaderLease,
                            "cachedb-admin-report-job-" + instanceId);
            this.monitoringHistoryBuffer =
                    new MonitoringHistoryBuffer(
                            this::admin,
                            backgroundJedis,
                            effectiveAdminMonitoringConfig,
                            monitoringHistoryLeaderLease,
                            "cachedb-monitoring-history-" + instanceId);
            this.alertRouteHistoryBuffer =
                    new AlertRouteHistoryBuffer(
                            this::admin,
                            backgroundJedis,
                            effectiveAdminMonitoringConfig,
                            alertRouteHistoryLeaderLease,
                            "cachedb-alert-route-history-" + instanceId);
            this.performanceHistoryBuffer =
                    new PerformanceHistoryBuffer(
                            this::admin,
                            backgroundJedis,
                            effectiveAdminMonitoringConfig,
                            performanceHistoryLeaderLease,
                            "cachedb-performance-history-" + instanceId);
        } else {
            this.adminIncidentDeliveryManager =
                    AdminIncidentDeliveryManager.disabled(effectiveAdminMonitoringConfig);
            this.adminReportJobWorker = AdminReportJobWorker.disabled(config.adminReportJob());
            this.monitoringHistoryBuffer =
                    MonitoringHistoryBuffer.disabled(effectiveAdminMonitoringConfig);
            this.alertRouteHistoryBuffer =
                    AlertRouteHistoryBuffer.disabled(effectiveAdminMonitoringConfig);
            this.performanceHistoryBuffer =
                    PerformanceHistoryBuffer.disabled(effectiveAdminMonitoringConfig);
        }
        this.schemaAdmin =
                new CacheDatabaseSchemaAdmin(dataSource, entityRegistry, config.schemaBootstrap());
        this.adminContext = new CacheDatabaseAdminContext(this,
                new CacheDatabaseAdminContext.Infrastructure(dataSource, backgroundJedis, redisKeyStrategy, entityRegistry,
                        session, deadLetterManagement, indexMaintenance, schemaAdmin, adminIncidentDeliveryManager::enqueue));
    }

    public void start() {
        if (config.runtimeRole().runsWorkers() && config.schemaBootstrap().autoApplyOnStart()
                && config.schemaBootstrap().mode() != SchemaBootstrapMode.DISABLED) {
            SchemaBootstrapResult schemaResult = schemaAdmin.applyConfiguredMode();
            if (!schemaResult.success()) {
                throw new SchemaBootstrapException(schemaResult);
            }
        }
        functionLoader.initialize();
        if (!config.runtimeRole().runsWorkers()) return;
        writeBehindWorker.start();
        deadLetterRecoveryWorker.start();
        recoveryCleanupWorker.start();
        if (adminMonitoringEnabled) {
            adminIncidentDeliveryManager.start();
            adminReportJobWorker.start();
            monitoringHistoryBuffer.start();
            alertRouteHistoryBuffer.start();
            performanceHistoryBuffer.start();
        }
        if (projectionRefreshWorker != null) {
            projectionRefreshWorker.start();
        }
    }

    public <T, ID> EntityBinding<T, ID> register(
            EntityMetadata<T, ID> metadata, EntityCodec<T> codec, CachePolicy cachePolicy) {
        return entityRegistry.register(
                metadata,
                codec,
                cachePolicy,
                new NoOpRelationBatchLoader<>(),
                new NoOpEntityPageLoader<>(),
                new NoOpEntityByIdLoader<>(),
                new NoOpEntityQueryLoader<>());
    }

    public <T, ID> EntityBinding<T, ID> register(
            EntityMetadata<T, ID> metadata,
            EntityCodec<T> codec,
            CachePolicy cachePolicy,
            RelationBatchLoader<T> relationBatchLoader) {
        return entityRegistry.register(
                metadata,
                codec,
                cachePolicy,
                relationBatchLoader,
                new NoOpEntityPageLoader<>(),
                new NoOpEntityByIdLoader<>(),
                new NoOpEntityQueryLoader<>());
    }

    public <T, ID> EntityBinding<T, ID> register(
            EntityMetadata<T, ID> metadata,
            EntityCodec<T> codec,
            CachePolicy cachePolicy,
            RelationBatchLoader<T> relationBatchLoader,
            EntityPageLoader<T> pageLoader) {
        return register(
                metadata,
                codec,
                cachePolicy,
                relationBatchLoader,
                pageLoader,
                new NoOpEntityByIdLoader<>(),
                new NoOpEntityQueryLoader<>());
    }

    public <T, ID> EntityBinding<T, ID> register(
            EntityMetadata<T, ID> metadata,
            EntityCodec<T> codec,
            CachePolicy cachePolicy,
            RelationBatchLoader<T> relationBatchLoader,
            EntityPageLoader<T> pageLoader,
            EntityByIdLoader<T, ID> byIdLoader,
            EntityQueryLoader<T> queryLoader) {
        return entityRegistry.register(
                metadata,
                codec,
                cachePolicy,
                relationBatchLoader,
                pageLoader,
                byIdLoader,
                queryLoader);
    }

    public <T, ID> EntityBinding<T, ID> registerJdbcBacked(
            EntityMetadata<T, ID> metadata, EntityCodec<T> codec) {
        return registerJdbcBacked(metadata, codec, config.resourceLimits().defaultCachePolicy());
    }

    public <T, ID> EntityBinding<T, ID> registerJdbcBacked(
            EntityMetadata<T, ID> metadata, EntityCodec<T> codec, CachePolicy cachePolicy) {
        return registerJdbcBacked(
                metadata, codec, cachePolicy, new NoOpRelationBatchLoader<>(), null);
    }

    public <T, ID> EntityBinding<T, ID> registerJdbcBacked(
            EntityMetadata<T, ID> metadata,
            EntityCodec<T> codec,
            CachePolicy cachePolicy,
            RelationBatchLoader<T> relationBatchLoader) {
        return registerJdbcBacked(metadata, codec, cachePolicy, relationBatchLoader, null);
    }

    public <T, ID> EntityBinding<T, ID> registerJdbcBacked(
            EntityMetadata<T, ID> metadata,
            EntityCodec<T> codec,
            CachePolicy cachePolicy,
            RelationBatchLoader<T> relationBatchLoader,
            EntityPageLoader<T> pageLoader) {
        codec = com.reactor.cachedb.core.crypto.EncryptedStorageChecks.bind(metadata, codec, runtimeOptions.keyProvider());
        JdbcEntitySourceLoader<T, ID> sourceLoader =
                new JdbcEntitySourceLoader<>(
                        dataSource,
                        metadata,
                        codec,
                        config.readThrough().maxQueryLoadRows(),
                        config.readThrough().queryTimeoutSeconds());
        EntityPageLoader<T> resolvedPageLoader = pageLoader == null ? sourceLoader : pageLoader;
        return register(
                metadata,
                codec,
                cachePolicy,
                relationBatchLoader == null ? new NoOpRelationBatchLoader<>() : relationBatchLoader,
                resolvedPageLoader,
                sourceLoader,
                sourceLoader);
    }

    public <T, ID> EntityBinding<T, ID> register(
            EntityMetadata<T, ID> metadata, EntityCodec<T> codec) {
        return register(
                metadata,
                codec,
                config.resourceLimits().defaultCachePolicy(),
                new NoOpRelationBatchLoader<>(),
                new NoOpEntityPageLoader<>(),
                new NoOpEntityByIdLoader<>(),
                new NoOpEntityQueryLoader<>());
    }

    public <T, ID> EntityBinding<T, ID> register(EntityBinding<T, ID> binding) {
        return register(
                binding.metadata(),
                binding.codec(),
                binding.cachePolicy(),
                binding.relationBatchLoader(),
                binding.pageLoader(),
                binding.byIdLoader(),
                binding.queryLoader());
    }

    public CacheWarmResult warm(CacheWarmPlan plan) {
        return new CacheWarmRunner(this).execute(plan);
    }

    public CacheWarmResult dryRun(CacheWarmPlan plan) {
        return new CacheWarmRunner(this).dryRun(plan);
    }

    public CacheWarmResult warmProjections(CacheWarmPlan plan) {
        return new CacheWarmRunner(this).executeProjectionsOnly(plan);
    }

    /**
     * Executes the plan without asking callers to repeat its entity/projection admission decision
     * in a second boolean flag.
     */
    public CacheWarmExecution executeWarm(CacheWarmPlan plan, CacheWarmExecutionMode mode) {
        if (plan == null) {
            throw new IllegalArgumentException("plan must not be null");
        }
        if (mode == null) {
            throw new IllegalArgumentException("mode must not be null");
        }
        CacheWarmResult result =
                mode == CacheWarmExecutionMode.DRY_RUN
                        ? dryRun(plan)
                        : plan.projectionsOnly() ? warmProjections(plan) : warm(plan);
        return new CacheWarmExecution(plan, mode, result);
    }

    /**
     * Incrementally evicts Redis entities and projections that no longer satisfy their registered
     * hot policy. The durable SQL row is never changed.
     */
    public CacheHotSetReconciliationResult reconcileHotSet(
            String entityName, String cursor, int maxRows, int scanCount) {
        String normalizedEntityName = entityName == null ? "" : entityName.trim();
        EntityBinding<?, ?> rawBinding =
                entityRegistry
                        .find(normalizedEntityName)
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "No registered CacheDB entity found for hot-set"
                                                        + " reconciliation: "
                                                        + normalizedEntityName));
        return reconcileHotSet(rawBinding, cursor, maxRows, scanCount);
    }

    public List<CacheWarmResult> warmAll(Collection<CacheWarmPlan> plans) {
        if (plans == null || plans.isEmpty()) {
            return List.of();
        }
        CacheWarmRunner runner = new CacheWarmRunner(this);
        ArrayList<CacheWarmResult> results = new ArrayList<>(plans.size());
        for (CacheWarmPlan plan : plans) {
            results.add(runner.execute(plan));
        }
        return List.copyOf(results);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private CacheHotSetReconciliationResult reconcileHotSet(
            EntityBinding<?, ?> rawBinding, String cursor, int maxRows, int scanCount) {
        EntityBinding binding = rawBinding;
        EntityRepository repository =
                repository(binding.metadata(), binding.codec(), binding.cachePolicy());
        if (!(repository
                instanceof com.reactor.cachedb.redis.RedisEntityRepository redisRepository)) {
            throw new IllegalStateException(
                    "Hot-set reconciliation requires the Redis entity repository runtime for "
                            + rawBinding.metadata().entityName());
        }
        RedisHotSetReconciliationResult result =
                redisRepository.reconcileHotSet(cursor, maxRows, scanCount);
        return new CacheHotSetReconciliationResult(
                rawBinding.metadata().entityName(),
                result.nextCursor(),
                result.inspectedRows(),
                result.evictedRows(),
                result.missingRows(),
                result.invalidRows(),
                result.fullCycleCompleted());
    }

    private WriteBehindFlusher createWriteBehindFlusher(
            DataSource dataSource,
            EntityRegistry entityRegistry,
            WriteBehindConfig writeBehindConfig,
            StoragePerformanceCollector performanceCollector,
            WriteBehindFlusherFactory flusherFactory) {
        WriteBehindFlusher flusher = flusherFactory != null
                ? flusherFactory.create(dataSource, entityRegistry, writeBehindConfig, performanceCollector)
                : JdbcStorageProviders.require("postgres").writeBehindFlusherFactory(Map.of())
                        .create(dataSource, entityRegistry, writeBehindConfig, performanceCollector);
        if (flusher instanceof com.reactor.cachedb.jdbc.AbstractJdbcWriteBehindFlusher jdbc)
            jdbc.withObservationRecorder(runtimeOptions.observationRecorder())
                    .withObservationOriginLinksEnabled(runtimeOptions.observationTraceparentSupplier()
                            != com.reactor.cachedb.core.observe.CacheTraceparentSupplier.NONE);
        return flusher;
    }

    /**
     * Attach the native producer before the first repository is obtained.
     * This does NOT open a generation, invent a migration attestation or certify purge closure.
     * The returned capability is borrowed and participates in distributed producer-drain probes.
     */
    public com.reactor.cachedb.redis.RedisTenantProducer configureTenantProducer(EntityMetadata<?, ?> metadata, int maxInFlight) {
        var binding = entityRegistry.find(metadata.entityName()).orElseThrow(
                () -> new IllegalStateException("Register the entity before protection configuration"));
        if (!binding.metadata().redisNamespace().equals(metadata.redisNamespace())
                || !binding.metadata().tenantPurgeEnabled())
            throw new IllegalArgumentException("Protection metadata disagrees with the registered entity");
        var producer = session.configureTenantProducer(binding.metadata(), maxInFlight);
        ownedResources.add(producer);
        return producer;
    }

    private final java.util.concurrent.locks.ReentrantLock tenantProtectionPreparation =
            new java.util.concurrent.locks.ReentrantLock();

    /** First-only administrator binding. Inspect its descriptor, then bootstrap BEFORE INITIAL acquisition. */
    public <T,ID> CacheInitialNamespace<T,ID> prepareInitialNamespace(EntityMetadata<T,ID> metadata,
            com.reactor.cachedb.core.protection.TenantPurgeProtocol.Binding nativeBinding,
            com.reactor.cachedb.jdbc.JdbcTenantPurgeGuard guard,
            com.reactor.cachedb.jdbc.JdbcSourceOwnerOnboarding.JdbcIdCodec<ID> ids, ID first, ID last,
            int maxRows,int pageBytes,int rowBytes,long residentBytes,int maxInFlight) {
        var prepared=CacheInitialNamespace.prepare(this,session,metadata,nativeBinding,guard,ids,first,last,
                maxRows,pageBytes,rowBytes,residentBytes,maxInFlight);
        ownResource(prepared);return prepared;
    }

    com.reactor.cachedb.redis.RedisTenantProducer tenantProducerForEnrollment(EntityMetadata<?,?> metadata,int maxInFlight) {
        var existing=session.configuredTenantProducer(metadata);
        return existing==null?configureTenantProducer(metadata,maxInFlight):existing;
    }

    /** Prepare all registered protected producers before the first repository is published. */
    public CacheTenantRuntimeEnrollment prepareTenantProtection(int maxInFlight) {
        tenantProtectionPreparation.lock();
        try {
            var enrollment = CacheTenantRuntimeEnrollment.prepare(this, maxInFlight);
            ownedResources.add(enrollment);
            return enrollment;
        } finally { tenantProtectionPreparation.unlock(); }
    }

    /** Explicit administrative adoption of a bounded existing-identity worklist; never opens admission. */
    public <T,ID> CacheSourceOwnerOnboarding<ID> prepareSourceOwnerOnboarding(EntityMetadata<T,ID> metadata,
            CacheTenantRuntimeEnrollment enrollment, RedisTenantPurgePlan plan,
            com.reactor.cachedb.redis.RedisTenantRuntimeControl.ApprovedRoster approval,
            com.reactor.cachedb.jdbc.JdbcSourceOwnerOnboarding.JdbcIdCodec<ID> ids,
            java.util.List<ID> existingCandidates, java.util.Set<String> reviewedPlans) {
        return CacheSourceOwnerOnboarding.prepare(this,metadata,enrollment,plan,approval,ids,existingCandidates,reviewedPlans);
    }

    public <T, ID, P> EntityProjectionBinding<T, P, ID> registerProjection(
            EntityMetadata<T, ID> metadata, EntityProjection<T, P, ID> projection) {
        return entityRegistry.registerProjection(metadata, projection);
    }

    /** Explicit aggregate snapshot API; does not change repository COUNT/FACET semantics. */
    public com.reactor.cachedb.core.readmodel.CountFacetReadModel countFacetReadModel(
            EntityMetadata<?, ?> source,
            com.reactor.cachedb.core.readmodel.CountFacetDefinition definition) {
        Objects.requireNonNull(source, "source");
        var registered = entityRegistry.find(source.entityName()).orElseThrow(
                () -> new IllegalStateException("Register the source entity before creating its read model"));
        var actual = registered.metadata();
        if (actual.entityType() != source.entityType()
                || !actual.redisNamespace().equals(source.redisNamespace())
                || !Objects.equals(actual.tenantFieldName(), source.tenantFieldName())
                || actual.tenantPurgeEnabled() != source.tenantPurgeEnabled()) {
            throw new IllegalArgumentException("Read-model source disagrees with the registered entity");
        }
        return new com.reactor.cachedb.redis.RedisCountFacetReadModel(
                foregroundJedis, redisKeyStrategy, actual, definition);
    }

    @Override
    public <T, ID> EntityRepository<T, ID> repository(
            EntityMetadata<T, ID> metadata, EntityCodec<T> codec) {
        return session.repository(metadata, codec);
    }

    @Override
    public <T, ID> EntityRepository<T, ID> repository(
            EntityMetadata<T, ID> metadata, EntityCodec<T> codec, CachePolicy cachePolicy) {
        return session.repository(metadata, codec, cachePolicy);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T, ID> SourceRepository<T, ID> sourceRepository(
            EntityMetadata<T, ID> metadata, EntityCodec<T> codec) {
        com.reactor.cachedb.core.protection.TenantProtectionGate.requireLegacy(metadata);
        EntityBinding<?, ?> rawBinding =
                entityRegistry
                        .find(metadata.entityName())
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "No registered CacheDB entity found for source"
                                                        + " reads: "
                                                        + metadata.entityName()));
        EntityBinding<T, ID> binding = (EntityBinding<T, ID>) rawBinding;
        com.reactor.cachedb.core.protection.TenantProtectionGate.requireLegacy(binding.metadata());
        return new RegisteredSourceRepository<>(
                metadata,
                binding.byIdLoader(),
                binding.pageLoader(),
                binding.queryLoader());
    }

    public <T> com.reactor.cachedb.core.repository.SourceSqlRepository<T> sourceSqlRepository(
            EntityCodec<T> codec) {
        return new JdbcSourceSqlRepository<>(dataSource, codec);
    }

    @Override public <T, ID> EntityCodec<T> runtimeCodec(EntityMetadata<T, ID> metadata, EntityCodec<T> fallback) {
        var registered = entityRegistry.find(metadata.entityName());
        if (registered.isPresent()) {
            @SuppressWarnings("unchecked") var bound = (EntityBinding<T, ID>) registered.get();
            com.reactor.cachedb.core.crypto.EncryptedStorageChecks.sameMapping(metadata, bound.metadata());
            com.reactor.cachedb.core.crypto.EncryptedStorageChecks.requireBound(metadata, bound.codec());
            return bound.codec();
        }
        return com.reactor.cachedb.core.crypto.EncryptedStorageChecks.bind(metadata, fallback, runtimeOptions.keyProvider());
    }

    public <T> com.reactor.cachedb.core.model.SourceMapping<T> sourceMapping(com.reactor.cachedb.core.model.SourceMapping<T> mapping) {
        if (mapping.entityMetadata() == null) return mapping;
        @SuppressWarnings("unchecked") var metadata = (EntityMetadata<T, Object>) mapping.entityMetadata();
        var registered = entityRegistry.find(metadata.entityName());
        if (registered.isEmpty()) return mapping.bindEncryption(runtimeOptions.keyProvider());
        @SuppressWarnings("unchecked") var binding = (EntityBinding<T, Object>) registered.get();
        com.reactor.cachedb.core.crypto.EncryptedStorageChecks.sameMapping(metadata, binding.metadata());
        return mapping.withCodec(binding.codec());
    }

    public boolean isDurable(WriteReceipt<?, ?> receipt) {
        return durabilityTracker.isDurable(receipt);
    }

    public boolean isDurable(com.reactor.cachedb.core.api.CacheWriteBatchReceipt receipt) {
        java.util.Objects.requireNonNull(receipt, "receipt");
        if (receipt.dependencies().isEmpty())
            throw new IllegalArgumentException("Batch receipt has no durability dependencies");
        return durabilityTracker.areDurableDependencies(receipt.dependencies());
    }

    /** Creates a bounded writer that applies backpressure until SQL durability is proven. */
    public <T, ID> CacheDurableBatchWriter<T, ID> durableBatchWriter(
            String operation,
            int batchSize,
            int maxPendingReceipts,
            Duration durabilityTimeout,
            Function<Collection<T>, List<WriteReceipt<T, ID>>> writer) {
        if (durabilityTimeout == null
                || durabilityTimeout.isZero()
                || durabilityTimeout.isNegative()) {
            throw new IllegalArgumentException("durabilityTimeout must be greater than zero");
        }
        return new CacheDurableBatchWriter<>(
                operation,
                batchSize,
                maxPendingReceipts,
                writer,
                (receipts, resolvedOperation) ->
                        awaitDurableOrThrow(receipts, durabilityTimeout, resolvedOperation));
    }

    public boolean awaitDurable(WriteReceipt<?, ?> receipt, Duration timeout) {
        requireDurabilityArguments(receipt, timeout);
        return durabilityTracker.await(receipt, timeout, null);
    }

    public boolean awaitDurable(com.reactor.cachedb.core.api.CacheWriteBatchReceipt receipt, Duration timeout) {
        requireDurabilityArguments(receipt, timeout);
        return durabilityTracker.awaitBatch(receipt, timeout);
    }

    public <T, ID> WriteReceipt<T, ID> awaitDurableOrThrow(
            WriteReceipt<T, ID> receipt, Duration timeout) {
        requireDurabilityArguments(receipt, timeout);
        if (!awaitDurable(receipt, timeout)) {
            throw new com.reactor.cachedb.core.repository.WriteDurabilityTimeoutException(
                    receipt, timeout);
        }
        return receipt;
    }

    public boolean awaitDurable(
            Collection<? extends WriteReceipt<?, ?>> receipts, Duration timeout) {
        requireDurabilityArguments(receipts, timeout);
        return durabilityTracker.awaitAll(receipts, timeout, null);
    }

    @Override public boolean areDurable(Collection<? extends WriteReceipt<?, ?>> receipts) {
        return durabilityTracker.areDurable(receipts);
    }

    public <C extends Collection<? extends WriteReceipt<?, ?>>> C awaitDurableOrThrow(
            C receipts, Duration timeout) {
        return awaitDurableOrThrow(receipts, timeout, "");
    }

    public <C extends Collection<? extends WriteReceipt<?, ?>>> C awaitDurableOrThrow(
            C receipts, Duration timeout, String operation) {
        requireDurabilityArguments(receipts, timeout);
        if (!awaitDurable(receipts, timeout)) {
            throw new com.reactor.cachedb.core.repository.WriteBatchDurabilityTimeoutException(
                    receipts, timeout, operation);
        }
        return receipts;
    }

    private void requireDurabilityArguments(Object receipts, Duration timeout) {
        if (receipts == null) {
            throw new IllegalArgumentException("receipt(s) must not be null");
        }
        if (receipts instanceof Collection<?> collection) {
            for (Object receipt : collection) {
                if (receipt == null) {
                    throw new IllegalArgumentException("receipts must not contain null");
                }
            }
        }
        if (timeout == null || timeout.isZero() || timeout.isNegative()) {
            throw new IllegalArgumentException("timeout must be greater than zero");
        }
    }

    public com.reactor.cachedb.core.route.RouteCoverage routeCoverage(
            String routeName, String scope, Duration maxAge) {
        return routeCoverageStore.get(routeName, scope, maxAge);
    }

    public com.reactor.cachedb.core.route.RouteCoverage routeCoverage(
            com.reactor.cachedb.core.route.RepositoryRouteRef route,
            String scope,
            Duration maxAge) {
        com.reactor.cachedb.core.route.RepositoryRouteRef hotRoute =
                java.util.Objects.requireNonNull(route, "route")
                        .requireKind(com.reactor.cachedb.core.route.RepositoryRouteKind.HOT);
        return routeCoverage(hotRoute.routeName(), scope, maxAge);
    }

    public com.reactor.cachedb.core.route.RouteCoverageStore routeCoverageStore() {
        return routeCoverageStore;
    }

    public com.reactor.cachedb.core.repository.CacheIdGenerator idGenerator() {
        return idGenerator;
    }

    public EntityRegistry entityRegistry() {
        return entityRegistry;
    }

    public Optional<CachePolicy> registeredPolicy(String entityName) {
        if (entityName == null || entityName.isBlank()) {
            return Optional.empty();
        }
        return entityRegistry.find(entityName.trim()).map(EntityBinding::cachePolicy);
    }

    public com.reactor.cachedb.core.queue.WriteBehindWorkerSnapshot workerSnapshot() {
        return writeBehindWorker.snapshot();
    }

    public com.reactor.cachedb.core.queue.DeadLetterRecoverySnapshot deadLetterRecoverySnapshot() {
        return deadLetterRecoveryWorker.snapshot();
    }

    public DeadLetterManagement deadLetterManagement() {
        return deadLetterManagement;
    }

    public RecoveryCleanupSnapshot recoveryCleanupSnapshot() {
        return recoveryCleanupWorker.snapshot();
    }

    public AdminReportJobSnapshot adminReportJobSnapshot() {
        return adminReportJobWorker.snapshot();
    }

    public com.reactor.cachedb.core.queue.IncidentDeliverySnapshot incidentDeliverySnapshot() {
        return adminIncidentDeliveryManager.snapshot();
    }

    public com.reactor.cachedb.core.queue.RedisGuardrailSnapshot redisGuardrailSnapshot() {
        return producerGuard.snapshot();
    }

    public com.reactor.cachedb.core.queue.RedisRuntimeProfileSnapshot
            redisRuntimeProfileSnapshot() {
        return producerGuard.runtimeProfileSnapshot();
    }

    public java.util.List<com.reactor.cachedb.core.queue.RedisRuntimeProfileEvent>
            runtimeProfileEvents() {
        return producerGuard.runtimeProfileEvents();
    }

    public Map<String, String> activeRuntimeProfileProperties() {
        return producerGuard.activeRuntimeProfileProperties();
    }

    public StoragePerformanceSnapshot storagePerformanceSnapshot() {
        return storagePerformanceMirror.snapshot();
    }

    public StoragePerformanceCollector storagePerformanceCollector() {
        return storagePerformanceCollector;
    }

    public DataSource dataSource() {
        return dataSource;
    }

    RedisClientOperations backgroundRedisClient() {
        return backgroundJedis;
    }

    public RedisClientOperations redisOperations() {
        return foregroundJedis;
    }

    public RedisClientOperations backgroundRedisOperations() {
        return backgroundJedis;
    }

    String redisKeyPrefix() {
        return config.keyspace().keyPrefix();
    }

    public StoragePerformanceSnapshot resetStoragePerformance() {
        return storagePerformanceMirror.reset();
    }

    public ProjectionRefreshSnapshot projectionRefreshSnapshot() {
        return projectionRefreshWorker == null
                ? ProjectionRefreshSnapshot.empty()
                : projectionRefreshWorker.snapshot();
    }

    public List<ProjectionRefreshFailureEntry> projectionRefreshFailures(int limit) {
        return projectionRefreshWorker == null
                ? List.of()
                : projectionRefreshWorker.failures(limit);
    }

    public ProjectionRefreshReplayResult replayProjectionRefreshFailure(String entryId) {
        return projectionRefreshWorker == null
                ? new ProjectionRefreshReplayResult(
                        entryId == null ? "" : entryId,
                        false,
                        "",
                        "Projection refresh worker is not enabled.")
                : projectionRefreshWorker.replayFailure(entryId);
    }

    public String manualRuntimeProfileOverride() {
        return producerGuard.manualRuntimeProfileOverride();
    }

    public void setManualRuntimeProfile(String profile) {
        producerGuard.setManualRuntimeProfile(profile);
    }

    public void clearManualRuntimeProfileOverride() {
        producerGuard.clearManualRuntimeProfileOverride();
    }

    public java.util.List<MonitoringHistoryPoint> monitoringHistory(int limit) {
        return monitoringHistoryBuffer.history(limit);
    }

    public java.util.List<AlertRouteHistoryPoint> alertRouteHistory(int limit) {
        return alertRouteHistoryBuffer.history(limit);
    }

    public java.util.List<PerformanceHistoryPoint> performanceHistory(int limit) {
        return performanceHistoryBuffer.history(limit);
    }

    public AdminTelemetryResetSnapshot resetAdminTelemetryBuffers() {
        StoragePerformanceSnapshot performanceReset;
        try {
            performanceReset = resetStoragePerformance();
        } catch (RuntimeException ignored) {
            performanceReset = emptyPerformanceSnapshot();
        }
        int monitoringHistoryCleared;
        try {
            monitoringHistoryCleared = monitoringHistoryBuffer.clear();
        } catch (RuntimeException ignored) {
            monitoringHistoryCleared = 0;
        }
        int alertRouteHistoryCleared;
        try {
            alertRouteHistoryCleared = alertRouteHistoryBuffer.clear();
        } catch (RuntimeException ignored) {
            alertRouteHistoryCleared = 0;
        }
        return new AdminTelemetryResetSnapshot(
                0L,
                0L,
                monitoringHistoryCleared,
                alertRouteHistoryCleared,
                totalOperations(performanceReset),
                java.time.Instant.now());
    }

    public PerformanceTelemetryResetSnapshot resetPerformanceTelemetry() {
        StoragePerformanceSnapshot performanceReset;
        try {
            performanceReset = resetStoragePerformance();
        } catch (RuntimeException ignored) {
            performanceReset = emptyPerformanceSnapshot();
        }
        int performanceHistoryCleared;
        try {
            performanceHistoryCleared = performanceHistoryBuffer.clear();
        } catch (RuntimeException ignored) {
            performanceHistoryCleared = 0;
        }
        return new PerformanceTelemetryResetSnapshot(
                totalOperations(performanceReset),
                performanceHistoryCleared,
                java.time.Instant.now());
    }

    private long totalOperations(StoragePerformanceSnapshot snapshot) {
        return snapshot.redisRead().operationCount()
                + snapshot.redisWrite().operationCount()
                + snapshot.postgresRead().operationCount()
                + snapshot.postgresWrite().operationCount();
    }

    private StoragePerformanceSnapshot emptyPerformanceSnapshot() {
        return new StoragePerformanceSnapshot(
                LatencyMetricSnapshot.empty(),
                LatencyMetricSnapshot.empty(),
                LatencyMetricSnapshot.empty(),
                LatencyMetricSnapshot.empty());
    }

    public CacheDatabaseAdmin admin() {
        return adminContext.get();
    }

    public CacheDatabaseDebug debug() {
        return new CacheDatabaseDebug(entityRegistry, session);
    }

    public CacheDatabaseSchemaAdmin schema() {
        return schemaAdmin;
    }

    public CacheDatabaseConfig config() {
        return config;
    }

    public com.reactor.cachedb.core.api.CacheWriteBatch writeBatch() {
        return writeBatch(java.util.UUID.randomUUID().toString());
    }

    public com.reactor.cachedb.core.api.CacheWriteBatchReceipt inTransaction(
            java.util.function.Consumer<com.reactor.cachedb.core.api.CacheUnitOfWork> commands) {
        return new CacheTransactionTemplate(this).execute(commands);
    }

    public com.reactor.cachedb.core.api.CacheWriteBatch writeBatch(String batchId) {
        return new com.reactor.cachedb.redis.RedisAtomicWriteBatch(
                        foregroundJedis,
                        entityRegistry,
                        redisKeyStrategy,
                        config.writeBehind(),
                        config.redisGuardrail(),
                        producerGuard,
                        batchId)
                .withMaxColumnsPerOperation(config.resourceLimits().maxColumnsPerOperation())
                .withQueryIndexConfig(config.queryIndex())
                .withTraceContextPropagator(runtimeTraceContextPropagator)
                .withNearInvalidationPublisher(nearCaches::publishLegacyInvalidations);
    }

    public String instanceId() {
        return instanceId;
    }

    public CacheDatabaseAdminHttpServer adminHttpServer() {
        return adminHttpServer(config.adminHttp());
    }

    public CacheDatabaseAdminHttpServer adminHttpServer(AdminHttpConfig adminHttpConfig) {
        return new CacheDatabaseAdminHttpServer(this, adminHttpConfig);
    }

    void ownResource(AutoCloseable resource) {
        if (resource != null && !ownedResources.contains(resource)) {
            ownedResources.add(resource);
        }
    }

    @Override
    public void close() {
        session.stopTenantProducers();
        asyncExecutor.stopAccepting();
        // Foreclose both transport admission and the disabled/causal/UOW legacy bypass paths first.
        RuntimeException closeFailure = closeResource(pointReads, null);
        closeFailure = closeResource(asyncExecutor, closeFailure);
        closeFailure = closeResource(writeBehindWorker, closeFailure);
        durableListeners.clear();
        closeFailure = closeResource(deadLetterRecoveryWorker, closeFailure);
        closeFailure = closeResource(recoveryCleanupWorker, closeFailure);
        closeFailure = closeResource(adminIncidentDeliveryManager, closeFailure);
        closeFailure = closeResource(adminReportJobWorker, closeFailure);
        closeFailure = closeResource(monitoringHistoryBuffer, closeFailure);
        closeFailure = closeResource(alertRouteHistoryBuffer, closeFailure);
        closeFailure = closeResource(performanceHistoryBuffer, closeFailure);
        closeFailure = closeResource(projectionRefreshWorker, closeFailure);
        closeFailure = closeResource(projectionRefreshDispatcher, closeFailure);
        for (AutoCloseable resource : ownedResources) {
            closeFailure = closeResource(resource, closeFailure);
        }
        ownedResources.clear();
        if (closeFailure != null) {
            throw closeFailure;
        }
    }

    private RuntimeException closeResource(
            AutoCloseable resource, RuntimeException currentFailure) {
        if (resource == null) {
            return currentFailure;
        }
        try {
            resource.close();
            return currentFailure;
        } catch (Exception exception) {
            if (currentFailure == null) {
                return new IllegalStateException(
                        "Failed to close a CacheDatabase resource", exception);
            }
            currentFailure.addSuppressed(exception);
            return currentFailure;
        }
    }
}
