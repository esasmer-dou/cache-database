package com.reactor.cachedb.starter;

import com.reactor.cachedb.core.api.CacheSession;
import com.reactor.cachedb.core.api.EntityRepository;
import com.reactor.cachedb.core.cache.CachePolicy;
import com.reactor.cachedb.core.config.CacheDatabaseConfig;
import com.reactor.cachedb.core.model.EntityCodec;
import com.reactor.cachedb.core.model.EntityMetadata;
import com.reactor.cachedb.core.page.EntityByIdLoader;
import com.reactor.cachedb.core.page.EntityPageLoader;
import com.reactor.cachedb.core.page.EntityQueryLoader;
import com.reactor.cachedb.core.page.NoOpEntityByIdLoader;
import com.reactor.cachedb.core.page.NoOpEntityPageLoader;
import com.reactor.cachedb.core.page.NoOpEntityQueryLoader;
import com.reactor.cachedb.core.query.QueryEvaluator;
import com.reactor.cachedb.core.queue.StoragePerformanceCollector;
import com.reactor.cachedb.core.queue.WriteBehindQueue;
import com.reactor.cachedb.core.registry.EntityBinding;
import com.reactor.cachedb.core.registry.EntityRegistry;
import com.reactor.cachedb.core.relation.NoOpRelationBatchLoader;
import com.reactor.cachedb.core.relation.RelationBatchLoader;
import com.reactor.cachedb.redis.JedisPooledOperations;
import com.reactor.cachedb.redis.ProjectionRefreshDispatcher;
import com.reactor.cachedb.redis.RedisClientOperations;
import com.reactor.cachedb.redis.RedisEntityRepository;
import com.reactor.cachedb.redis.RedisFunctionExecutor;
import com.reactor.cachedb.redis.RedisHotSetManager;
import com.reactor.cachedb.redis.RedisKeyStrategy;
import com.reactor.cachedb.redis.RedisPageCacheManager;
import com.reactor.cachedb.redis.RedisProducerGuard;
import com.reactor.cachedb.redis.RedisProjectionRefreshQueue;
import com.reactor.cachedb.redis.RedisQueryIndexManager;

import redis.clients.jedis.JedisPooled;

import java.util.concurrent.ConcurrentHashMap;

public final class DefaultCacheSession implements CacheSession {
    private com.reactor.cachedb.redis.RedisNearCacheCoordinator nearCacheCoordinator;
    DefaultCacheSession withNearCacheCoordinator(com.reactor.cachedb.redis.RedisNearCacheCoordinator coordinator) {
        nearCacheCoordinator = coordinator; return this;
    }
    @Override public boolean awaitDurable(com.reactor.cachedb.core.model.WriteReceipt<?, ?> receipt, java.time.Duration timeout) {
        return durabilityTracker.await(receipt, timeout, null);
    }
    @Override public boolean awaitDurable(com.reactor.cachedb.core.api.CacheWriteBatchReceipt receipt, java.time.Duration timeout) {
        return durabilityTracker.awaitBatch(receipt, timeout);
    }
    private final com.reactor.cachedb.redis.RedisDurabilityTracker durabilityTracker;
    @Override public boolean isDurable(com.reactor.cachedb.core.model.WriteReceipt<?, ?> receipt) {
        return durabilityTracker.isDurable(receipt);
    }
    @Override public boolean isDurable(com.reactor.cachedb.core.api.CacheWriteBatchReceipt receipt) {
        if (receipt.dependencies().isEmpty()) throw new IllegalArgumentException("Batch receipt has no durability dependencies");
        return durabilityTracker.areDurableDependencies(receipt.dependencies());
    }
    @Override public boolean areDurable(java.util.Collection<? extends com.reactor.cachedb.core.model.WriteReceipt<?, ?>> receipts) {
        return durabilityTracker.areDurable(receipts);
    }

    private final RedisClientOperations foregroundJedis;
    private final RedisClientOperations backgroundJedis;
    private final CacheDatabaseConfig config;
    private final EntityRegistry entityRegistry;
    private final WriteBehindQueue writeBehindQueue;
    private final RedisKeyStrategy redisKeyStrategy;
    private final RedisFunctionExecutor functionExecutor;
    private final RedisProducerGuard producerGuard;
    private final RedisHotSetManager hotSetManager;
    private final QueryEvaluator queryEvaluator;
    private final StoragePerformanceCollector performanceCollector;
    private final ProjectionRefreshDispatcher projectionRefreshDispatcher;
    private final RedisProjectionRefreshQueue projectionRefreshQueue;
    private final ConcurrentHashMap<RepositoryKey, EntityRepository<?, ?>> repositories =
            new ConcurrentHashMap<>();

    public DefaultCacheSession(
            JedisPooled foregroundJedis,
            JedisPooled backgroundJedis,
            CacheDatabaseConfig config,
            EntityRegistry entityRegistry,
            WriteBehindQueue writeBehindQueue,
            RedisKeyStrategy redisKeyStrategy,
            RedisFunctionExecutor functionExecutor,
            RedisProducerGuard producerGuard,
            RedisHotSetManager hotSetManager,
            QueryEvaluator queryEvaluator,
            StoragePerformanceCollector performanceCollector,
            ProjectionRefreshDispatcher projectionRefreshDispatcher,
            RedisProjectionRefreshQueue projectionRefreshQueue) {
        this(
                JedisPooledOperations.of(foregroundJedis),
                JedisPooledOperations.of(backgroundJedis),
                config,
                entityRegistry,
                writeBehindQueue,
                redisKeyStrategy,
                functionExecutor,
                producerGuard,
                hotSetManager,
                queryEvaluator,
                performanceCollector,
                projectionRefreshDispatcher,
                projectionRefreshQueue);
    }

    public DefaultCacheSession(
            RedisClientOperations foregroundJedis,
            RedisClientOperations backgroundJedis,
            CacheDatabaseConfig config,
            EntityRegistry entityRegistry,
            WriteBehindQueue writeBehindQueue,
            RedisKeyStrategy redisKeyStrategy,
            RedisFunctionExecutor functionExecutor,
            RedisProducerGuard producerGuard,
            RedisHotSetManager hotSetManager,
            QueryEvaluator queryEvaluator,
            StoragePerformanceCollector performanceCollector,
            ProjectionRefreshDispatcher projectionRefreshDispatcher,
            RedisProjectionRefreshQueue projectionRefreshQueue) {
        this.foregroundJedis = foregroundJedis;
        this.durabilityTracker = new com.reactor.cachedb.redis.RedisDurabilityTracker(backgroundJedis, redisKeyStrategy);
        this.backgroundJedis = backgroundJedis;
        this.config = config;
        this.entityRegistry = entityRegistry;
        this.writeBehindQueue = writeBehindQueue;
        this.redisKeyStrategy = redisKeyStrategy;
        this.functionExecutor = functionExecutor;
        this.producerGuard = producerGuard;
        this.hotSetManager = hotSetManager;
        this.queryEvaluator = queryEvaluator;
        this.performanceCollector = performanceCollector;
        this.projectionRefreshDispatcher = projectionRefreshDispatcher;
        this.projectionRefreshQueue = projectionRefreshQueue;
    }

    @Override
    public <T, ID> EntityRepository<T, ID> repository(
            EntityMetadata<T, ID> metadata, EntityCodec<T> codec) {
        EntityBinding<T, ID> binding =
                resolveBinding(metadata, codec, config.resourceLimits().defaultCachePolicy());
        CachePolicy resolvedCachePolicy =
                binding.cachePolicy() == null
                        ? config.resourceLimits().defaultCachePolicy()
                        : binding.cachePolicy();
        return repository(metadata, codec, resolvedCachePolicy);
    }

    @Override
    @SuppressWarnings("unchecked") // The registered entity and policy select this typed factory result.
    public <T, ID> EntityRepository<T, ID> repository(
            EntityMetadata<T, ID> metadata, EntityCodec<T> codec, CachePolicy cachePolicy) {
        CachePolicy defaultPolicy = config.resourceLimits().defaultCachePolicy();
        EntityBinding<T, ID> binding =
                resolveBinding(metadata, codec, cachePolicy == null ? defaultPolicy : cachePolicy);
        RelationBatchLoader<T> relationBatchLoader =
                binding.relationBatchLoader() == null
                        ? new NoOpRelationBatchLoader<>()
                        : binding.relationBatchLoader();
        EntityPageLoader<T> pageLoader =
                binding.pageLoader() == null ? new NoOpEntityPageLoader<>() : binding.pageLoader();
        EntityByIdLoader<T, ID> byIdLoader =
                binding.byIdLoader() == null ? new NoOpEntityByIdLoader<>() : binding.byIdLoader();
        EntityQueryLoader<T> queryLoader =
                binding.queryLoader() == null
                        ? new NoOpEntityQueryLoader<>()
                        : binding.queryLoader();
        CachePolicy resolvedCachePolicy =
                cachePolicy != null
                        ? cachePolicy
                        : (binding.cachePolicy() == null ? defaultPolicy : binding.cachePolicy());
        RepositoryKey repositoryKey = new RepositoryKey(metadata.entityName(), resolvedCachePolicy);
        return (EntityRepository<T, ID>)
                repositories.computeIfAbsent(
                        repositoryKey,
                        ignored ->
                                createRepository(
                                        metadata,
                                        binding.codec(),
                                        resolvedCachePolicy,
                                        relationBatchLoader,
                                        pageLoader,
                                        byIdLoader,
                                        queryLoader));
    }

    private <T, ID> EntityRepository<T, ID> createRepository(
            EntityMetadata<T, ID> metadata,
            EntityCodec<T> codec,
            CachePolicy resolvedCachePolicy,
            RelationBatchLoader<T> relationBatchLoader,
            EntityPageLoader<T> pageLoader,
            EntityByIdLoader<T, ID> byIdLoader,
            EntityQueryLoader<T> queryLoader) {
        RedisQueryIndexManager<T, ID> queryIndexManager =
                new RedisQueryIndexManager<>(
                        foregroundJedis,
                        metadata,
                        codec,
                        redisKeyStrategy,
                        entityRegistry,
                        config.queryIndex(),
                        config.relations(),
                        queryEvaluator,
                        producerGuard);
        return new RedisEntityRepository<>(
                foregroundJedis,
                metadata,
                codec,
                writeBehindQueue,
                redisKeyStrategy,
                com.reactor.cachedb.core.plan.FetchPlan.empty(),
                resolvedCachePolicy,
                functionExecutor,
                producerGuard,
                config.redisGuardrail(),
                redisKeyStrategy.writeStreamKey(config.writeBehind().streamKey(), metadata.redisNamespace()),
                config.writeBehind().compactionStreamKey(),
                config.writeBehind().compactionShardCount(),
                entityRegistry,
                relationBatchLoader,
                config.relations(),
                config.queryIndex(),
                pageLoader,
                byIdLoader,
                queryLoader,
                config.pageCache(),
                config.readThrough(),
                config.readShapeGuardrail(),
                new RedisPageCacheManager<>(
                        foregroundJedis,
                        metadata,
                        codec,
                        resolvedCachePolicy,
                        redisKeyStrategy,
                        hotSetManager,
                        queryIndexManager,
                        producerGuard,
                        config.readShapeGuardrail(),
                        performanceCollector),
                queryEvaluator,
                queryIndexManager,
                performanceCollector,
                backgroundJedis,
                projectionRefreshDispatcher,
                projectionRefreshQueue).withMutationConfig(config.mutations())
                .withWatcherLimit(config.resourceLimits().maxWatchersPerEntity())
                .withNearCache(nearCacheCoordinator);
    }

    private record RepositoryKey(String entityName, CachePolicy cachePolicy) {}

    @SuppressWarnings("unchecked")
    private <T, ID> EntityBinding<T, ID> resolveBinding(
            EntityMetadata<T, ID> metadata, EntityCodec<T> codec, CachePolicy cachePolicy) {
        return (EntityBinding<T, ID>)
                entityRegistry
                        .find(metadata.entityName())
                        .orElseGet(
                                () ->
                                        entityRegistry.register(
                                                metadata,
                                                codec,
                                                cachePolicy,
                                                new NoOpRelationBatchLoader<>(),
                                                new NoOpEntityPageLoader<>()));
    }
}
